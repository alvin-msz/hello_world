# Detection
|   model              |  dataset |   backbone     |   Input shape      |   config  |  ckpt download        |  demo download       |
| :----------:          | :-------:|  :--------:    |  :------------:    | :------: |        :--------:          | :--------:           |
| CenterPoint | Nuscenes | Pointpillar | 300000x5 | configs/detection/centerpoint/centerpoint_pointpillar_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/centerpoint_pointpillar_nuscenes/* --ftp-password='c5R,2!pG' | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/centerpoint_pointpillar_nuscenes/* --ftp-password='c5R,2!pG' |

