# optical flow
|   model              |  dataset |   backbone     |   Input shape      |   config  |  ckpt download        |  demo download       |
| :----------:          | :-------:|  :--------:    |  :------------:    | :------: |        :--------:          | :--------:           |
| pwcnet | FlyingChairs | - | 384x512 | configs/opticalflow_pred/pwcnet/pwcnet_pwcnetneck_flyingchairs.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.0.20/py310/modelzoo/qat_origin_modelzoo/pwcnet_pwcnetneck_flyingchairs/* --ftp-password='c5R,2!pG' | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.0.20/py310/demo/pwcnet_pwcnetneck_flyingchairs/* --ftp-password='c5R,2!pG' |
