import copy
import os
from functools import partial
from pathlib import Path

import torch
import torch.nn as nn
from horizon_plugin_pytorch.march import March
from horizon_plugin_pytorch.quantization.qconfig_template import (
    default_qat_fixed_act_qconfig_setter,
    sensitive_op_qat_8bit_weight_16bit_fixed_act_qconfig_setter,
)

from hat.utils.config import ConfigVersion

VERSION = ConfigVersion.v2
training_step = os.environ.get("HAT_TRAINING_STEP", "float")

task_name = "qcnet_oe_argoverse2"
batch_size_per_gpu = 1
dataloader_workers = 4
device_ids = [i for i in range(8)]  # noqa
ckpt_dir = f"./tmp_models/{task_name}"
cudnn_benchmark = False
seed = 2
log_rank_zero_only = True
bn_kwargs = {}
march = March.NASH_M
qat_mode = "fuse_bn"

data_rootdir = "tmp_data/argoverse-2/qc_data"
input_dim = 2
hidden_dim = 128
ori_historical_sec = (
    5  # Length of the original historical trajectory in seconds）
)
ori_future_sec = 6  # Length of the predicted future trajectory in seconds
ori_sample_fre = (
    10  # Original sampling frequency, which is 10 steps per second
)
sample_fre = 2  # Frequency used for downsampling
num_historical_steps = ori_historical_sec * sample_fre
num_future_steps = ori_future_sec * sample_fre
num_freq_bands = 32
num_heads = 8
head_dim = 16
output_dim = 2
time_span = 2
dropout = 0.1
num_map_layers = 1
num_agent_layers = 1
num_modes = 6
num_recurrent_steps = 3
num_t2m_steps = 30 // ori_sample_fre * sample_fre
num_dec_layers = 1
split_rec_modules = True
reuse_agent_rembs = True

deploy_model = dict(
    type="QCNetOE",
    encoder=dict(
        type="QCNetOEEncoder",
        map_encoder=dict(
            type="QCNetOEMapEncoder",
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            num_historical_steps=num_historical_steps,
            num_freq_bands=num_freq_bands,
            num_layers=num_map_layers,
            num_heads=num_heads,
            head_dim=head_dim,
            dropout=dropout,
        ),
        agent_encoder=dict(
            type="QCNetOEAgentEncoderStream",
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            num_historical_steps=num_historical_steps,
            time_span=time_span,
            num_freq_bands=num_freq_bands,
            num_layers=num_agent_layers,
            num_heads=num_heads,
            head_dim=head_dim,
            dropout=dropout,
            num_t2m_steps=num_t2m_steps,
            save_memory=False,
            stream_infer=False,  # if hbir_exporter his_model, must set False
            reuse_agent_rembs=reuse_agent_rembs,
            deploy=True,
        ),
    ),
)


sensitive_path1 = os.path.join(
    ckpt_dir, "analysis", "output_prob_L1_sensitive_ops.pt"
)
sensitive_path2 = os.path.join(
    ckpt_dir, "analysis", "output_pred_L1_sensitive_ops.pt"
)

if os.path.exists(sensitive_path1):
    sensitive_table1 = torch.load(sensitive_path1)
    sensitive_table2 = torch.load(sensitive_path2)
    qat_qconfig_setter = (
        sensitive_op_qat_8bit_weight_16bit_fixed_act_qconfig_setter(
            sensitive_table1,
            topk=200,
            ratio=None,
        ),
        sensitive_op_qat_8bit_weight_16bit_fixed_act_qconfig_setter(
            sensitive_table2,
            topk=100,
            ratio=None,
        ),
        default_qat_fixed_act_qconfig_setter,
    )
else:
    qat_qconfig_setter = (default_qat_fixed_act_qconfig_setter,)


B = 1
A = 30
pl = 80
pt = 50
HT = ori_historical_sec * sample_fre
QT = num_t2m_steps + time_span * (num_agent_layers - 1) - 1
deploy_inputs = {}
deploy_inputs["agent"] = {
    "valid_mask": (torch.rand(1, A, HT) > 0.2).bool(),
    "valid_mask_a2a": (torch.rand(1, HT, A, A) > 0.2).bool(),
    "agent_type": (torch.rand(1, A, 1) * 3).long(),
    "x_a": [torch.rand(B, 1, A, time_span + QT) for i in range(4)],
    "r_pl2a": [torch.rand(B * A, 1, QT, pl) for i in range(3)],
    "r_t": [torch.rand(B * A, 1, QT, time_span) for i in range(4)],
    "r_a2a": [torch.rand(B * QT, 1, A, A) for i in range(3)],
}
deploy_inputs["map_polygon"] = {
    "pl_type": (torch.rand(1, pl) * 3).long(),
    "is_intersection": (torch.rand(1, pl)).long(),
    "r_pl2pl": [torch.rand(B, 1, pl, pl) for i in range(3)],
    "r_pt2pl": [torch.rand(B, 1, pl, pt) for i in range(3)],
}
deploy_inputs["map_point"] = {
    "magnitude": torch.rand(1, pl, pt),
    "pt_type": (torch.rand(1, pl, pt) * 3).long(),
    "side": (torch.rand(1, pl, pt) * 3).long(),
    "mask": (torch.rand(1, pl, pt) > 0.2).bool(),
}
deploy_inputs["type_pl2pl"] = (torch.rand([B, pl, pl]) * 5).long()

deploy_model_convert_pipeline = dict(
    type="ModelConvertPipeline",
    qat_mode=qat_mode,
    converters=[
        dict(
            type="Float2QAT",
            convert_mode="jit-strip",
            example_inputs=deploy_inputs,
            qconfig_setter=qat_qconfig_setter,
        ),
    ],
)


real_deploy_model_convert_pipeline = dict(
    type="ModelConvertPipeline",
    qat_mode=qat_mode,
    converters=[
        dict(
            type="Float2QAT",
            convert_mode="jit-strip",
            example_inputs=deploy_inputs,
            qconfig_setter=qat_qconfig_setter,
        ),
        dict(
            type="LoadCheckpoint",
            checkpoint_path=os.path.join(
                ckpt_dir, "qat-checkpoint-last.pth.tar"
            ),
            allow_miss=True,
            ignore_extra=True,
            verbose=True,
        ),
    ],
)


hbir_exporter = dict(
    type="HbirExporter",
    model=deploy_model,
    model_convert_pipeline=real_deploy_model_convert_pipeline,
    example_inputs=deploy_inputs,
    save_path=os.path.join(ckpt_dir, "qcnet_oe_argoverse2_his"),
    model_name=task_name,
    march=march,
)

compile_dir = os.path.join(ckpt_dir, "qcnet_oe_argoverse2_his", "compile")
hbir_save_dir = os.path.join(ckpt_dir, "qcnet_oe_argoverse2_his")
compile_cfg = dict(
    march=march,
    name=task_name,
    out_dir=compile_dir,
    hbm=os.path.join(compile_dir, "model.hbm"),
    layer_details=True,
    input_source=["ddr"],
    opt="O2",
)
calops_cfg = dict(method="hook")
onnx_cfg = dict(
    model=deploy_model,
    stage="qat",
    inputs=deploy_inputs,
    model_convert_pipeline=real_deploy_model_convert_pipeline,
    out_dir=os.path.join(ckpt_dir, "qcnet_oe_argoverse2_his"),
)
