# map
|   model              |  dataset |   backbone     |   Input shape      |   config  |  ckpt download        |  demo download       |
| :----------:          | :-------:|  :--------:    |  :------------:    | :------: |        :--------:           | :--------:           |
| maptroe_henet_tinym_bevformer_nuscenes | Nuscenes | henet_tinym_imagenet | (480, 800) | configs/map/maptroe_henet_tinym_bevformer_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/maptroe_henet_tinym_bevformer_nuscenes/* --ftp-password='c5R,2!pG' | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/maptroe_henet_tinym_bevformer_nuscenes/* --ftp-password='c5R,2!pG' |
| maptroe_sparse_henet_tinym_nuscenes | Nuscenes | henet_tinym_imagenet | (256, 704) | configs/map/maptroe_sparse_henet_tinym_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/maptroe_sparse_henet_tinym_nuscenes/* --ftp-password='c5R,2!pG' | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/maptroe_sparse_henet_tinym_nuscenes/* --ftp-password='c5R,2!pG' |

# RUNTIME REFERENCEPOINT

|   file         |  download |
| :----------:       |  :-----------: |
| maptroe_henet_tinym_bevformer_nuscenes  |  wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/runtime_reference_points/maptroe_henet_tinym_bevformer_nuscenes --ftp-password='c5R,2!pG' |