"""BevFusion ego-frame multitask, OCC Argmax compiled onto the BPU.

Same ego / Occ3D training recipe as ``*_argmax_cpu_ego.py`` (shared
``task_name`` / checkpoints). Float, calibration and QAT stay on the
logits ``UnionMask`` graph so QAT can load calib scales and backprop CE.
Only ``deploy_model`` switches to ``BevformerOccDetDecoderArgmax`` so
quantized ``argmax(-1)`` sits on the BPU graph (before DeQuantStub);
HBIR/HBM emit ``[B, Dx, Dy, Dz]`` INT32 class ids. Do not dequant then
cast ArgMax to int8 — hbdk cannot map that and the OCC output becomes
0 bytes on the board.

Camera VT uses ``ego2img``, OCC uses native Occ3D ego labels, detection uses
``ego_bboxes_labels``, and LiDAR points are mapped by ``Lidar2EgoNuscenes``.
Fusion starts from Occ3D-aligned ego CenterPoint + ego camera checkpoints.

``SampleBevRotationAngle`` + ``RotateEgoOccVoxels`` share the yaw with
``BevBBoxRotation`` so OCC voxels stay aligned.

BEV XY is Occ3D 200×200 (±40 m, 0.4 m). OCC GT / C2H / viz stay
``[-1, 5.4]`` 16×0.4 m. VT + detection use Z ``[-1.8, 6.2]`` (span 8.0 m).
LiDAR voxelization keeps CenterPoint XY (±51.2 m / 0.2 m) with the same
8 m Z pillar; ``BevFusionOccGrid`` crops the 128×128 neck to ±40 m and
upsamples to 200×200. Fusion OCC keeps occupied CE on
``mask_lidar | mask_camera``. Class balance uses vis-only ``sem_scal``;
empty uses column-relative ``geo_scal`` on FREE *above* a hit (unknown
non-vis is never treated as empty — avoids distant FREE collapse).
No FREE CE and no absolute z-band. Occupied CE is *not* mixed into the
same ``sum(w*ce)/sum(w)`` as free.

If lidar crop / perception ROI is not nuScenes, retune constants in
``scripts/tools/ego_occ_rotate.py``. Keep OCC z on the label grid; keep
VT/det Z span 8.0; recompute ``lidar_bev_roi_box`` if lidar XY or voxel
size changes. BPU: ``centerpoint_preprocess_5dim_ego.json`` =
``LIDAR_EGO_PC_RANGE``; ``bevfusion_pointpillar_multitask_post_ego.json``
``bev_range`` = ``VT_DET_PC_RANGE``.
"""
import copy
import os
import re
import shutil
import sys
from functools import partial

import cv2
import horizon_plugin_pytorch as horizon
import numpy as np
import torch
from horizon_plugin_pytorch.quantization import March
from PIL import Image
from torchvision.transforms.functional import pil_to_tensor

try:
    from torchvision.transforms.functional_tensor import resize
except ImportError:
    # torchvision 0.18
    from torchvision.transforms._functional_tensor import resize

from hat.data.collates.nusc_collates import collate_nuscenes_sequencev2
from hat.data.transforms.functional_img import image_pad
from hat.models.backbones.mixvargenet import MixVarGENetConfig
from hat.utils.checkpoint import update_state_dict_by_add_prefix
from hat.utils.config import ConfigVersion
from hat.visualize.lidar_det import lidar_det_visualize

_tools_dir = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "tools")
)
if _tools_dir not in sys.path:
    sys.path.insert(0, _tools_dir)
import bevfusion_occ_grid  # noqa: F401
import bevformer_occ_det_decoder_argmax  # noqa: F401
import bevformer_occ_union_mask  # noqa: F401
import ego_occ_rotate  # noqa: F401
import lidar2ego_nuscenes  # noqa: F401
from ego_occ_rotate import (  # noqa: E402
    LIDAR_EGO_PC_RANGE,
    LIDAR_EGO_VOXEL_SIZE,
    OCC3D_FREE_INDEX,
    OCC3D_GRID_SIZE,
    OCC3D_PC_RANGE,
    VT_DET_PC_RANGE,
)
# Add occ metric
from occ_seg_metric import OccSegMetric

from horizon_plugin_pytorch.dtype import qint8, qint16
from horizon_plugin_pytorch.quantization import (
    QConfig,
    get_qconfig,
    observer_v2,
)
from horizon_plugin_pytorch.quantization.fake_quantize import FakeQuantize
from horizon_plugin_pytorch.quantization.qconfig_setter import (
    ConvDtypeTemplate,
    MatmulDtypeTemplate,
    ModuleNameTemplate,
    QconfigSetter,
)

VERSION = ConfigVersion.v2
training_step = os.environ.get("HAT_TRAINING_STEP", "float")

task_name = "bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_ego_4loss"
batch_size_per_gpu = 16
device_ids = [4, 5, 6, 7]

ckpt_dir = f"./tmp_models/{task_name}"

lidar_task_name = "centerpoint_pointpillar_nuscenes_ego_occ3d"
lidar_ckpt_dir = "./tmp_models/centerpoint_pointpillar_nuscenes_ego_occ3d"

camera_task_name = "bevformer_henet_camera_multitask_nuscenes_ego_4loss"
camera_ckpt_dir = f"./tmp_models/{camera_task_name}"
# datadir settings — align with bevformer_henet_camera_multitask_nuscenes_pretrain.py
# and centerpoint_pointpillar_nuscenes.py (shared bevfusion_nuscenes LMDB)
train_data_path = "data/nuscenes/pack/horizon_bevfusion_nuscenes/train_lmdb/"
val_data_path = "data/nuscenes/pack/horizon_bevfusion_nuscenes/val_lmdb/"
meta_rootdir = "data/nuscenes"
log_loss_show = 200

cudnn_benchmark = True
seed = None
log_rank_zero_only = True
march = March.NASH_M
norm_cfg = None
bn_kwargs = dict(eps=2e-5, momentum=0.1)
qat_mode = "fuse_bn"
convert_mode = "fx"

# LiDAR: CenterPoint XY (±51.2 m / 0.2 m) + 8 m ego Z ([-1.8, 6.2] m).
lidar_point_cloud_range = list(LIDAR_EGO_PC_RANGE)
lidar_voxel_size = list(LIDAR_EGO_VOXEL_SIZE)
lidar_norm_range = lidar_point_cloud_range[:3] + [0.0] + lidar_point_cloud_range[3:] + [255.0]
# OCC GT / C2H / viz: Occ3D 200×200×16, ±40 m, [-1, 5.4].
# VT + detection: same XY, Z [-1.8, 6.2] so HAT ``Z = z_max - z_min`` is 8.0.
occ_pc_range = list(OCC3D_PC_RANGE)
point_cloud_range = list(VT_DET_PC_RANGE)
bev_size = (40.0, 40.0, 0.4)
bev_size_occ = (40, 40)
occ_voxel_size = [0.4, 0.4, 0.4]
occ_grid_size = list(OCC3D_GRID_SIZE)
# Crop CenterPoint 128×128 (±51.2 @ 0.8 m) to center ±40 m (100×100).
lidar_bev_roi_box = (14, 14, 114, 114)

voxel_size = lidar_voxel_size
max_num_points = 20
max_voxels = (30000, 40000)

_dim_ = 256
_pos_dim_ = _dim_ // 2
_num_levels_ = 1
bev_h_ = occ_grid_size[0]
bev_w_ = occ_grid_size[1]
input_size = (512, 960)
map_size = (15, 30, 0.15)
use_lidar2img = False
with_ego_occ = True

max_camoverlap_num = 2
bev_sparse_rate = 0.4
vt_num_layers = 1
vt_num_points_in_pillar = 4
vt_sa_num_points = 2
vt_ca_num_points = 4
# Packed per-camera BEV queries. 64×80=5120 overflowed at ~7.2k hits on
# Occ3D 200×200; keep ≥ bev_sparse_rate of the physical grid.
vt_virtual_bev_h = int(bev_sparse_rate * bev_h_)  # 80
vt_virtual_bev_w = bev_w_  # 200

lidar_input = True
camera_input = True

use_occ_head = True
use_bev_head = True

class_names = (
    "car",
    "truck",
    "trailer",
    "bus",
    "construction_vehicle",
    "bicycle",
    "motorcycle",
    "pedestrian",
    "traffic_cone",
    "barrier",
)

num_classes = 10
num_classes_occ = 18

occ3d_seg_class = [
    "others",
    "barrier",
    "bicycle",
    "bus",
    "car",
    "construction_vehicle",
    "motorcycle",
    "pedestrian",
    "traffic_cone",
    "trailer",
    "truck",
    "driveable_surface",
    "other_flat",
    "sidewalk",
    "terrain",
    "manmade",
    "vegetation",
]

# No inverse-log class weights: down-weighting ``free`` (class 17) encouraged
# ceiling false positives on open road when VT/LiDAR Z was misaligned.


def get_feature_map_size(point_cloud_range, voxel_size):
    point_cloud_range = np.array(point_cloud_range, dtype=np.float32)
    voxel_size = np.array(voxel_size, dtype=np.float32)
    grid_size = (point_cloud_range[3:] - point_cloud_range[:3]) / voxel_size
    grid_size = np.round(grid_size).astype(np.int64)
    return grid_size


lidar_network = dict(
    type="CenterPointDetector",
    feature_map_shape=get_feature_map_size(
        lidar_point_cloud_range, lidar_voxel_size
    ),
    pre_process=dict(
        type="CenterPointPreProcess",
        pc_range=lidar_point_cloud_range,
        voxel_size=lidar_voxel_size,
        max_voxels_num=max_voxels,
        max_points_in_voxel=max_num_points,
        norm_range=lidar_norm_range,
        norm_dims=[0, 1, 2, 3],
    ),
    reader=dict(
        type="PillarFeatureNet",
        num_input_features=5,
        num_filters=(64,),
        with_distance=False,
        pool_size=(max_num_points, 1),
        voxel_size=lidar_voxel_size,
        pc_range=lidar_point_cloud_range,
        bn_kwargs=norm_cfg,
        quantize=True,
        use_4dim=True,
        use_conv=True,
        hw_reverse=True,
    ),
    backbone=dict(
        type="PointPillarScatter",
        num_input_features=64,
        use_horizon_pillar_scatter=True,
        quantize=True,
    ),
    neck=dict(
        type="SECONDNeck",
        in_feature_channel=64,
        down_layer_nums=[3, 5, 5],
        down_layer_strides=[2, 2, 2],
        down_layer_channels=[64, 128, 256],
        up_layer_strides=[0.5, 1, 2],
        up_layer_channels=[128, 128, 128],
        bn_kwargs=norm_cfg,
        quantize=True,
        use_relu6=False,
    ),
)
camera_network = dict(
    type="BevFormer",
    out_indices=(-1,),
    backbone=dict(
        type="HENet",
        in_channels=3,
        block_nums=[4, 3, 8, 6],
        embed_dims=[64, 128, 192, 384],
        attention_block_num=[0, 0, 0, 0],
        mlp_ratios=[2, 2, 2, 3],
        mlp_ratio_attn=2,
        act_layer=["nn.GELU", "nn.GELU", "nn.GELU", "nn.GELU"],
        use_layer_scale=[True, True, True, True],
        layer_scale_init_value=1e-5,
        num_classes=1000,
        include_top=False,
        extra_act=[False, False, False, False],
        final_expand_channel=0,
        feature_mix_channel=1024,
        block_cls=["GroupDWCB", "GroupDWCB", "AltDWCB", "DWCB"],
        down_cls=["S2DDown", "S2DDown", "S2DDown", "None"],
        patch_embed="origin",
    ),
    neck=dict(
        type="FPN",
        in_strides=[32],
        in_channels=[384],
        out_strides=[32],
        out_channels=[_dim_],
        bn_kwargs=dict(eps=1e-5, momentum=0.1),
    ),
    view_transformer=dict(
        type="SingleBevFormerViewTransformer",
        bev_h=bev_h_,
        bev_w=bev_w_,
        pc_range=point_cloud_range,
        num_points_in_pillar=vt_num_points_in_pillar,
        embed_dims=_dim_,
        queue_length=1,
        in_indices=(-1,),
        single_bev=True,
        use_lidar2img=use_lidar2img,
        max_camoverlap_num=max_camoverlap_num,
        virtual_bev_h=vt_virtual_bev_h,
        virtual_bev_w=vt_virtual_bev_w,
        positional_encoding=dict(
            type="LearnedPositionalEncoding",
            num_feats=_pos_dim_,
            row_num_embed=bev_h_,
            col_num_embed=bev_w_,
        ),
        encoder=dict(
            type="SingleBEVFormerEncoder",
            num_layers=vt_num_layers,
            return_intermediate=False,
            bev_h=bev_h_,
            bev_w=bev_w_,
            embed_dims=_dim_,
            encoder_layer=dict(
                type="SingleBEVFormerEncoderLayer",
                embed_dims=_dim_,
                selfattention=dict(
                    type="HorizonMultiScaleDeformableAttention",
                    embed_dims=_dim_,
                    num_points=vt_sa_num_points,
                    num_levels=1,
                    grid_align_num=4,
                    batch_first=True,
                    # reduce_align_num=8,
                    feats_size=[[bev_w_, bev_h_]],
                ),
                crossattention=dict(
                    type="HorizonSpatialCrossAttention",
                    max_camoverlap_num=max_camoverlap_num,
                    bev_h=bev_h_,
                    bev_w=bev_w_,
                    deformable_attention=dict(
                        type="HorizonMultiScaleDeformableAttention3D",
                        embed_dims=_dim_,
                        num_points=vt_ca_num_points,
                        num_levels=_num_levels_,
                        grid_align_num=64,
                        feats_size=[[30, 16]],
                    ),
                    embed_dims=_dim_,
                ),
                dropout=0.1,
            ),
        ),
    ),
)
bev_head = dict(
    type="BEVFormerDetDecoder",
    bev_h=bev_h_,
    bev_w=bev_w_,
    num_query=900,
    embed_dims=_dim_,
    pc_range=point_cloud_range,
    decoder=dict(
        type="DetectionTransformerDecoder",
        num_layers=6,
        return_intermediate=True,
        decoder_layer=dict(
            type="DetrTransformerDecoderLayer",
            crossattention=dict(
                type="HorizonMultiScaleDeformableAttention",
                embed_dims=_dim_,
                num_levels=1,
                grid_align_num=4,
                feats_size=[[bev_w_, bev_h_]],
            ),
            dropout=0.1,
        ),
    ),
    criterion=dict(
        type="BevFormerCriterion",
        assigner=dict(
            type="BevFormerHungarianAssigner3D",
            cls_cost=dict(type="FocalLossCost", weight=2.0),
            reg_cost=dict(type="BBox3DL1Cost", weight=0.25),
        ),
        loss_cls=dict(
            type="FocalLoss",
            loss_name="cls",
            num_classes=num_classes + 1,
            alpha=0.25,
            gamma=2.0,
            loss_weight=1.0,
            reduction="mean",
        ),
        loss_bbox=dict(
            type="L1Loss",
            loss_weight=0.15,
        ),
        pc_range=point_cloud_range,
        bbox_key="ego_bboxes_labels",
    ),
    post_process=dict(
        type="BevFormerProcess",
        post_center_range=[-50.0, -50.0, -10.0, 50.0, 50.0, 10.0],
        pc_range=point_cloud_range,
        max_num=300,
        num_classes=10,
    ),
)
occ_head = dict(
    type="BevformerOccDetDecoderUnionMask",
    use_mask=True,
    add_sem_scal=True,
    add_geo_scal=True,
    add_lovasz=True,
    sem_scal_weight=0.5,
    geo_scal_weight=0.2,
    lovasz_weight=1.0,
    free_index=OCC3D_FREE_INDEX,
    lidar_input=lidar_input,
    camera_input=camera_input,
    num_classes=num_classes_occ,
    roi_resizer=None,
    occ_head=dict(
        type="BEVOCCHead2D",
        in_dim=256,
        out_dim=128,
        Dz=occ_grid_size[2],
        num_classes=num_classes_occ,
        use_predicter=True,
        use_upsample=False,
    ),
    loss_occ=dict(
        type="CrossEntropyLoss",
        use_sigmoid=False,
        ignore_index=255,
        loss_weight=6.0,
    ),
)
bev_decoders = []
if use_bev_head:
    bev_decoders.append(bev_head)
if use_occ_head:
    bev_decoders.append(occ_head)
# model settings
model = dict(
    type="BevFusionOccGrid",
    lidar_network=lidar_network if lidar_input else None,
    camera_network=camera_network if camera_input else None,
    bev_decoders=bev_decoders,
    fuse_module=dict(type="BevFuseModule", input_c=384 + _dim_, fuse_c=_dim_),
    bev_h=bev_h_,
    bev_w=bev_w_,
    lidar_roi_box=lidar_bev_roi_box,
    lidar_out_hw=(bev_h_, bev_w_),
)

# model settings
deploy_model = copy.deepcopy(model)
deploy_model["lidar_network"].pop("pre_process")
deploy_model["camera_network"]["view_transformer"]["is_compile"] = True
deploy_model["bev_decoders"][0]["is_compile"] = True
deploy_model["bev_decoders"][0].pop("criterion")
deploy_model["bev_decoders"][0].pop("post_process")
deploy_model["bev_decoders"][1]["is_compile"] = True
deploy_model["bev_decoders"][1]["type"] = "BevformerOccDetDecoderArgmax"
deploy_model["bev_decoders"][1]["add_argmax_for_compile"] = True
deploy_model["bev_decoders"][1].pop("loss_occ")
# UnionMask training-only kwargs are not accepted by the Argmax subclass.
for _k in (
    "add_sem_scal",
    "add_geo_scal",
    "add_lovasz",
    "sem_scal_weight",
    "geo_scal_weight",
    "lovasz_weight",
    "free_index",
    "ignore_index",
):
    deploy_model["bev_decoders"][1].pop(_k, None)

deploy_inputs = dict(
    features=torch.randn((1, 5, 20, 40000), dtype=torch.float32),
    coors=torch.zeros([40000, 4]).int(),
    img=torch.randn((6, 3, 512, 960)),
    queries_rebatch_grid=torch.randn(
        (6, vt_virtual_bev_h, vt_virtual_bev_w, 2)
    ),
    restore_bev_grid=torch.randn(
        (1, max_camoverlap_num * bev_h_, bev_w_, 2)
    ),
    reference_points_rebatch=torch.randn(
        (6, vt_virtual_bev_h * vt_virtual_bev_w, vt_num_points_in_pillar, 2)
    ),
    bev_pillar_counts=torch.randn((1, bev_h_ * bev_w_, 1)),
)

train_dataset = dict(
    type="NuscenesBevSequenceDataset",
    data_path=train_data_path,
    map_size=None,
    map_path=None,
    with_bev_mask=False,
    with_lidar_bboxes=use_lidar2img,
    with_bev_bboxes=False,
    with_ego_bboxes=True,
    bev_range=point_cloud_range,
    max_dist=40.0,
    need_lidar=True,
    num_sweeps=9,
    load_dim=5,
    use_dim=[0, 1, 2, 3, 4],
    num_seq=1,
    with_ego_occ=with_ego_occ,
    with_lidar_occ=use_lidar2img,
    transforms=[
        dict(type="Lidar2EgoNuscenes"),
        dict(type="MultiViewsImgResize", size=input_size),
        dict(type="MultiViewsImgFlip"),
        dict(type="MultiViewsImgRotate", rot=(-5.4, 5.4)),
        dict(
            type="SampleBevRotationAngle",
            rotation_3d_range=(-0.3925, 0.3925),
        ),
        dict(
            type="BevBBoxRotation",
            transform_matrix_key=("ego2img",),
            global_key=("ego2global",),
            rotation_3d_range=(-0.3925, 0.3925),
        ),
        dict(type="RotateEgoOccVoxels"),
        dict(type="MultiViewsPhotoMetricDistortion"),
        dict(
            type="MultiViewsImgTransformWrapper",
            transforms=[
                dict(type="PILToTensor"),
                dict(type="BgrToYuv444", rgb_input=True),
                dict(type="Normalize", mean=128, std=128),
            ],
        ),
    ],
)


data_loader = dict(
    type=torch.utils.data.DataLoader,
    dataset=train_dataset,
    sampler=dict(type=torch.utils.data.DistributedSampler),
    batch_size=batch_size_per_gpu,
    shuffle=True,
    num_workers=8,
    pin_memory=False,
    collate_fn=collate_nuscenes_sequencev2,
)


val_dataset = dict(
    type="NuscenesBevSequenceDataset",
    data_path=val_data_path,
    map_size=None,
    map_path=None,
    with_bev_mask=False,
    with_lidar_bboxes=use_lidar2img,
    with_bev_bboxes=False,
    with_ego_bboxes=True,
    bev_range=point_cloud_range,
    max_dist=40.0,
    with_ego_occ=with_ego_occ,
    with_lidar_occ=use_lidar2img,
    need_lidar=True,
    num_sweeps=9,
    load_dim=5,
    use_dim=[0, 1, 2, 3, 4],
    num_seq=1,
    transforms=[
        dict(type="Lidar2EgoNuscenes"),
        dict(type="MultiViewsImgResize", size=input_size),
        dict(
            type="MultiViewsImgTransformWrapper",
            transforms=[
                dict(type="PILToTensor"),
                dict(type="Pad", divisor=32),
                dict(type="BgrToYuv444", rgb_input=True),
                dict(type="Normalize", mean=128.0, std=128.0),
            ],
        ),
    ],
)
val_data_loader = dict(
    type=torch.utils.data.DataLoader,
    dataset=val_dataset,
    sampler=dict(type=torch.utils.data.DistributedSampler),
    batch_size=1,
    shuffle=False,
    num_workers=4,
    pin_memory=True,
    collate_fn=collate_nuscenes_sequencev2,
)


def loss_collector(outputs: dict):
    losses = []
    for _, loss in outputs.items():
        losses.append(loss)
    return losses


batch_processor = dict(
    type="MultiBatchProcessor",
    need_grad_update=True,
    enable_amp=True,
    loss_collector=loss_collector,
)
val_batch_processor = dict(
    type="MultiBatchProcessor",
    need_grad_update=False,
    loss_collector=None,
)


def update_metric(metrics, batch, model_outs):
    idx = 0
    if use_bev_head:
        metric_gt = {}
        metric_gt["meta"] = batch["seq_meta"][0]["meta"]
        metrics[idx].update(metric_gt, model_outs[idx])
        idx += 1
    if use_occ_head:
        # occ metric
        gt_semantics = batch["seq_meta"][0]["gt_occ_info"]["voxel_semantics"][
            0
        ].squeeze()  # (Dx, Dy, Dz)
        semantics_pred = model_outs[idx][0].squeeze()  # (Dx, Dy, Dz)

        if lidar_input and camera_input:
            lidar_mask = batch["seq_meta"][0]["gt_occ_info"]["mask_lidar"][
                0
            ].squeeze()
            camera_mask = batch["seq_meta"][0]["gt_occ_info"]["mask_camera"][
                0
            ].squeeze()
            mask = lidar_mask | camera_mask
        elif lidar_input:
            mask = batch["seq_meta"][0]["gt_occ_info"]["mask_lidar"][
                0
            ].squeeze()  # (Dx, Dy, Dz)
        elif camera_input:
            mask = batch["seq_meta"][0]["gt_occ_info"]["mask_camera"][
                0
            ].squeeze()
        masked_semantics_gt = gt_semantics[mask]
        masked_semantics_pred = semantics_pred[mask]
        results = {
            "label": masked_semantics_gt.reshape(-1),
            "preds": masked_semantics_pred.reshape(-1),
        }
        metrics[idx].update(**results)


def update_loss(metrics, batch, model_outs):
    for metric in metrics:
        metric.update(model_outs)


val_metric_updater = dict(
    type="MetricUpdater",
    metric_update_func=update_metric,
    step_log_freq=10000,
    epoch_log_freq=1,
    log_prefix="Validation " + task_name,
)
loss_show_update = dict(
    type="MetricUpdater",
    metric_update_func=update_loss,
    step_log_freq=log_loss_show,
    epoch_log_freq=1,
    log_prefix="loss_" + task_name,
)

stat_callback = dict(
    type="StatsMonitor",
    log_freq=log_loss_show,
)

ckpt_callback = dict(
    type="Checkpoint",
    save_dir=ckpt_dir,
    name_prefix=training_step + "-",
    strict_match=True,
    save_interval=1,
    # mode="max",
    mode=None,
)

val_callback = dict(
    type="Validation",
    data_loader=val_data_loader,
    batch_processor=val_batch_processor,
    callbacks=[val_metric_updater],
    val_model=None,
    val_on_train_end=False,
    val_interval=1,
    log_interval=200,
)

trace_callback = dict(
    type="SaveTraced",
    save_dir=ckpt_dir,
    trace_inputs=deploy_inputs,
)

grad_callback = dict(
    type="GradScale",
    module_and_scale=[],
    clip_grad_norm=35,
    clip_norm_type=2,
)

bev_val_nuscenes_metric = dict(
    type="NuscenesMetric",
    data_root=meta_rootdir,
    version="v1.0-trainval",
    # ego_bboxes_labels are already wlh in ego. Do not use the lidar-frame
    # path (sensor2ego + trans_lidar_dim); that would rotate/swap twice.
    use_lidar=False,
    classes=class_names,
    save_prefix="./metric_results/" + task_name,
)
# Add occ metric
# occ_val_nuscenes_metric = dict(
#     type="MeanIOU",
occ_val_nuscenes_metric = OccSegMetric(
    seg_class=occ3d_seg_class,
    ignore_index=17,
)
val_metrics = []
if use_bev_head:
    val_metrics.append(bev_val_nuscenes_metric)
if use_occ_head:
    val_metrics.append(occ_val_nuscenes_metric)


float_trainer = dict(
    type="distributed_data_parallel_trainer",
    model=model,
    data_loader=data_loader,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        converters=[
            dict(
                type="LoadCheckpoint",
                checkpoint_path=os.path.join(
                    camera_ckpt_dir, "float-checkpoint-last.pth.tar"
                ),
                allow_miss=True,
                ignore_extra=True,
                verbose=True,
            ),
            dict(
                type="LoadCheckpoint",
                checkpoint_path=os.path.join(
                    lidar_ckpt_dir, "float-checkpoint-last.pth.tar"
                ),
                state_dict_update_func=partial(
                    update_state_dict_by_add_prefix, prefix="lidar_net."
                ),
                allow_miss=True,
                ignore_extra=True,
                verbose=True,
            ),
        ],
    ),
    optimizer=dict(
        type=torch.optim.AdamW,
        betas=(0.95, 0.99),
        params={
            "camera_net.backbone": dict(lr_mult=0.1),   # 4e-5 × 4 | 0.1 x 1.6e-3
            "lidar_net": dict(lr_mult=0.1),             # 4e-5 × 4 | 0.1 x 1.6e-3
            "bev_decoders.0": dict(lr=8e-4),          # 2e-4 × 4 | 4e-4 x (2loss, focal+l1)
            "bev_decoders.1": dict(lr=1.6e-3),        # 6e-4 × 4 | 4e-4 x (4loss, ce+sem+geo+lovasz)
        },
        lr=1.6e-3,                                    # 4e-4 × 4
        weight_decay=0.01,
    ),
    batch_processor=batch_processor,
    num_epochs=24,
    stop_by="epoch",
    device=None,
    callbacks=[
        stat_callback,
        loss_show_update,
        dict(
            type="CosineAnnealingLrUpdater",
            warmup_len=110,          # 关键：440 步/epoch × 0.28 ≈ 123，取 110~125
            warmup_by="step",
            warmup_lr_ratio=1.0 / 3,
            step_log_interval=500,
            stop_lr=8e-7,            # 2e-7 × 4，保持与 base lr 的比值不变
        ),
        grad_callback,
        val_callback,
        ckpt_callback,
    ],
    sync_bn=True,
    train_metrics=dict(
        type="LossShow",
    ),
    val_metrics=val_metrics,
)


calibration_data_loader = copy.deepcopy(val_data_loader)
calibration_data_loader.pop("sampler")  # Calibration do not support DDP or DP
calibration_example_data_loader = copy.deepcopy(calibration_data_loader)
calibration_example_data_loader["num_workers"] = 0
calibration_batch_processor = copy.deepcopy(val_batch_processor)

# ============ QAT qconfig（对照 model_check_result 的 named_modules 命名）============
def _set_fuse_mode(self):
    from horizon_plugin_pytorch.quantization.fx.fusion_patterns import (
        FuseMode,
    )
    return FuseMode.BNAddReLU


QconfigSetter.get_fuse_mode = _set_fuse_mode

int16_qconfig = dict()

# ---- 相机 view_transformer 量化 stub（注意 camera_net. 前缀）----
int16_qconfig["camera_net.view_transformer.quant_hybird_ref_2d"] = {
    "output": qint16
}
int16_qconfig["camera_net.view_transformer.quant_queries_rebatch_grid"] = {
    "output": qint16
}
int16_qconfig["camera_net.view_transformer.quant_restore_bev_grid"] = {
    "output": qint16
}
int16_qconfig["camera_net.view_transformer.quant_reference_points_rebatch"] = {
    "output": qint16
}

# ---- 检测 decoder（bev_decoders.0）----
int16_qconfig["bev_decoders.0.reference_points"] = {"output": qint16}

# reference_points 的迭代回传（只有 0~4，.5 未使用）
for layer in range(5):
    int16_qconfig[f"bev_decoders.0.decoder.reference_points_add1.{layer}"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.reference_points_add2.{layer}"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.reference_points_cat.{layer}"] = {
        "output": qint16
    }

# cls / reg / decoder 6 层
for layer in range(6):
    int16_qconfig[f"bev_decoders.0.cls_branches.{layer}.0"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.cls_branches.{layer}.3"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.new_reference_points_sigmoids.{layer}"] = {
        "output": qint16
    }
    # 回归输出：仅前 5 层用 qint16，最后一层（layer 5）输出 float32
    int16_qconfig[f"bev_decoders.0.reg_branches.{layer}.4"] = {
        "output": qint16
    }
    # decoder 的 self-attn 残差
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.add_self_attn"] = {
        "output": qint16
    }
    # cross-attn（HorizonMultiScaleDeformableAttention，无 deformable_attention 子层）
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.ca.sampling_offsets"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.ca.mul1"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.ca.add1"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.ca.add_offset"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.ca.output_proj"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.ca.add_res"] = {
        "output": qint16
    }
    # FFN
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.ffn.ffn2"] = {
        "output": qint16
    }
    int16_qconfig[f"bev_decoders.0.decoder.layers.{layer}.ffn.add"] = {
        "output": qint16
    }

int16_qconfig.pop("bev_decoders.0.reg_branches.5.4")

# ---- 相机 encoder（vt_num_layers = 1）----
enc = "camera_net.view_transformer.encoder.layers.0"
# self-attention（HorizonMultiScaleDeformableAttention）
int16_qconfig[f"{enc}.sa.sampling_offsets"] = {"output": qint16}
int16_qconfig[f"{enc}.sa.mul1"] = {"output": qint16}
int16_qconfig[f"{enc}.sa.add1"] = {"output": qint16}
int16_qconfig[f"{enc}.sa.add_offset"] = {"output": qint16}
int16_qconfig[f"{enc}.sa.output_proj"] = {"output": qint16}
int16_qconfig[f"{enc}.sa.add_res"] = {"output": qint16}
# cross-attention（HorizonSpatialCrossAttention → deformable_attention）
da = f"{enc}.ca.deformable_attention"
int16_qconfig[f"{da}.sampling_offsets"] = {"output": qint16}
int16_qconfig[f"{da}.mul1"] = {"output": qint16}
int16_qconfig[f"{da}.add1"] = {"output": qint16}
int16_qconfig[f"{da}.add_offset"] = {"output": qint16}
int16_qconfig[f"{enc}.ca.output_proj"] = {"output": qint16}
int16_qconfig[f"{enc}.ca.add_res"] = {"output": qint16}
# FFN
int16_qconfig[f"{enc}.ffn.ffn2"] = {"output": qint16}
int16_qconfig[f"{enc}.ffn.add"] = {"output": qint16}

# ---- OCC head（bev_decoders.1）：修复地面不平整 / 类别错乱的关键 ----
# 语义 18 类 logits 卷积 + 几何预测输出 Linear，argmax 前保持高精度
int16_qconfig["bev_decoders.1.occ_head.final_conv.0"] = {"output": qint16}
int16_qconfig["bev_decoders.1.occ_head.predicter.2"] = {"output": qint16}

# ---- 不量化的模块 ----
None_qconfig_template = dict()
None_qconfig_template["camera_net.view_transformer.positional_encoding"] = None
for layer in range(6):
    # cls_branches 里的 ReLU（.2 / .5），不参与 activation 量化
    None_qconfig_template[f"bev_decoders.0.cls_branches.{layer}.2"] = {
        "activation": None
    }
    None_qconfig_template[f"bev_decoders.0.cls_branches.{layer}.5"] = {
        "activation": None
    }

q_templates = [
    ModuleNameTemplate({"": qint8}),  # 全局默认 int8
    ModuleNameTemplate(
        int16_qconfig | None_qconfig_template,
        freeze=True,
    ),
    MatmulDtypeTemplate(input_dtypes=[qint8, qint8]),
    ConvDtypeTemplate(input_dtype=qint8, weight_dtype=qint8),
]

# calibration 阶段：int16 输出用 MixObserver（activation=qint16）
mix_qconfig = dict()
for k, _ in int16_qconfig.items():
    mix_qconfig[k] = QConfig(
        activation=FakeQuantize.with_args(
            observer=observer_v2.MixObserver,
            dtype=qint16,
        ),
        weight=FakeQuantize.with_args(
            observer=observer_v2.MinMaxObserver,
            dtype=qint8,
            qscheme=torch.per_channel_symmetric,
            ch_axis=0,
        ),
    )

cali_qconfig_setter = QconfigSetter(
    reference_qconfig=get_qconfig(observer=observer_v2.MSEObserver),
    templates=q_templates,
    enable_optimize=True,
    save_dir=os.path.join(ckpt_dir, "qconfig_setting"),
    custom_qconfig_mapping=mix_qconfig,
)

qat_qconfig_setter = QconfigSetter(
    reference_qconfig=get_qconfig(observer=observer_v2.MinMaxObserver),
    templates=q_templates,
    enable_optimize=True,
    save_dir=os.path.join(ckpt_dir, "qconfig_setting"),
    custom_qconfig_mapping=None,
)

float2calibration = dict(
    type="Float2Calibration",
    convert_mode="jit-strip",
    example_data_loader=calibration_example_data_loader,
    qconfig_setter=cali_qconfig_setter,
)

float2qat = dict(
    type="Float2QAT",
    convert_mode="jit-strip",
    example_data_loader=calibration_example_data_loader,
    qconfig_setter=qat_qconfig_setter,
)


calibration_trainer = dict(
    type="Calibrator",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        qat_mode="fuse_bn",
        converters=[
            dict(
                type="LoadCheckpoint",
                checkpoint_path=os.path.join(
                    ckpt_dir, "float-checkpoint-last.pth.tar"
                ),
                allow_miss=True,
                ignore_extra=True,
                verbose=True,
            ),
            dict(
                type="RepModel2Deploy",
            ),
            float2calibration,
            dict(
                type="FixWeightQScale",
            ),
        ],
    ),
    data_loader=calibration_data_loader,
    batch_processor=calibration_batch_processor,
    num_steps=100,
    device=None,
    callbacks=[
        stat_callback,
        val_callback,
        ckpt_callback,
    ],
    val_metrics=val_metrics,
    log_interval=20,
)


qat_trainer = dict(
    type="distributed_data_parallel_trainer",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        qat_mode="fuse_bn",
        converters=[
            dict(
                type="RepModel2Deploy",
            ),
            float2qat,
            dict(
                type="FixWeightQScale",
            ),
            dict(
                type="LoadCheckpoint",
                checkpoint_path=os.path.join(
                    ckpt_dir, "calibration-checkpoint-last.pth.tar"
                ),
                allow_miss=True,
                ignore_extra=True,
                verbose=True,
            ),
        ],
    ),
    data_loader=data_loader,
    optimizer=dict(
        type=torch.optim.AdamW,
        lr=2e-5,
        weight_decay=1e-3,
    ),
    batch_processor=batch_processor,
    num_epochs=8,
    device=None,
    callbacks=[
        stat_callback,
        loss_show_update,
        dict(
            type="StepDecayLrUpdater",
            lr_decay_id=[3],
            step_log_interval=500,
        ),
        grad_callback,
        val_callback,
        ckpt_callback,
    ],
    train_metrics=dict(
        type="LossShow",
    ),
    val_metrics=val_metrics,
)

compile_dir = os.path.join(ckpt_dir, "compile")
compile_cfg = dict(
    march=march,
    name=task_name,
    hbm=os.path.join(compile_dir, "model.hbm"),
    layer_details=True,
    input_source=[
        "ddr",
    ],
    opt="O2",
)


# predictor
float_predictor = dict(
    type="Predictor",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        converters=[
            dict(
                type="LoadCheckpoint",
                checkpoint_path=os.path.join(
                    ckpt_dir, "float-checkpoint-last.pth.tar"
                ),
                allow_miss=True,
                ignore_extra=True,
                verbose=True,
            ),
        ],
    ),
    data_loader=[val_data_loader],
    batch_processor=val_batch_processor,
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=100,
)

calibration_predictor = dict(
    type="Predictor",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        qat_mode="fuse_bn",
        converters=[
            dict(
                type="RepModel2Deploy",
            ),
            float2qat,
            dict(
                type="LoadCheckpoint",
                checkpoint_path=os.path.join(
                    ckpt_dir, "calibration-checkpoint-last.pth.tar"
                ),
                verbose=True, 
                allow_miss=True,
                ignore_extra=True,
            ),
        ],
    ),
    data_loader=[val_data_loader],
    batch_processor=val_batch_processor,
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=100,
)

qat_predictor = dict(
    type="Predictor",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        qat_mode="fuse_bn",
        converters=[
            dict(
                type="RepModel2Deploy",
            ),
            float2qat,
            dict(
                type="LoadCheckpoint",
                checkpoint_path=os.path.join(
                    ckpt_dir, "qat-checkpoint-last.pth.tar"
                ),
                verbose=True, 
                allow_miss=True,
                ignore_extra=True,
            ),
            dict(type="SetQuantRoundingMode"),
        ],
    ),
    data_loader=[val_data_loader],
    batch_processor=val_batch_processor,
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=100,
)

hbir_deploy_model = copy.deepcopy(model)

hbir_infer_model = dict(
    type="BevFusionHbirInferArgmax",
    ir_model=dict(
        type="HbirModule",
        model_path=os.path.join(ckpt_dir, "quantized.bc"),
    ),
    deploy_model=hbir_deploy_model,
)

int_infer_data_loader = copy.deepcopy(val_data_loader)
int_infer_data_loader["batch_size"] = 1
int_infer_data_loader["shuffle"] = False


int_infer_predictor = dict(
    type="Predictor",
    model=hbir_infer_model,
    data_loader=int_infer_data_loader,
    batch_processor=val_batch_processor,
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=1,
)
infer_transforms = [
    dict(type="Lidar2EgoNuscenes"),
    dict(type="MultiViewsImgResize", size=(512, 960)),
    dict(
        type="MultiViewsImgTransformWrapper",
        transforms=[
            dict(type="PILToTensor"),
            dict(type="Pad", divisor=32),
            dict(type="BgrToYuv444", rgb_input=True),
            dict(type="Normalize", mean=128.0, std=128.0),
        ],
    ),
]

align_bpu_data_loader = dict(
    type=torch.utils.data.DataLoader,
    dataset=dict(
        type="NuscenesFromImageSequence",
        src_data_dir="./data/nuscenes",
        version="v1.0-trainval",
        split_name="val",
        transforms=infer_transforms,
        num_seq=1,
        map_size=None,
        map_path=None,
        with_bev_mask=False,
        with_bev_bboxes=False,
        with_ego_bboxes=True,
        with_lidar_bboxes=use_lidar2img,
        bev_range=point_cloud_range,
        max_dist=40.0,
        need_lidar=True,
        num_sweeps=9,
        load_dim=5,
        use_dim=[0, 1, 2, 3, 4],
        with_ego_occ=with_ego_occ,
        with_lidar_occ=use_lidar2img,
    ),
    batch_size=1,
    shuffle=False,
    num_workers=2,
    pin_memory=True,
    collate_fn=collate_nuscenes_sequencev2,
)


align_bpu_predictor = dict(
    type="Predictor",
    model=hbir_infer_model,
    data_loader=align_bpu_data_loader,
    batch_processor=dict(type="BasicBatchProcessor", need_grad_update=False),
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=1,
)


deploy_model_convert_pipeline = dict(
    type="ModelConvertPipeline",
    qat_mode=qat_mode,
    converters=[
        dict(
            type="Float2QAT",
            convert_mode="jit-strip",
            example_inputs=deploy_inputs,
            qconfig_setter=qat_qconfig_setter,
        ),
    ],
)

real_deploy_model_convert_pipeline = dict(
    type="ModelConvertPipeline",
    qat_mode=qat_mode,
    converters=[
        dict(
            type="RepModel2Deploy",
        ),
        dict(
            type="Float2QAT",
            convert_mode="jit-strip",
            example_inputs=deploy_inputs,
            qconfig_setter=qat_qconfig_setter,
        ),
        dict(
            type="LoadCheckpoint",
            checkpoint_path=os.path.join(
                ckpt_dir, "qat-checkpoint-last.pth.tar"
            ),
            allow_miss=True,
            ignore_extra=True,
            verbose=True,
        ),
        dict(type="SetQuantRoundingMode"),
    ],
)


hbir_exporter = dict(
    type="HbirExporter",
    model=deploy_model,
    model_convert_pipeline=real_deploy_model_convert_pipeline,
    example_inputs=deploy_inputs,
    save_path=ckpt_dir,
    model_name=task_name,
    march=march,
    input_names=list(deploy_inputs.keys()),
)


def resize_homo(homo, scale):
    view = np.eye(4)
    view[0, 0] = scale[1]
    view[1, 1] = scale[0]
    homo = view @ homo
    return homo


def process_img(img_path, resize_size, pad_divisor):
    orig_img = cv2.imread(img_path)
    cv2.cvtColor(orig_img, cv2.COLOR_BGR2RGB, orig_img)
    orig_img = Image.fromarray(orig_img)
    orig_img = pil_to_tensor(orig_img)
    resize_hw = (
        int(resize_size[0]),
        int(resize_size[1]),
    )

    orig_shape = (orig_img.shape[1], orig_img.shape[2])
    resized_img = resize(orig_img, resize_hw)
    resized_img = image_pad(
        resized_img, "chw", None, pad_divisor, 0
    ).unsqueeze(0)
    return resized_img, orig_shape


def prepare_inputs(infer_inputs):
    file_list = list(os.listdir(infer_inputs))
    image_dir_list = list(filter(lambda x: x.endswith(".jpg"), file_list))

    def extract_key(filename):
        match = re.search(r"img(\d+)_", filename)
        if match:
            return int(match.group(1))
        return float("inf")

    image_dir_list.sort(key=extract_key)

    image_dir_list.sort()
    ego2img = np.load(os.path.join(infer_inputs, "ego2img.npy"))
    lidar2img_path = os.path.join(infer_inputs, "lidar2img.npy")
    lidar2img = (
        np.load(lidar2img_path) if os.path.exists(lidar2img_path) else ego2img
    )
    lidar2ego_path = os.path.join(infer_inputs, "lidar2ego.npy")
    frame_inputs = {}
    num_cam = 6

    img_paths = [os.path.join(infer_inputs, p) for p in image_dir_list]
    frame_inputs["img_paths"] = img_paths
    frame_inputs["ego2img"] = ego2img[:num_cam]
    frame_inputs["lidar2img"] = lidar2img[:num_cam]
    frame_inputs["points"] = os.path.join(infer_inputs, "lidar.npy")
    if os.path.exists(lidar2ego_path):
        frame_inputs["lidar2ego"] = np.load(lidar2ego_path)

    return [frame_inputs]


resize_shape = (3, 512, 960)
val_data_shape = (3, 512, 960)
orig_shape = (3, 900, 1600)


def process_inputs(infer_inputs, transforms=None):
    pad_divisor = 32
    resize_size = resize_shape[1:]
    orig_imgs = []
    for i, img_path in enumerate(infer_inputs["img_paths"]):
        img, orig_shape = process_img(img_path, resize_size, pad_divisor)
        orig_imgs.append({"name": i, "img": img})

    input_imgs = []
    for orig_img in orig_imgs:
        input_img = horizon.nn.functional.bgr_to_yuv444(orig_img["img"], True)
        input_imgs.append(input_img)

    input_imgs = torch.cat(input_imgs)
    input_imgs = (input_imgs - 128.0) / 128.0

    lidar2img = infer_inputs["lidar2img"]
    ego2img = infer_inputs["ego2img"]
    point_path = infer_inputs["points"]
    points_np = np.load(point_path)
    if "lidar2ego" in infer_inputs:
        points_np = lidar2ego_nuscenes.transform_points_xyz(
            points_np, infer_inputs["lidar2ego"]
        )
    points = [torch.tensor(points_np)]

    scale = (resize_size[0] / orig_shape[0], resize_size[1] / orig_shape[1])
    lidar2img = resize_homo(lidar2img, scale)
    ego2img = resize_homo(ego2img, scale)
    model_input = {
        "img": input_imgs,
        "points": points,
        "seq_meta": [
            {
                "meta": [
                    {
                        "scene": "test_infer",
                    }
                ],
                "lidar2img": [lidar2img],
                "ego2img": [ego2img],
            }
        ],
    }
    if transforms is not None:
        model_input = transforms(model_input)

    vis_inputs = {}
    vis_inputs["img"] = orig_imgs
    vis_inputs["points"] = points
    vis_inputs["meta"] = {
        "ego2img": ego2img,
        "lidar2img": copy.deepcopy(lidar2img),
    }

    return model_input, vis_inputs


def process_outputs(model_outs, viz_func, vis_inputs):
    occ_raw = model_outs[1][0]
    if isinstance(occ_raw, (list, tuple)):
        occ_raw = occ_raw[0]
    if hasattr(occ_raw, "dim") and occ_raw.dim() >= 5:
        occ_raw = occ_raw.argmax(dim=-1)
    semantics_pred = occ_raw.squeeze().numpy().astype(np.uint8)
    preds = {"bev_det": model_outs[0], "occ_det": semantics_pred}
    viz_func(
        vis_inputs["img"], vis_inputs["points"], preds, vis_inputs["meta"]
    )
    return None


single_hbir_infer_model = copy.deepcopy(hbir_infer_model)
single_hbir_infer_model["deploy_model"]["bev_decoders"][0]["post_process"][
    "score_threshold"
] = 0.1


single_infer_dataset = copy.deepcopy(align_bpu_data_loader["dataset"])
single_infer_dataset["transforms"] = None


def inputs_save_func(data, save_path):
    if os.path.isdir(save_path):
        shutil.rmtree(save_path)
    os.makedirs(save_path, exist_ok=True)
    for image_idx, (img_name, img_data) in enumerate(
        zip(data[0]["img_name"], data[0]["img"])
    ):
        save_name = f"img{image_idx}_{os.path.basename(img_name)}"
        img_data.save(os.path.join(save_path, save_name), "JPEG")

    ego2img_path = os.path.join(save_path, "ego2img.npy")
    np.save(ego2img_path, np.array(data[0]["ego2img"]))
    np.save(os.path.join(save_path, "lidar2img.npy"), data[0]["lidar2img"])
    np.save(os.path.join(save_path, "lidar.npy"), data[0]["points"])
    if "lidar2ego" in data[0]:
        np.save(os.path.join(save_path, "lidar2ego.npy"), data[0]["lidar2ego"])


infer_cfg = dict(
    model=single_hbir_infer_model,
    input_path=f"./demo/{task_name}",
    gen_inputs_cfg=dict(
        dataset=single_infer_dataset,
        sample_idx=[0],
        inputs_save_func=inputs_save_func,
    ),
    process_inputs=process_inputs,
    viz_func=dict(
        type="NuscenesMultitaskViz",
        occ_viz=dict(
            type="OccViz",
            vcs_range=tuple(occ_pc_range),
            vis_bev_2d=True,
        ),
        score_thresh=0.3,
        is_plot=True,
        bev_size=bev_size,
        use_bce=False,
    ),
    process_outputs=process_outputs,
    prepare_inputs=prepare_inputs,
)
calops_cfg = dict(method="hook")
onnx_cfg = dict(
    model=deploy_model,
    stage="qat",
    inputs=deploy_inputs,
    model_convert_pipeline=real_deploy_model_convert_pipeline,
)

# ============ QAT 层敏感度分析（quant_analysis.py）============
# 用 QAT 的 MinMax setter + 训练好的 qat checkpoint，对比 float baseline 逐层算 L1 误差。
qat_analysis_float2qat = dict(
    type="Float2QAT",
    convert_mode="jit-strip",
    example_data_loader=calibration_example_data_loader,   # 仅用来 trace 结构
    qconfig_setter=qat_qconfig_setter,                     # QAT 的 MinMax observer
)

qat_analysis_model_convert_pipeline = dict(
    type="ModelConvertPipeline",
    qat_mode="fuse_bn",
    converters=[
        qat_analysis_float2qat,
        dict(
            type="LoadCheckpoint",
            checkpoint_path=os.path.join(
                ckpt_dir, "qat-checkpoint-last.pth.tar"
            ),
            allow_miss=True,
            ignore_extra=True,
            verbose=True,
        ),
    ],
)

quant_analysis_data_loader = copy.deepcopy(val_data_loader)
quant_analysis_data_loader.pop("sampler")      # 单卡分析，去 DDP sampler
quant_analysis_data_loader["batch_size"] = 1
quant_analysis_data_loader["num_workers"] = 0

quant_analysis_solver = dict(
    type="QuantAnalysis",
    model=copy.deepcopy(model),
    device_id=0,
    dataloader=quant_analysis_data_loader,
    num_steps=100,
    baseline_model_convert_pipeline=float_predictor["model_convert_pipeline"],
    analysis_model_convert_pipeline=qat_analysis_model_convert_pipeline,
    analysis_model_type="fake_quant",
    out_dir=os.path.join(ckpt_dir, "quant_analysis"),
)