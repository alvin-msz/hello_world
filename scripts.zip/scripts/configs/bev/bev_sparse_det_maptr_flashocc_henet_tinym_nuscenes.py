import copy
import math
import os
import shutil
from functools import partial

import cv2
import horizon_plugin_pytorch as horizon
import numpy as np
import torch
from horizon_plugin_pytorch.dtype import qint8, qint16
from horizon_plugin_pytorch.march import March
from horizon_plugin_pytorch.quantization import get_qconfig, observer_v2
from horizon_plugin_pytorch.quantization.qconfig_setter import (
    ConvDtypeTemplate,
    MatmulDtypeTemplate,
    ModuleNameTemplate,
    QconfigSetter,
    SensitivityTemplate,
)
from PIL import Image
from torchvision.transforms.functional import pil_to_tensor

from hat.utils.checkpoint import update_state_dict_by_add_prefix

try:
    from torchvision.transforms.functional_tensor import resize
except ImportError:
    # torchvision 0.18
    from torchvision.transforms._functional_tensor import resize

from collections import OrderedDict

from hat.data.collates.nusc_collates import collate_nuscenes
from hat.data.datasets.nuscenes_dataset import CLASSES
from hat.models.base_modules.attention import MultiheadAttention
from hat.utils.config import ConfigVersion

try:
    from horizon_plugin_pytorch.quantization.qconfig import (
        default_calib_8bit_fake_quant_qconfig,
        default_qat_8bit_fake_quant_qconfig,
    )
    from horizon_plugin_pytorch.quantization.qconfig_template import (
        ConstTensorQuantTemplate,
        DefaultTemplate,
        GEMMToGridSampleGridInt16Template,
        HighPrecisionOutputTemplate,
        TemplateQconfigSetter,
    )

    support_qat_jit_trace = True
except ImportError:
    support_qat_jit_trace = False

VERSION = ConfigVersion.v2
training_step = os.environ.get("HAT_TRAINING_STEP", "float")

task_name = "bev_sparse_det_maptr_flashocc_henet_tinym_nuscenes"
num_classes = 10
batch_size_per_gpu = 4
num_machines = 2
dataloader_workers = 8
device_ids = [0, 1, 2, 3, 4, 5, 6, 7]  # 1 node
ckpt_dir = "./tmp_models/%s" % task_name
pretrain_ckpt_dir = "./tmp_models/henet_tinym_imagenet"

cudnn_benchmark = False
seed = None
log_rank_zero_only = True
bn_kwargs = {}
march = March.NASH_M
convert_mode = "jit-strip"

orig_shape = (3, 900, 1600)
resize_shape = (3, 396, 704)
data_shape = (3, 256, 704)
val_data_shape = (3, 256, 704)

bev_range = (-51.2, -51.2, -5.0, 51.2, 51.2, 3.0)
bev_size = (51.2, 51.2, 3.0)
position_range = (-61.2, -61.2, -10.0, 61.2, 61.2, 10.0)
vt_input_hw = (16, 44)

data_rootdir = "tmp_data/occ3d_nuscenes/bev_occ_new/v1.0-trainval"
meta_rootdir = "./tmp_data/nuscenes/meta"
anchor_file = "./tmp_data/nuscenes/nuscenes_kmeans900.npy"
map_anchor_file = "./tmp_orig_data/nuscenes/kmeans_map_100.npy"

num_epochs = 200
num_steps_per_epoch = int(
    28130 // (len(device_ids) * batch_size_per_gpu * num_machines)
)
num_steps = num_steps_per_epoch * num_epochs

embed_dims = 256
num_groups = 8
num_levels = 1
num_classes = 10
drop_out = 0.1
num_single_frame_decoder = 0  # 1
num_decoder = 6
num_depth_layers = 3
max_num_points = 20
point_cloud_range = [-51.2, -51.2, -5.0, 51.2, 51.2, 3.0]

map_point_cloud_range = [-15.0, -30.0, -10.0, 15.0, 30.0, 10.0]
map_post_center_range = [-20, -35, -20, -35, 20, 35, 20, 35]
bev_h_ = 100
bev_w_ = 50

sd_map_path = "./tmp_data/nuscenes/osm"
camera_input = True
enable_det_head = True
enable_om_head = True
enable_occ_head = True



det_head = dict(
    type="SparseBEVOEHead",
    enable_dn=True,
    level_index=[2],
    cls_threshold_to_reg=0.05,
    instance_bank=dict(
        type="MemoryBankOE",
        num_anchor=384,
        embed_dims=embed_dims,
        num_memory_instances=384,
        anchor=anchor_file,
        num_temp_instances=128,
        confidence_decay=0.6,
    ),
    anchor_encoder=dict(
        type="SparseBEVOEEncoder",
        pos_embed_dims=128,
        size_embed_dims=32,
        yaw_embed_dims=32,
        vel_embed_dims=64,
        vel_dims=3,
    ),
    num_single_frame_decoder=num_single_frame_decoder,
    operation_order=[
        "deformable",
        "ffn",
        "norm",
        "refine",
    ]
    * num_single_frame_decoder
    + [
        "temp_interaction",
        "interaction",
        "norm",
        "deformable",
        "ffn",
        "norm",
        "refine",
    ]
    * (num_decoder - num_single_frame_decoder),
    ffn=dict(
        type="AsymmetricFFNOE",
        in_channels=embed_dims * 2,
        pre_norm=True,
        embed_dims=embed_dims,
        feedforward_channels=embed_dims * 4,
        num_fcs=2,
        ffn_drop=drop_out,
    ),
    deformable_model=dict(
        type="DeformableFeatureAggregationOE",
        embed_dims=embed_dims,
        num_groups=num_groups,
        num_levels=num_levels,
        num_cams=6,
        attn_drop=0.15,
        use_camera_embed=True,
        residual_mode="cat",
        kps_generator=dict(
            type="SparseBEVOEKeyPointsGenerator",
            num_pts=8,
        ),
    ),
    refine_layer=dict(
        type="SparseBEVOERefinementModule",
        embed_dims=embed_dims,
        num_cls=num_classes,
        refine_yaw=True,
    ),
    target=dict(
        type="SparseBEVOETarget",
        num_dn_groups=5,
        num_temp_dn_groups=3,
        dn_noise_scale=[2.0] * 3 + [0.5] * 7,
        max_dn_gt=32,
        add_neg_dn=True,
        cls_weight=2.0,
        box_weight=0.25,
        reg_weights=[2.0] * 3 + [0.5] * 3 + [0.0] * 4,
        cls_wise_reg_weights={
            CLASSES.index("traffic_cone"): [
                2.0,
                2.0,
                2.0,
                1.0,
                1.0,
                1.0,
                0.0,
                0.0,
                1.0,
                1.0,
            ],
        },
    ),
    cls_allow_reverse=[CLASSES.index("barrier")],
    loss_cls=dict(
        type="FocalLoss",
        loss_name="cls",
        num_classes=num_classes + 1,
        gamma=2.0,
        alpha=0.25,
        loss_weight=2.0,
    ),
    loss_reg=dict(type="L1Loss", loss_weight=0.25),
    loss_cns=dict(type="CrossEntropyLoss", use_sigmoid=True),
    loss_yns=dict(type="GaussianFocalLoss"),
    decoder=dict(type="SparseBEVOEDecoder"),
    reg_weights=[2.0] * 3 + [1.0] * 7,
)


def get_grid_quant_scale(grid_shape, view_shape):
    max_coord = max(*grid_shape, *view_shape)
    coord_bit_num = math.ceil(math.log(max_coord + 1, 2))
    coord_shift = 15 - coord_bit_num
    coord_shift = max(min(coord_shift, 8), 0)
    grid_quant_scale = 1.0 / (1 << coord_shift)
    return grid_quant_scale


occ_depth = 45
occ_grid_size = (128, 128)
view_shape = [data_shape[1] / 32, data_shape[2] / 32]
vt_input_hw = [int(view_shape[0]), int(view_shape[1])]
depthview_shape = [6 * occ_depth, view_shape[0] * view_shape[1]]
featview_shape = [view_shape[0] * 6, view_shape[1]]
grid_quant_scale = get_grid_quant_scale(occ_grid_size, featview_shape)
depth_grid_quant_scale = get_grid_quant_scale(occ_grid_size, depthview_shape)
num_classes_occ = 18
occ_num_points = 10
occ_bev_size = (40, 40, 0.625)
occ_point_cloud_range = (-40.0, -40.0, -1.0, 40.0, 40.0, 5.4)
occ3d_seg_class = [
    "others",
    "barrier",
    "bicycle",
    "bus",
    "car",
    "construction_vehicle",
    "motorcycle",
    "pedestrian",
    "traffic_cone",
    "trailer",
    "truck",
    "driveable_surface",
    "other_flat",
    "sidewalk",
    "terrain",
    "manmade",
    "vegetation",
]
occ_head = dict(
    type="FlashOccHead",
    bev_feat_index=-1,
    bev_upscale=2,
    view_transformer=dict(
        type="LSSTransformer",
        in_channels=256,
        feat_channels=64,
        z_range=(-1.0, 5.4),
        depth=occ_depth,
        num_points=occ_num_points,
        bev_size=occ_bev_size,
        grid_size=occ_grid_size,
        num_views=6,
        grid_quant_scale=grid_quant_scale,
        depth_grid_quant_scale=depth_grid_quant_scale,
        homo_key="lidar2img",
    ),
    bev_encoder=dict(
        type="BevEncoder",
        backbone=dict(
            type="HENet",
            in_channels=64,
            block_nums=[4, 3, 8, 6],
            embed_dims=[64, 128, 192, 384],
            attention_block_num=[0, 0, 0, 0],
            mlp_ratios=[2, 2, 2, 3],
            mlp_ratio_attn=2,
            act_layer=["nn.GELU", "nn.GELU", "nn.GELU", "nn.GELU"],
            use_layer_scale=[True, True, True, True],
            layer_scale_init_value=1e-5,
            num_classes=1000,
            include_top=False,
            extra_act=[False, False, False, False],
            final_expand_channel=0,
            feature_mix_channel=1024,
            block_cls=["GroupDWCB", "GroupDWCB", "AltDWCB", "DWCB"],
            down_cls=["S2DDown", "S2DDown", "S2DDown", "None"],
            patch_embed="origin",
            quant_input=False,
        ),
        neck=dict(
            type="BiFPN",
            in_strides=[2, 4, 8, 16, 32],
            out_strides=[2, 4, 8, 16, 32],
            stride2channels=dict({2: 64, 4: 64, 8: 128, 16: 192, 32: 384}),
            out_channels=48,
            num_outs=5,
            stack=3,
            start_level=0,
            end_level=-1,
            fpn_name="bifpn_sum",
            upsample_type="function",
            use_fx=False,
        ),
    ),
    bev_decoder=dict(
        type="FlashOccDetDecoder",
        use_mask=True,
        num_classes=num_classes_occ,
        occ_head=dict(
            type="BEVOCCHead2D",
            in_dim=48,
            out_dim=128,
            Dz=16,
            num_classes=num_classes_occ,
            use_predicter=True,
            use_upsample=True,
        ),
        loss_occ=dict(
            type="CrossEntropyLoss",
            use_sigmoid=False,
            ignore_index=255,
            loss_weight=12.0,
        ),
    ),
)

fixed_ptsnum_per_gt_line = 20  # now only support fixed_pts > 0
fixed_ptsnum_per_pred_line = 20
om_num_anchor = 100
map_classes = ["divider", "ped_crossing", "boundary"]
eval_use_same_gt_sample_num_flag = True
num_map_classes = len(map_classes)

map_aux_seg_cfg = dict(
    use_aux_seg=True,
    bev_seg=False,
    pv_seg=True,
    dense_depth=False,
    seg_classes=1,
    feat_down_sample=[(1, 8), (2, 16), (3, 32)],
    pv_thickness=1,
)

om_head = dict(
    type="SparseMapPerceptionDecoder",
    embed_dims=embed_dims,
    num_cam=6,
    num_vec_one2one=om_num_anchor,
    num_vec_one2many=0,
    k_one2many=0,
    num_pts_per_vec=fixed_ptsnum_per_pred_line,
    transform_method="minmax",
    is_deploy=False,
    decoder=dict(
        type="SparseOMOEHead",
        feat_indices=[2],
        num_anchor=om_num_anchor,
        num_pts_per_vec=fixed_ptsnum_per_pred_line,
        num_views=6,
        projection_mat_key="lidar2img",
        anchor_encoder=dict(
            type="SparseOEPoint3DEncoder",
            embed_dims=embed_dims,
            input_dim=fixed_ptsnum_per_pred_line * 2,
        ),
        instance_bank=dict(
            type="InstanceBankOE",
            num_anchor=om_num_anchor,
            embed_dims=embed_dims,
            anchor=map_anchor_file,
            num_temp_instances=0,
            confidence_decay=0.6,
            anchor_grad=True,
            feat_grad=True,
        ),
        instance_interaction=dict(
            type=MultiheadAttention,
            embed_dim=embed_dims,
            num_heads=num_groups,
            batch_first=True,
            attn_drop=drop_out,
            proj_drop=drop_out,
        ),
        norm_layer=dict(
            type=torch.nn.LayerNorm,
            normalized_shape=embed_dims,
        ),
        ffn=dict(
            type="AsymmetricFFNOE",
            in_channels=embed_dims * 2,
            pre_norm=True,
            embed_dims=embed_dims,
            num_fcs=2,
            ffn_drop=0.1,
            feedforward_channels=embed_dims * 4,
        ),
        deformable_model=dict(
            type="DeformableFeatureAggregationOEv2",
            embed_dims=embed_dims,
            num_groups=num_groups,
            num_levels=num_levels,
            num_cams=6,
            attn_drop=0.15,
            residual_mode="cat",
            use_camera_embed=True,
            grid_align_num=4,
            kps_generator=dict(
                type="SparsePoint3DKeyPointsGenerator",
                embed_dims=embed_dims,
                num_sample=fixed_ptsnum_per_pred_line,
                num_learnable_pts=2,
                fix_height=(0, 0.5, -0.5),
                ground_height=-1.84023,  # ground height in lidar frame
            ),
        ),
        refine_layer=dict(
            type="SparsePoint3DRefinementModule",
            embed_dims=embed_dims,
            num_sample=fixed_ptsnum_per_pred_line,
            coords_dim=2,
            num_cls=len(map_classes),
            with_cls_branch=True,
        ),
        num_decoder=num_decoder,
        num_single_frame_decoder=num_single_frame_decoder,
        operation_order=[
            "interaction",
            "norm",
            "deformable",
            "ffn",
            "norm",
            "refine",
        ]
        * num_single_frame_decoder
        + [
            "interaction",
            "norm",
            "deformable",
            "ffn",
            "norm",
            "refine",
        ]
        * (num_decoder - num_single_frame_decoder),
    ),
    aux_seg=map_aux_seg_cfg,
    criterion=dict(
        type="MapTRCriterion",
        dir_interval=1,
        num_classes=num_map_classes,
        code_weights=[1.0, 1.0, 1.0, 1.0],
        sync_cls_avg_factor=True,
        pc_range=map_point_cloud_range,
        num_pts_per_vec=fixed_ptsnum_per_pred_line,  # one bbox
        num_pts_per_gt_vec=fixed_ptsnum_per_gt_line,
        gt_shift_pts_pattern="sparsedrive",
        aux_seg=map_aux_seg_cfg,
        pred_absolute_points=True,
        assigner=dict(
            type="MapTRAssigner",
            cls_cost=dict(type="FocalLossCost", weight=1.0),
            pts_cost=dict(type="OrderedPtsL1Cost", weight=0.5, beta=0.01),
            pc_range=map_point_cloud_range,
            pred_absolute_points=True,
        ),
        loss_cls=dict(
            type="FocalLoss",
            loss_name="cls",
            num_classes=num_map_classes + 1,
            alpha=0.25,
            gamma=2.0,
            loss_weight=1.0,
            reduction="mean",
        ),
        loss_pts=dict(type="PtsL1Loss", loss_weight=0.5, beta=0.01),
        loss_dir=dict(type="PtsDirCosLoss", loss_weight=0),
        loss_pv_seg=dict(type="SimpleLoss", pos_weight=1.0, loss_weight=2.0),
    ),
    post_process=dict(
        type="MapTRPostProcess",
        pc_range=map_point_cloud_range,
        post_center_range=map_post_center_range,
        max_num=om_num_anchor,
        num_classes=num_map_classes,
        pred_absolute_points=True,
    ),
)
task_heads = OrderedDict()
if enable_det_head:
    task_heads["det"] = det_head
if enable_om_head:
    task_heads["om"] = om_head
if enable_occ_head:
    task_heads["occ"] = occ_head


model = dict(
    type="SparseBevFusionMultitaskOE",
    compiler_model=False,
    backbone=dict(
        type="HENet",
        in_channels=3,
        block_nums=[4, 3, 8, 6],
        embed_dims=[64, 128, 192, 384],
        attention_block_num=[0, 0, 0, 0],
        mlp_ratios=[2, 2, 2, 3],
        mlp_ratio_attn=2,
        act_layer=["nn.GELU", "nn.GELU", "nn.GELU", "nn.GELU"],
        use_layer_scale=[True, True, True, True],
        layer_scale_init_value=1e-5,
        num_classes=1000,
        include_top=False,
        extra_act=[False, False, False, False],
        final_expand_channel=0,
        feature_mix_channel=1024,
        block_cls=["GroupDWCB", "GroupDWCB", "AltDWCB", "DWCB"],
        down_cls=["S2DDown", "S2DDown", "S2DDown", "None"],
        patch_embed="origin",
    ),
    neck=dict(
        type="MMFPN",
        in_strides=[2, 4, 8, 16, 32],
        in_channels=[64, 64, 128, 192, 384],
        fix_out_channel=256,
        out_strides=[4, 8, 16, 32],
    ),
    depth_branch=dict(  # for auxiliary supervision only
        type="DenseDepthNetOE",
        embed_dims=embed_dims,
        num_depth_layers=num_depth_layers,
        loss_weight=0.2,
    ),
    head=task_heads,
)


deploy_model = copy.deepcopy(model)
deploy_model["compiler_model"] = True
if "om" in deploy_model["head"]:
    deploy_model["head"]["om"]["is_deploy"] = True
if "det" in deploy_model["head"]:
    deploy_model["head"]["det"]["enable_dn"] = False
if "om" in deploy_model["head"]:
    # deploy_model["head"]["occ"]["compile_model"] = True
    deploy_model["head"]["occ"]["bev_decoder"]["is_compile"] = True


def get_deploy_input():
    inputs = {
        "img": torch.randn((6, 3, 256, 704)),
        "projection_mat": torch.randn((6, 4, 4)),
        "cached_anchor": torch.randn((1, 384, 11)),
        "cached_feature": torch.randn((1, 384, 256)),
        "points0": torch.randn(
            (occ_num_points, 128, 128, 2),
        ),
        "points1": torch.randn(
            (occ_num_points, 128, 128, 2),
        ),
    }
    return inputs


deploy_inputs = get_deploy_input()

train_dataset = dict(
    type="NuscenesSparseMapDataset",
    data_path=os.path.join(data_rootdir, "train_lmdb"),
    map_path=meta_rootdir,
    pc_range=map_point_cloud_range,
    test_mode=False,
    bev_size=(bev_h_, bev_w_),
    fixed_ptsnum_per_line=fixed_ptsnum_per_gt_line,
    padding_value=-10000,
    map_classes=map_classes,
    aux_seg=map_aux_seg_cfg,
    with_bev_bboxes=False,
    with_ego_bboxes=False,
    with_bev_mask=False,
    with_lidar_bboxes=True,
    need_lidar=True,
    num_split=2,
    num_sweeps=9,
    load_dim=5,
    use_dim=[0, 1, 2, 3, 4],
    use_lidar_gt=True,
    with_ego_occ=False,
    with_lidar_occ=True,
    filter_empty_gt=False,
    transforms=[
        dict(type="MultiViewsImgResize", scales=(0.40, 0.47)),
        dict(type="MultiViewsImgCrop", size=(256, 704), random=False),
        dict(type="MultiViewsImgFlip"),
        dict(type="MultiViewsImgRotate", rot=(-5.4, 5.4)),
        dict(type="BevBBoxRotation", rotation_3d_range=(-0.3925, 0.3925)),
        dict(type="MultiViewsPhotoMetricDistortion", use_pil=False),
        dict(
            type="MultiViewsGridMask",
            use_h=True,
            use_w=True,
            rotate=1,
            offset=False,
            ratio=0.5,
            mode=1,
            prob=0.7,
        ),
        dict(
            type="MultiViewsImgTransformWrapper",
            transforms=[
                dict(type="PILToTensor"),
                dict(type="BgrToYuv444", rgb_input=True),
                dict(type="Normalize", mean=128, std=128),
            ],
        ),
    ],
)

data_loader = dict(
    type=torch.utils.data.DataLoader,
    dataset=train_dataset,
    batch_sampler=dict(
        type="DistStreamBatchSampler",
        batch_size=batch_size_per_gpu,
        dataset=train_dataset,
        keep_consistent_seq_aug=True,
        skip_prob=0.0,
        sequence_flip_prob=0.0,
    ),
    num_workers=dataloader_workers,
    pin_memory=True,
    collate_fn=collate_nuscenes,
)

val_data_loader = dict(
    type=torch.utils.data.DataLoader,
    dataset=dict(
        type="NuscenesSparseMapDataset",
        data_path=os.path.join(data_rootdir, "val_lmdb"),
        map_path=meta_rootdir,
        pc_range=map_point_cloud_range,
        test_mode=True,
        bev_size=(bev_h_, bev_w_),
        fixed_ptsnum_per_line=fixed_ptsnum_per_gt_line,
        padding_value=-10000,
        map_classes=map_classes,
        with_bev_bboxes=False,
        with_ego_bboxes=False,
        with_bev_mask=False,
        with_lidar_bboxes=True,
        need_lidar=True,
        num_split=2,
        num_sweeps=9,
        load_dim=5,
        use_dim=[0, 1, 2, 3, 4],
        use_lidar_gt=True,
        with_ego_occ=False,
        with_lidar_occ=True,
        transforms=[
            dict(type="MultiViewsImgResize", size=(396, 704)),
            dict(type="MultiViewsImgCrop", size=(256, 704)),
            dict(
                type="MultiViewsImgTransformWrapper",
                transforms=[
                    dict(type="PILToTensor"),
                    dict(type="BgrToYuv444", rgb_input=True),
                    dict(type="Normalize", mean=128, std=128),
                ],
            ),
        ],
    ),
    # sampler=dict(type=torch.utils.data.DistributedSampler),
    batch_size=1,
    shuffle=False,
    num_workers=4,
    pin_memory=True,
    collate_fn=collate_nuscenes,
)


def loss_collector(outputs: dict):
    losses = []
    for _, loss in outputs.items():
        losses.append(loss)
    return losses


def update_loss(metrics, batch, model_outs):
    for metric in metrics:
        metric.update(model_outs)


loss_show_update = dict(
    type="MetricUpdater",
    metric_update_func=update_loss,
    step_log_freq=50,
    epoch_log_freq=1,
    log_prefix="loss_" + task_name,
)

batch_processor = dict(
    type="MultiBatchProcessor",
    need_grad_update=True,
    loss_collector=loss_collector,
    # grad_scaler=torch.cuda.amp.GradScaler(init_scale=32.0),
    enable_amp=False,
)

val_batch_processor = dict(
    type="MultiBatchProcessor",
    need_grad_update=False,
)


def update_metric(metrics, batch, model_outs):
    for _, metric in enumerate(metrics):
        if metric.name == "MeanIOU":
            k = "occ"
        elif metric.name == "NuscenesMetric":
            k = "det"
        elif metric.name == "NuscenesMapMetric":
            k = "om"
        if k == "det" or k == "om":
            metric.update(batch, model_outs[k])
        else:
            gt_semantics = batch["gt_occ_info"]["voxel_semantics"][0].squeeze()
            semantics_pred = model_outs[k][0].squeeze()

            mask = batch["gt_occ_info"]["mask_camera"][0].squeeze()
            masked_semantics_gt = gt_semantics[mask]
            masked_semantics_pred = semantics_pred[mask]
            results = {
                "label": masked_semantics_gt.reshape(-1),
                "preds": masked_semantics_pred.reshape(-1),
            }
            metric.update(**results)


val_metric_updater = dict(
    type="MetricUpdater",
    metric_update_func=update_metric,
    step_log_freq=10000,
    epoch_log_freq=1,
    log_prefix="Validation " + task_name,
)

stat_callback = dict(
    type="StatsMonitor",
    log_freq=100,
    batch_size=batch_size_per_gpu,
)

grad_callback = dict(
    type="GradClip",
    # max_norm=1.0,
    max_norm=25,
    norm_type=2,
)

ckpt_callback = dict(
    type="Checkpoint",
    save_dir=ckpt_dir,
    name_prefix=training_step + "-",
    interval_by="step",
    save_interval=num_steps_per_epoch * 10,
    strict_match=False,
    mode="max",
)

val_callback = dict(
    type="Validation",
    data_loader=val_data_loader,
    batch_processor=val_batch_processor,
    callbacks=[val_metric_updater],
    val_model=None,
    init_with_train_model=False,
    val_interval=num_steps_per_epoch * 10,
    interval_by="step",
    val_on_train_end=True,
    log_interval=500,
)

val_nuscenes_metric = dict(
    type="NuscenesMetric",
    data_root=meta_rootdir,
    use_lidar=True,
    trans_lidar_dim=True,
    trans_lidar_rot=False,
    use_ddp=True,
    lidar_key="sensor2ego",
    version="v1.0-trainval",
    save_prefix="./WORKSPACE/results" + task_name,
)
val_map_metric = dict(
    type="NuscenesMapMetric",
    classes=map_classes,
    save_prefix="./WORKSPACE/results" + task_name,
    fixed_ptsnum_per_line=fixed_ptsnum_per_gt_line,
    pc_range=map_point_cloud_range,
    metric="chamfer",
    eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
)
val_occ_metric = dict(
    type="MeanIOU",
    seg_class=occ3d_seg_class,
    ignore_index=17,
)

val_metrics = []
if enable_det_head:
    val_metrics.append(val_nuscenes_metric)
if enable_om_head:
    val_metrics.append(val_map_metric)
if enable_occ_head:
    val_metrics.append(val_occ_metric)


float_checkpoint = os.path.join(
    ckpt_dir, "float-checkpoint-best.pth.tar"
)
float_trainer = dict(
    type="distributed_data_parallel_trainer",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        qat_mode="fuse_bn",
        converters=[
            dict(
                type="LoadCheckpoint",
                checkpoint_path=os.path.join(
                    pretrain_ckpt_dir, "float-checkpoint-best.pth.tar"
                ),
                allow_miss=True,
                ignore_extra=True,
                ignore_tensor_shape=True,
                verbose=True,
            ),
        ],
    ),
    data_loader=data_loader,
    optimizer=dict(
        type=torch.optim.AdamW,
        params={
            # "backbone": dict(lr=1e-3),
            "backbone": dict(lr=3e-4),
        },
        # eps=1e-8,
        # betas=(0.9, 0.999),
        lr=3e-4,
        weight_decay=0.001,
    ),
    batch_processor=batch_processor,
    num_steps=num_steps,
    stop_by="step",
    # num_epochs=100,
    device=None,
    callbacks=[
        stat_callback,
        loss_show_update,
        dict(type="ExponentialMovingAverage"),
        grad_callback,
        dict(
            type="CosineAnnealingLrUpdater",
            warmup_len=500,
            warmup_by="step",
            warmup_lr_ratio=1.0 / 3,
            step_log_interval=500,
            update_by="step",
            min_lr_ratio=1e-3,
        ),
        val_callback,
        ckpt_callback,
    ],
    train_metrics=dict(
        type="LossShow",
    ),
    sync_bn=True,
    val_metrics=val_metrics,
)
sensitivity_templates = []
table_dir = os.path.join(ckpt_dir, "quant_analysis")

def load_ckpt(ckpt):
    if ckpt.startswith("http"):
        import io

        import requests

        ckpt = requests.get(ckpt).content
        ckpt = torch.load(io.BytesIO(ckpt), map_location="cpu", weights_only=False)
    else:
        ckpt = torch.load(ckpt, map_location="cpu", weights_only=False)
    return ckpt



sensitive_setting_dict = {
    "output_det.classification_L1_sensitive_ops.pt": 20,
    "output_det.prediction_L1_sensitive_ops.pt": 20,
    "output_det.quality_L1_sensitive_ops.pt": 10,
    "output_om.all_pts_preds_L1_sensitive_ops.pt": 5,
    "output_om.all_bbox_preds_L1_sensitive_ops.pt": 5,
    "output_om.all_cls_scores_L1_sensitive_ops.pt": 5,
}
for k, v in sensitive_setting_dict.items():
    sensitive_table = load_ckpt(os.path.join(table_dir, k))
    sensitivity_templates.append(
        SensitivityTemplate(
            sensitive_table,
            topk_or_ratio=v,
        )
    )
      
backbone = ["backbone"]
int16_max_point_muls = [
    f"head.det.layers.{layer}.point_mul" for layer in range(3, 39, 7)
] + [f"head.om.decoder.layers.{layer}.point_mul" for layer in range(2, 33, 6)]
int16_max_reciprocal_op = [
    f"head.det.layers.{layer}.reciprocal_op" for layer in range(3, 39, 7)
]
int16_add_ops = [f"head.det.layers.{layer}.add2" for layer in range(6, 35, 7)]
# int16_add_ops += [f"head.om.layers.{layer}._generated_add_1" for layer in range(5, 35, 6)]
float32_ops = [
    f"head.det.layers.{layer}.cls_layers" for layer in range(6, 35, 7) # 6, 13, 20, 27, 34
] + [f"head.det.layers.{layer}.quality_layers" for layer in range(6, 35, 7)]
q_template = [ 
    ModuleNameTemplate({"": qint8}),
    MatmulDtypeTemplate(  
        input_dtypes=[qint8, qint8],
        # prefix=[""],  
    ),
    ConvDtypeTemplate( 
        input_dtype=qint8,
        weight_dtype=qint8, 
        # prefix=[""],  
    ),
    ModuleNameTemplate(
        {
            m: {"dtype": qint8, "threshold": 1.0} for m in ["backbone.quant"]
        }, 
        
    ),
    ModuleNameTemplate(
        {
            m: {"dtype": qint16, "threshold": 1.1}
            for m in int16_max_point_muls
        }, 
      
    ),
    ModuleNameTemplate(
        {
            m: {"dtype": qint16, "threshold": 10}
            for m in int16_max_reciprocal_op
        }, 
       
    ),
    ModuleNameTemplate(
        {
            m: {"dtype": qint16, "threshold": 50}
            for m in ["head.det.fc_after"]
        }, 
       
    ),
    ModuleNameTemplate(
        {
            m: {"dtype": qint16, "threshold": 10}
            for m in ["head.det.fc_before"]
        },  
    ),
    ModuleNameTemplate(
        {
            m: {"input": [qint16, qint16], "output": qint16}
            for m in int16_add_ops
        }, 
        
    ),
    *sensitivity_templates,
    ModuleNameTemplate(
        {m: None for m in float32_ops},  # quant int8，固定 scale 方式 1
        freeze=True,
    ),  
    # ModuleNameTemplate(
    #     {   
    #     #  "head.det.layers.41.add2": {"input": [qint16, qint16], "output": torch.float32},
    #         "head.om.decoder.layers.35._generated_add_1": {"input": [qint16, qint16], "output": torch.float32},
    #     },  
    #     freeze=True,
    # ),  
    # 精度调优
    # 模版
    # LoadFromFileTemplate(
    #         load_dir=xxx,
    #         exclude=share_modules
    #     ),
]

calibration_qconfig_setter = QconfigSetter(
    reference_qconfig=get_qconfig(  # 1. 主要用于获取 observer
        # observer=(observer_v2.MSEObserver)
        observer=(observer_v2.HistogramObserver)
    ),
    templates=q_template,
    enable_optimize=True, 
    save_dir=os.path.join(
        ckpt_dir, "./qconfig_setting"
    ), 
    custom_qconfig_mapping=None,  
)
qat_qconfig_setter = QconfigSetter(
    reference_qconfig=get_qconfig(  
        observer=(observer_v2.MinMaxObserver), fix_scale=True
    ),
    templates=q_template,
    enable_optimize=True,  
    save_dir=os.path.join(
        ckpt_dir, "./qconfig_setting"
    ), 
    custom_qconfig_mapping=None,  
)

calibration_data_loader = copy.deepcopy(data_loader)
calibration_data_loader["dataset"]["transforms"] = val_data_loader["dataset"][
    "transforms"
]
calibration_batch_processor = copy.deepcopy(val_batch_processor)
calibration_step = 50
example_inputs = {
    "img": torch.randn((6, 3, 256, 704)),
    "lidar2global": torch.randn((1, 4, 4)),
    "lidar2img": torch.randn((6, 4, 4)),
}
float2qat = dict(
    type="Float2QAT",
    convert_mode=convert_mode,
    example_inputs=example_inputs,
    state="train",
    qconfig_setter=qat_qconfig_setter,
)

calibration_trainer = dict(
    type="Calibrator",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        qat_mode="fuse_bn",
        converters=[
            dict(
                type="LoadCheckpoint",
                checkpoint_path=float_checkpoint,
                allow_miss=True,
                ignore_extra=True,
                verbose=True,
                load_ema_model=True,
            ),
            dict(
                type="Float2Calibration",
                convert_mode=convert_mode,
                example_inputs=example_inputs,
                qconfig_setter=calibration_qconfig_setter,
            ),
        ],
    ),
    data_loader=calibration_data_loader,
    batch_processor=calibration_batch_processor,
    num_steps=100,  # calibration_step,
    device=None,
    callbacks=[
        ckpt_callback,
        val_callback,
    ],
    log_interval=calibration_step / 10,
    val_metrics=val_metrics,
)

bn_callback = dict(
    type="FreezeBNStatistics",
)


calibration_checkpoint_path = os.path.join(ckpt_dir, "calibration-checkpoint-last.pth.tar")

compile_dir = os.path.join(ckpt_dir, "compile")
compile_cfg = dict(
    march=march,
    name=task_name + "_model",
    out_dir=compile_dir,
    hbm=os.path.join(compile_dir, "model.hbm"),
    layer_details=True,
    debug=True,
    input_source="pyramid, ddr, ddr, ddr, ddr, ddr,",
    opt="O2",
    split_dim=dict(
        inputs={
            "0": [0, 6],
        }
    ),
    enable_vpu=True
)

float_predictor = dict(
    type="Predictor",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        converters=[
            dict(
                type="LoadCheckpoint",
                checkpoint_path=float_checkpoint,
                allow_miss=True,
                ignore_extra=True,
                verbose=True,
                load_ema_model=True,
            ),
        ],
    ),
    data_loader=[val_data_loader],
    batch_processor=val_batch_processor,
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=50,
)

calibration_predictor = dict(
    type="Predictor",
    model=model,
    model_convert_pipeline=dict(
        type="ModelConvertPipeline",
        qat_mode="fuse_bn",
        converters=[
            dict(
                type="Float2QAT",
                convert_mode=convert_mode,
                example_inputs=example_inputs,
                state="val",
                qconfig_setter=qat_qconfig_setter,
            ),
            dict(
                type="LoadCheckpoint",
                checkpoint_path=calibration_checkpoint_path,
                ignore_extra=True,
                allow_miss=True,
                verbose=True
                
            ),
        ],
    ),
    data_loader=[val_data_loader],
    batch_processor=val_batch_processor,
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=50,
)

deploy_model_convert_pipeline = dict(
    type="ModelConvertPipeline",
    qat_mode="fuse_bn",
    converters=[
        dict(
            type="Float2QAT",
            convert_mode=convert_mode,
            example_inputs=deploy_inputs,
            state="val",
            qconfig_setter=qat_qconfig_setter,
        ),
    ],
)
first_frame_input = {
    "cached_anchor": torch.zeros((1, 384, 11)),
    "cached_feature": torch.zeros((1, 384, 256)),
    "cached_confidence": torch.zeros((1, 384)),
    "mask": torch.zeros((1)).bool(),
}

real_deploy_model_convert_pipeline = dict(
    type="ModelConvertPipeline",
    qat_mode="fuse_bn",
    converters=[
        dict(
            type="Float2QAT",
            convert_mode=convert_mode,
            example_inputs=deploy_inputs,
            state="eval",
            qconfig_setter=qat_qconfig_setter,
        ),
        dict(
            type="LoadCheckpoint",
            checkpoint_path=calibration_checkpoint_path,
            allow_miss=True,
            ignore_extra=True,
            verbose=True,
        ),
    ],
)
output_names = []
if enable_det_head:
    det_outs = [
        "det.classification",
        "det.prediction",
        "det.quality",
        "det.feature"
    ]
    output_names.extend(det_outs)
if enable_om_head:
    om_outs = [
        "om.classification",
        "om.prediction",
    ]
    output_names.extend(om_outs)
if enable_occ_head:
    occ_outs = [
        "occ",
    ]
    output_names.extend(occ_outs)

hbir_exporter = dict(
    type="HbirExporter",
    model=deploy_model,
    model_convert_pipeline=real_deploy_model_convert_pipeline,
    example_inputs=deploy_inputs,
    save_path=ckpt_dir,
    model_name=task_name,
    march=march,
    input_names=list(deploy_inputs.keys()),
    output_names=output_names,
    enable_vpu=True,
)


vt_input_hw = [int(view_shape[0]), int(view_shape[1])]
hbm_host = "10.103.110.34"
hbir_infer_model = dict(
    type="SparseBEVFusionMultitaskOEIrInfer",
    first_frame_input=first_frame_input,
    projection_mat_key="lidar2img",
    global_mat_key="lidar2global",
    ir_model = dict(
        type="HbirModule", 
        model_path=os.path.join(ckpt_dir, "quantized.bc")
    ),
    # ir_model=dict(
    #     type="HbmModule", 
    #     host="10.35.72.2",
    #     model_path=os.path.join(ckpt_dir, "compile", "model.hbm")
    # ),
    deploy_model=deploy_model,
    # model_converter_pipeline=real_deploy_model_convert_pipeline,
    det_decoder=dict(type="SparseBEVOEDecoder"),
    use_memory_bank=True,
    confidence_decay=0.6,
    num_temp_instances=128,
    num_memory_instances=384,
    vt_input_hw=vt_input_hw,
)

int_infer_data_loader = copy.deepcopy(val_data_loader)
int_infer_data_loader["batch_size"] = 1

infer_transforms = [
    dict(type="MultiViewsImgResize", size=(396, 704)),
    dict(type="MultiViewsImgCrop", size=(256, 704)),
    dict(
        type="MultiViewsImgTransformWrapper",
        transforms=[
            dict(type="PILToTensor"),
            dict(type="BgrToYuv444", rgb_input=True),
            dict(type="Normalize", mean=128, std=128),
        ],
    ),
]


int_infer_predictor = dict(
    type="Predictor",
    model=hbir_infer_model,
    data_loader=int_infer_data_loader,
    batch_processor=val_batch_processor,
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=1,
)
hbm_data_loader = copy.deepcopy(val_data_loader)
hbm_data_loader["batch_size"] = 1
hbm_data_loader["dataset"]["transforms"] =  [
    dict(type="MultiViewsImgResize", size=(396, 704)),
    dict(type="MultiViewsImgCrop", size=(256, 704)),
    dict(
        type="MultiViewsImgTransformWrapper",
        transforms=[
            dict(type="PILToTensor"),
        ],
    ),
]
hbm_infer_predictor = dict(
    type="Predictor",
    model=hbir_infer_model,
    data_loader=hbm_data_loader,
    batch_processor=val_batch_processor,
    device=None,
    metrics=val_metrics,
    callbacks=[
        val_metric_updater,
    ],
    log_interval=1,
)

align_bpu_data_loader = dict(
    type=torch.utils.data.DataLoader,
    dataset=dict(
        type="NuscenesFromImage",
        src_data_dir="./tmp_orig_data/nuscenes",
        version="v1.0-trainval",
        split_name="val",
        transforms=infer_transforms,
        with_bev_bboxes=False,
        with_ego_bboxes=False,
        with_bev_mask=False,
        with_lidar_bboxes=True,
        need_lidar=True,
        num_sweeps=9,
        load_dim=5,
        use_dim=[0, 1, 2, 3, 4],
    ),
    batch_size=1,
    shuffle=False,
    num_workers=2,
    pin_memory=True,
    collate_fn=collate_nuscenes,
)

align_bpu_predictor = dict(
    type="Predictor",
    model=hbir_infer_model,
    data_loader=align_bpu_data_loader,
    metrics=[val_nuscenes_metric],
    callbacks=[
        val_metric_updater,
    ],
    log_interval=1,
    batch_processor=dict(type="BasicBatchProcessor", need_grad_update=False),
)


def resize_homo(homo, scale):
    view = np.eye(4)
    view[0, 0] = scale[1]
    view[1, 1] = scale[0]
    homo = view @ homo
    return homo


def crop_homo(homo, offset):
    view = np.eye(4)
    view[0, 2] = -offset[0]
    view[1, 2] = -offset[1]
    homo = view @ homo
    return homo


def process_img(img_path, resize_size, crop_size):
    orig_img = cv2.imread(img_path)
    cv2.cvtColor(orig_img, cv2.COLOR_BGR2RGB, orig_img)
    orig_img = Image.fromarray(orig_img)
    orig_img = pil_to_tensor(orig_img)
    resize_hw = (
        int(resize_size[0]),
        int(resize_size[1]),
    )

    orig_shape = (orig_img.shape[1], orig_img.shape[2])
    resized_img = resize(orig_img, resize_hw).unsqueeze(0)
    top = int(resize_hw[0] - crop_size[0])
    left = int((resize_hw[1] - crop_size[1]) / 2)
    resized_img = resized_img[:, :, top:, left:]

    return resized_img, orig_shape


def prepare_inputs(infer_inputs):
    dir_list = os.listdir(infer_inputs)
    dir_list.sort()
    input_datas = []
    for _, frame in enumerate(dir_list):
        data = {}
        frame_path = os.path.join(infer_inputs, frame)
        file_list = list(os.listdir(frame_path))
        image_dir_list = list(filter(lambda x: x.endswith(".jpg"), file_list))
        image_dir_list.sort()

        data["imgs"] = [
            os.path.join(frame_path, tmpdir) for tmpdir in image_dir_list
        ]
        timestamp_path = os.path.join(frame_path, "timestamp.npy")
        data["timestamp"] = np.load(timestamp_path).reshape(1)
        lidar2global_path = os.path.join(frame_path, "lidar2global.npy")
        data["lidar2global"] = np.load(lidar2global_path).reshape(1, 4, 4)
        lidar2img_path = os.path.join(frame_path, "lidar2img.npy")
        data["lidar2img"] = np.load(lidar2img_path)
        data["points0"] = np.load(os.path.join(frame_path, "lidar.npy"))
        input_datas.append(data)
    return input_datas


def process_inputs(data, transforms=None):
    resize_size = resize_shape[1:]
    input_size = val_data_shape[1:]

    orig_imgs = []
    for i, img_path in enumerate(data["imgs"]):
        img, orig_shape = process_img(img_path, resize_size, input_size)
        orig_imgs.append({"name": i, "img": img})

    input_imgs = []
    for orig_img in orig_imgs:
        input_img = horizon.nn.functional.bgr_to_yuv444(orig_img["img"], True)
        input_imgs.append(input_img)

    input_imgs = torch.cat(input_imgs)
    input_imgs = (input_imgs - 128.0) / 128.0

    homo = data["lidar2img"]

    top = int(resize_size[0] - input_size[0])
    left = int((resize_size[1] - input_size[1]) / 2)

    scale = (resize_size[0] / orig_shape[0], resize_size[1] / orig_shape[1])
    homo = resize_homo(homo, scale)
    homo = crop_homo(homo, (left, top))

    model_input = {
        "img": input_imgs,
        "lidar2img": torch.tensor(homo),
        "lidar2global": torch.tensor(data["lidar2global"]),
        "timestamp": torch.tensor(data["timestamp"]),
        # "points": [torch.tensor(data["points"])],
    }
    if transforms is not None:
        model_input = transforms(model_input)

    vis_inputs = {}
    vis_inputs["img"] = orig_imgs
    vis_inputs["meta"] = {"lidar2img": homo}
    # vis_inputs["points"] = model_input["points"]
    return model_input, vis_inputs


def process_outputs(model_outs, viz_func, vis_inputs):
    preds = {}
    if "det" in model_outs:
        outs = torch.cat(
            [
                model_outs["det"][0]["bboxes"][..., :9].view(1, -1, 9),
                model_outs["det"][0]["scores"].view(1, -1, 1),
                model_outs["det"][0]["labels"].view(1, -1, 1),
            ],
            dim=-1,
        )
        outs[..., 3], outs[..., 4] = outs[..., 4], outs[..., 3]
        preds["lidar_det"] = outs

    if "occ" in model_outs:
        semantics_pred = (
            model_outs["occ"][0].squeeze().numpy().astype(np.uint8)
        )
        preds["occ_det"] = semantics_pred

    if "om" in model_outs:
        preds["om_det"] = model_outs["om"]

    viz_func(
        vis_inputs["img"],
        preds=preds,
        meta=vis_inputs["meta"],
    )
    return None


single_infer_dataset = copy.deepcopy(val_data_loader["dataset"])
single_infer_dataset["transforms"] = None


def inputs_save_func(data, save_path):
    if os.path.isdir(save_path):
        shutil.rmtree(save_path)
    os.makedirs(save_path, exist_ok=True)
    for idx_, sample_data in enumerate(data):
        save_dir = os.path.join(save_path, f"frame{idx_}")
        os.makedirs(save_dir, exist_ok=True)
        for image_idx, (img_name, img_data) in enumerate(
            zip(sample_data["img_name"], sample_data["img"])
        ):
            save_name = f"img{image_idx}_{os.path.basename(img_name)}"
            img_data.save(os.path.join(save_dir, save_name), "JPEG")

        lidar2global_path = os.path.join(save_dir, "lidar2global.npy")
        np.save(lidar2global_path, np.array(sample_data["lidar2global"]))
        lidar2img_path = os.path.join(save_dir, "lidar2img.npy")
        np.save(lidar2img_path, np.array(sample_data["lidar2img"]))
        timestamp_path = os.path.join(save_dir, "timestamp.npy")
        np.save(timestamp_path, np.array(sample_data["timestamp"]))
        np.save(os.path.join(save_dir, "lidar.npy"), sample_data["points"])


car_img_path = (
    "tmp_orig_data/nuscenes/infer_imgs/single_frame_lidarego/cars/lidar_car.png"
)
vt_input_hw = [int(view_shape[0]), int(view_shape[1])]

infer_cfg = dict(
    model=hbir_infer_model,
    input_path=f"./demo/{task_name}",
    gen_inputs_cfg=dict(
        dataset=single_infer_dataset,
        sample_idx=[0, 1],
        inputs_save_func=inputs_save_func,
    ),
    prepare_inputs=prepare_inputs,
    process_inputs=process_inputs,
    viz_func=dict(
        type="NuscenesMultitaskViz",
        occ_viz=dict(
            type="OccViz",
            vcs_range=occ_point_cloud_range,
            vis_bev_2d=True,
        ),
        om_viz=dict(
            type="NuscenesMapViz",
            pc_range=map_point_cloud_range,
            car_img_path=car_img_path,
        ),
        score_thresh=0.3,
        is_plot=True,
        bev_size=bev_size,
        use_bce=False,
    ),
    process_outputs=process_outputs,
)

onnx_cfg = dict(
    model=deploy_model,
    inputs=deploy_inputs,
    stage="qat",
    model_convert_pipeline=real_deploy_model_convert_pipeline,
)

calops_cfg = dict(method="hook")

analysis_dataloader = copy.deepcopy(val_data_loader)
analysis_dataloader["num_workers"] = 0
analysis_model = copy.deepcopy(model)
if enable_om_head:
    analysis_model["head"]["om"]["post_process"] = None
qat_bc_infer_model = copy.deepcopy(hbir_infer_model)
qat_bc_infer_model["ir_model"] = dict(
    type="HbirModule",
    model_path=os.path.join(ckpt_dir, "qat.bc"),
)
quantized_bc_infer_model = copy.deepcopy(hbir_infer_model)
quantized_bc_infer_model["ir_model"] = dict(
    type="HbirModule",
    model_path=os.path.join(ckpt_dir, "quantized.bc"),
)
    
quant_analysis_solver = dict(
    type="QuantAnalysis",
    model=analysis_model,
    device_id=0,
    dataloader=analysis_dataloader,    
    num_steps=100,
    baseline_model_convert_pipeline=float_predictor["model_convert_pipeline"],
    analysis_model_convert_pipeline=calibration_predictor[
        "model_convert_pipeline"
    ],
    # baseline_model=qat_bc_infer_model,
    # analysis_model=quantized_bc_infer_model,
    analysis_model_type="fake_quant",
    out_dir=os.path.join(ckpt_dir, "quant_analysis"),
    # cached_attrs=(
    #     "head.det.instance_bank.cached_confidence",
    #     "head.det.instance_bank.cached_feature",
    #     "head.det.instance_bank.cached_anchor",
    # ),
)
