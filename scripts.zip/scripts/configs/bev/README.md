# BEV
|   model               |  dataset |   backbone     |   Input shape      |   config                  |  ckpt download        |  demo download       |
| :----------:          | :-------:|  :--------:    |  :------------:    | :----------------------:  |  :--------:           | :--------:           |
| bev_gkt_multitask            | nuscenes |  MixVarGENet   |    (512, 960)      |configs/bev/bev_gkt_mixvargenet_multitask_nuscenes.py  |wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/bev_gkt_mixvargenet_multitask_nuscenes/* --ftp-password='c5R,2!pG' | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/bev_gkt_mixvargenet_multitask_nuscenes/* --ftp-password='c5R,2!pG' |
| bev_ipm_4d_multitask  | nuscenes | efficientnetb0 |    (512, 960)       |configs/bev/bev_ipm_4d_efficientnetb0_multitask_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/bev_ipm_4d_efficientnetb0_multitask_nuscenes/* --ftp-password='c5R,2!pG' | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/bev_ipm_4d_efficientnetb0_multitask_nuscenes/* --ftp-password='c5R,2!pG' |
| bev_ipm_multitask       | nuscenes | efficientnetb0 |    (512, 960)      | configs/bev/bev_ipm_efficientnetb0_multitask_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/bev_ipm_efficientnetb0_multitask_nuscenes/* --ftp-password='c5R,2!pG' |wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/bev_ipm_efficientnetb0_multitask_nuscenes/* --ftp-password='c5R,2!pG' |
| bev_lss_multitask     | nuscenes | efficientnetb0 |    (256, 704)      |configs/bev/bev_lss_efficientnetb0_multitask_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/bev_lss_efficientnetb0_multitask_nuscenes/* --ftp-password='c5R,2!pG' |wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/bev_lss_efficientnetb0_multitask_nuscenes/* --ftp-password='c5R,2!pG' |
| detr3d                | nuscenes | fcose3d_efficientnetb3  | (512, 1408)         |configs/bev/detr3d_efficientnetb3_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/detr3d_efficientnetb3_nuscenes/* --ftp-password='c5R,2!pG' |wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/detr3d_efficientnetb3_nuscenes/* --ftp-password='c5R,2!pG' |
| petr                  | nuscenes | fcose3d_efficientnetb3 | (512, 1408) | configs/bev/petr_efficientnetb3_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/petr_efficientnetb3_nuscenes/* --ftp-password='c5R,2!pG' |wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/petr_efficientnetb3_nuscenes/* --ftp-password='c5R,2!pG' |
| bevformer_tiny_resnet50_detection_nuscenes  | nuscenes | resnet50 | (480, 800) | configs/bev/bevformer_tiny_resnet50_detection_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/bevformer_tiny_resnet50_detection_nuscenes/* --ftp-password='c5R,2!pG' |wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/bevformer_tiny_resnet50_detection_nuscenes/* --ftp-password='c5R,2!pG' |
| bev_sparse_henet_tinym_nuscenes  | nuscenes | henet-tinym | (256, 704) | configs/bev/bev_sparse_henet_tinym_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/bev_sparse_henet_tinym_nuscenes/* --ftp-password='c5R,2!pG' |wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/bev_sparse_henet_tinym_nuscenes/* --ftp-password='c5R,2!pG' |
| bev_sparse_det_maptr_flashocc_henet_tinym_nuscenes  | nuscenes | henet-tinym | (256, 704) | configs/bev/bev_sparse_det_maptr_flashocc_henet_tinym_nuscenes.py | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/bev_sparse_det_maptr_flashocc_henet_tinym_nuscenes/* --ftp-password='c5R,2!pG' |wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/demo/bev_sparse_det_maptr_flashocc_henet_tinym_nuscenes/* --ftp-password='c5R,2!pG' |

# Backbone Pretrained ckpt
|   backbone         |  ckpt download |
| :----------:       |  :-----------: |
| efficientnetb0     |  wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/efficientnet_imagenet/* --ftp-password='c5R,2!pG' |
| MixVarGENet        |  wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/mixvargenet_imagenet/* --ftp-password='c5R,2!pG' |
|fcos3d_efficientnetb3 | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/fcos3d_efficientnetb3_nuscenes/* --ftp-password='c5R,2!pG' |
|resnet50 | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/resnet50_imagenet/* --ftp-password='c5R,2!pG' |
|henet_tinym | wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/modelzoo/qat_origin_modelzoo/henet_tinym_imagenet/* --ftp-password='c5R,2!pG' |

# Misc

|   file         |  download |
| :----------:       |  :-----------: |
| nuscenes_kmeans900.npy    |  wget -c ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/nuscenes_kmeans900.npy --ftp-password='c5R,2!pG' |

# RUNTIME REFERENCEPOINT

|   file         |  download |
| :----------:       |  :-----------: |
| bevformer_tiny_resnet50_detection_nuscenes  |  wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/runtime_reference_points/bevformer_tiny_resnet50_detection_nuscenes --ftp-password='c5R,2!pG' |
| bev_gkt_mixvargenet_multitask_nuscenes  |  wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/runtime_reference_points/bev_gkt_mixvargenet_multitask_nuscenes --ftp-password='c5R,2!pG' |
| bev_ipm_4d_efficientnetb0_multitask_nuscenes  |  wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/runtime_reference_points/bev_ipm_4d_efficientnetb0_multitask_nuscenes --ftp-password='c5R,2!pG' |
| bev_ipm_efficientnetb0_multitask_nuscenes  |  wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/runtime_reference_points/bev_ipm_efficientnetb0_multitask_nuscenes --ftp-password='c5R,2!pG' |
| bev_lss_efficientnetb0_multitask_nuscenes  |  wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/runtime_reference_points/bev_lss_efficientnetb0_multitask_nuscenes --ftp-password='c5R,2!pG' |
| detr3d_efficientnetb3_nuscenes  |  wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/runtime_reference_points/detr3d_efficientnetb3_nuscenes --ftp-password='c5R,2!pG' |
| petr_efficientnetb3_nuscenes  |  wget -r -np -nH --cut-dirs=5 --no-parent ftp://openexplorer@vrftp.horizon.ai/horizon_torch_samples/3.1.19/py310/misc/runtime_reference_points/petr_efficientnetb3_nuscenes --ftp-password='c5R,2!pG' |
