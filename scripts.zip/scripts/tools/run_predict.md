export FLASHOCC_DATA_ROOTDIR=/open_explorer/data/occ3d_nuscenes

# 在训练集评估浮点模型 | "train_predictor"
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/predict.py \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py \
  --device-ids 0 \
  --ckpt ./tmp_models/flashocc_henet_lss_occ3d_nuscenes/float-checkpoint-last.pth.tar \
  --stage train

# 在验证集评估浮点模型 | "float_predictor"
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/predict.py \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py \
  --device-ids 0 \
  --ckpt ./tmp_models/flashocc_henet_lss_occ3d_nuscenes/float-checkpoint-best.pth.tar \
  --stage float

# 在训练集/验证集评估calibration模型，注意'last'和'best'和浮点模型的注释含义不同 | "calibration_predictor"
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/predict.py \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py \
  --device-ids 0 \
  --stage calibration

# 在训练集/验证集评估qat模型 | "qat_predictor"
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/predict.py \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py \
  --device-ids 0 \
  --stage qat