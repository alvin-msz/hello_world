#!/usr/bin/env python3
"""Realtime HAT train-log monitor: parse loss / NDS / mAP / MeanIOU / lr and save figures.

Supports log styles from:
  - bevformer_pointpillar_nuscenes (tmp.log)
  - bevfusion_centerpoint_* (per-class cls/reg + loss_occ + NDS/MeanIOU)
  - bevfusion_pointpillar_* (loss_cls/bbox + d*.loss_* + loss_occ)

Examples:
  # one-shot plot from finished log
  python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/monitor_train_log.py -l tmp_models/tmp.log -o tmp_models/plots --once

  # live tail while training
  python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/monitor_train_log.py -l tmp_models/tmp.log -o tmp_models/plots --interval 30

  # compare three experiments
  python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/monitor_train_log.py \\
    -l tmp_models/tmp.log \\
    -l tmp_models/train-bevfusion_centerpoint_pointpillar_henet_multisensor_multitask.log \\
    -l tmp_models/train-bevfusion_pointpillar_henet_multisensor_multitask.log \\
    -o tmp_models/plots --once --names lidar_bevformer,fusion_cp,fusion_bevformer
"""

from __future__ import annotations

import argparse
import os
import re
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# -------- regex for HAT logs --------
RE_STEP_LOSS = re.compile(
    r"Epoch\[(\d+)\]\s+Step\[(\d+)\]\s+GlobalStep\[(\d+)\]\s+"
    r"loss_[\w]+:\s*(.+)$"
)
RE_EPOCH_LOSS = re.compile(
    r"Epoch\[(\d+)\]\s+loss_[\w]+:\s*(.+)$"
)
RE_KV = re.compile(r"([\w.\-]+)\[([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\]")
RE_LR = re.compile(
    r"Epoch\[(\d+)\]\s+Step\[(\d+)\]\s+GlobalStep\[(\d+)\]\s+lr=([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)"
)
RE_NDS_MAP = re.compile(
    r"NDS:\s*([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\s*,\s*mAP:\s*([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)"
)
RE_VAL_LINE = re.compile(
    r"Epoch\[(\d+)\]\s+Validation\s+[\w]+:\s*(.+)$"
)
RE_MEANIOU_TENSOR = re.compile(
    r"MeanIOU\[tensor\(([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)"
)
RE_MEANIOU_PLAIN = re.compile(
    r"MeanIOU\[([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\]"
)


def parse_kv_blob(blob: str) -> Dict[str, float]:
    return {k: float(v) for k, v in RE_KV.findall(blob)}


@dataclass
class RunSeries:
    name: str
    # step-wise
    step_gs: List[int] = field(default_factory=list)
    step_epoch: List[int] = field(default_factory=list)
    step_losses: Dict[str, List[float]] = field(default_factory=lambda: defaultdict(list))
    # lr
    lr_gs: List[int] = field(default_factory=list)
    lr_vals: List[float] = field(default_factory=list)
    # epoch-end loss
    epoch_ids: List[int] = field(default_factory=list)
    epoch_losses: Dict[str, List[float]] = field(default_factory=lambda: defaultdict(list))
    # metrics
    metric_epochs: List[int] = field(default_factory=list)
    nds: List[float] = field(default_factory=list)
    map_: List[float] = field(default_factory=list)
    miou: List[float] = field(default_factory=list)
    # file offset
    offset: int = 0
    pending_epoch_for_nds: Optional[int] = None

    def add_step_loss(self, epoch: int, gs: int, kvs: Dict[str, float]) -> None:
        self.step_gs.append(gs)
        self.step_epoch.append(epoch)
        for k, v in kvs.items():
            # keep lists aligned: fill missing with nan
            series = self.step_losses[k]
            while len(series) < len(self.step_gs) - 1:
                series.append(float("nan"))
            series.append(v)
        # pad keys that missed this step
        for k, series in self.step_losses.items():
            while len(series) < len(self.step_gs):
                series.append(float("nan"))

    def add_epoch_loss(self, epoch: int, kvs: Dict[str, float]) -> None:
        self.epoch_ids.append(epoch)
        for k, v in kvs.items():
            series = self.epoch_losses[k]
            while len(series) < len(self.epoch_ids) - 1:
                series.append(float("nan"))
            series.append(v)
        for k, series in self.epoch_losses.items():
            while len(series) < len(self.epoch_ids):
                series.append(float("nan"))

    def add_metrics(
        self,
        epoch: Optional[int],
        nds: Optional[float],
        mapv: Optional[float],
        miou: Optional[float],
    ) -> None:
        if epoch is None:
            epoch = self.pending_epoch_for_nds
        if epoch is None:
            epoch = self.metric_epochs[-1] + 1 if self.metric_epochs else 0
        # merge into same epoch row if last is same
        if self.metric_epochs and self.metric_epochs[-1] == epoch:
            if nds is not None:
                self.nds[-1] = nds
            if mapv is not None:
                self.map_[-1] = mapv
            if miou is not None:
                self.miou[-1] = miou
            return
        self.metric_epochs.append(epoch)
        self.nds.append(nds if nds is not None else float("nan"))
        self.map_.append(mapv if mapv is not None else float("nan"))
        self.miou.append(miou if miou is not None else float("nan"))


def consume_line(run: RunSeries, line: str) -> None:
    line = line.rstrip("\n")

    m = RE_LR.search(line)
    if m:
        run.lr_gs.append(int(m.group(3)))
        run.lr_vals.append(float(m.group(4)))
        return

    m = RE_STEP_LOSS.search(line)
    if m:
        epoch, _step, gs, blob = int(m.group(1)), int(m.group(2)), int(m.group(3)), m.group(4)
        run.add_step_loss(epoch, gs, parse_kv_blob(blob))
        run.pending_epoch_for_nds = epoch
        return

    # epoch-end loss: no Step[...]
    if "Step[" not in line and "Validation" not in line:
        m = RE_EPOCH_LOSS.search(line)
        if m:
            epoch, blob = int(m.group(1)), m.group(2)
            run.add_epoch_loss(epoch, parse_kv_blob(blob))
            run.pending_epoch_for_nds = epoch
            return

    m = RE_NDS_MAP.search(line)
    if m:
        run.add_metrics(
            run.pending_epoch_for_nds,
            float(m.group(1)),
            float(m.group(2)),
            None,
        )
        return

    m = RE_VAL_LINE.search(line)
    if m:
        epoch, blob = int(m.group(1)), m.group(2)
        kvs = parse_kv_blob(blob)
        nds = kvs.get("NDS")
        miou = None
        mm = RE_MEANIOU_TENSOR.search(blob) or RE_MEANIOU_PLAIN.search(blob)
        if mm:
            miou = float(mm.group(1))
        run.add_metrics(epoch, nds, None, miou)
        return


def read_new_bytes(path: str, run: RunSeries) -> int:
    if not os.path.isfile(path):
        return 0
    size = os.path.getsize(path)
    if size < run.offset:
        # log rotated / truncated
        run.offset = 0
    with open(path, "r", errors="ignore") as f:
        f.seek(run.offset)
        chunk = f.read()
        run.offset = f.tell()
    n = 0
    for line in chunk.splitlines():
        if "metric_updater.py" in line or "nuscenes_metric.py" in line or "lr_updater.py" in line:
            consume_line(run, line)
            n += 1
        elif "NDS:" in line and "mAP:" in line:
            consume_line(run, line)
            n += 1
    return n


def _sum_finite(keys: List[str], store: Dict[str, List[float]], idx: int) -> float:
    s, c = 0.0, 0
    for k in keys:
        if k in store and idx < len(store[k]):
            v = store[k][idx]
            if v == v:  # not nan
                s += v
                c += 1
    return s if c else float("nan")


def aggregate_total_loss(run: RunSeries, prefer: str = "step") -> Tuple[np.ndarray, np.ndarray]:
    """Return x, total_loss. Prefer main det losses + occ if present."""
    if prefer == "epoch" and run.epoch_ids:
        xs = np.asarray(run.epoch_ids, dtype=float)
        store = run.epoch_losses
        n = len(run.epoch_ids)
    else:
        xs = np.asarray(run.step_gs, dtype=float)
        store = run.step_losses
        n = len(run.step_gs)
    if n == 0:
        return xs, np.asarray([])

    # priority groups
    primary = [
        k
        for k in store
        if k in (
            "loss_cls",
            "loss_bbox",
            "loss_reg",
            "loss_occ",
            "loss_sem_scal",
            "loss_geo_scal",
        )
    ]
    if not primary:
        # centerpoint-style: sum all *cls_loss / *reg_loss / loss_occ
        primary = [
            k
            for k in store
            if k.endswith("cls_loss")
            or k.endswith("reg_loss")
            or k in ("loss_occ", "loss_sem_scal", "loss_geo_scal")
        ]
    if not primary:
        primary = list(store.keys())[:8]

    ys = np.array([_sum_finite(primary, store, i) for i in range(n)], dtype=float)
    return xs, ys


def plot_runs(runs: List[RunSeries], out_dir: str, tag: str = "latest") -> List[str]:
    os.makedirs(out_dir, exist_ok=True)
    saved = []

    # 1) step total loss
    fig, ax = plt.subplots(figsize=(10, 5))
    for run in runs:
        x, y = aggregate_total_loss(run, "step")
        if len(y):
            ax.plot(x, y, label=f"{run.name} total_loss", linewidth=1.2)
    ax.set_xlabel("GlobalStep")
    ax.set_ylabel("Sum selected losses")
    ax.set_title("Train loss (step)")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    p = os.path.join(out_dir, f"{tag}_loss_step.png")
    fig.tight_layout()
    fig.savefig(p, dpi=140)
    plt.close(fig)
    saved.append(p)

    # 2) epoch loss
    fig, ax = plt.subplots(figsize=(10, 5))
    for run in runs:
        x, y = aggregate_total_loss(run, "epoch")
        if len(y):
            ax.plot(x, y, marker="o", label=f"{run.name} epoch_loss", linewidth=1.5)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("sum selected losses")
    ax.set_title("Train loss (epoch end)")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    p = os.path.join(out_dir, f"{tag}_loss_epoch.png")
    fig.tight_layout()
    fig.savefig(p, dpi=140)
    plt.close(fig)
    saved.append(p)

    # 3) metrics
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))
    for run in runs:
        if not run.metric_epochs:
            continue
        e = np.asarray(run.metric_epochs)
        axes[0].plot(e, run.nds, marker="o", label=run.name)
        axes[1].plot(e, run.map_, marker="o", label=run.name)
        axes[2].plot(e, run.miou, marker="o", label=run.name)
    for ax, title, ylab in zip(
        axes, ["NDS", "mAP", "MeanIOU"], ["NDS", "mAP", "MeanIOU"]
    ):
        ax.set_title(title)
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylab)
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=8)
    p = os.path.join(out_dir, f"{tag}_metrics.png")
    fig.tight_layout()
    fig.savefig(p, dpi=140)
    plt.close(fig)
    saved.append(p)

    # 4) lr
    fig, ax = plt.subplots(figsize=(10, 4))
    for run in runs:
        if run.lr_gs:
            ax.plot(run.lr_gs, run.lr_vals, label=run.name, linewidth=1.2)
    ax.set_xlabel("GlobalStep")
    ax.set_ylabel("lr")
    ax.set_title("Learning rate")
    ax.set_yscale("log")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    p = os.path.join(out_dir, f"{tag}_lr.png")
    fig.tight_layout()
    fig.savefig(p, dpi=140)
    plt.close(fig)
    saved.append(p)

    # 5) dashboard
    fig = plt.figure(figsize=(14, 8))
    ax1 = fig.add_subplot(2, 2, 1)
    ax2 = fig.add_subplot(2, 2, 2)
    ax3 = fig.add_subplot(2, 2, 3)
    ax4 = fig.add_subplot(2, 2, 4)
    for run in runs:
        x, y = aggregate_total_loss(run, "step")
        if len(y):
            ax1.plot(x, y, label=run.name, linewidth=1.0)
        if run.metric_epochs:
            ax2.plot(run.metric_epochs, run.nds, marker="o", label=f"{run.name} NDS")
            ax2.plot(run.metric_epochs, run.map_, marker="x", label=f"{run.name} mAP")
        if run.lr_gs:
            ax3.plot(run.lr_gs, run.lr_vals, label=run.name)
        x, y = aggregate_total_loss(run, "epoch")
        if len(y):
            ax4.plot(x, y, marker="o", label=run.name)
    ax1.set_title("Step loss"); ax1.grid(True, alpha=0.3); ax1.legend(fontsize=7)
    ax2.set_title("Val NDS / mAP"); ax2.grid(True, alpha=0.3); ax2.legend(fontsize=7)
    ax3.set_title("LR (log)"); ax3.set_yscale("log"); ax3.grid(True, alpha=0.3); ax3.legend(fontsize=7)
    ax4.set_title("Epoch loss"); ax4.grid(True, alpha=0.3); ax4.legend(fontsize=7)
    p = os.path.join(out_dir, f"{tag}_dashboard.png")
    fig.tight_layout()
    fig.savefig(p, dpi=150)
    plt.close(fig)
    saved.append(p)

    return saved


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-l", "--log", action="append", required=True, help="train log path (repeatable)")
    ap.add_argument("-o", "--out-dir", default="tmp_models/train_monitor")
    ap.add_argument("--names", default="", help="comma names aligned with --log")
    ap.add_argument("--interval", type=float, default=20.0, help="seconds between refresh")
    ap.add_argument("--once", action="store_true", help="parse once and exit")
    args = ap.parse_args()

    names = [n.strip() for n in args.names.split(",") if n.strip()]
    while len(names) < len(args.log):
        base = os.path.basename(args.log[len(names)])
        names.append(os.path.splitext(base)[0][:40])

    runs = [RunSeries(name=n) for n in names]
    paths = args.log

    def tick(tag: str):
        for path, run in zip(paths, runs):
            read_new_bytes(path, run)
        saved = plot_runs(runs, args.out_dir, tag=tag)
        print(f"[monitor] saved: {', '.join(os.path.basename(p) for p in saved)}")
        for run in runs:
            last_nds = run.nds[-1] if run.nds else float("nan")
            last_map = run.map_[-1] if run.map_ else float("nan")
            print(
                f"  - {run.name}: steps={len(run.step_gs)} epochs_loss={len(run.epoch_ids)} "
                f"metrics={len(run.metric_epochs)} last NDS={last_nds:.4f} mAP={last_map:.4f}"
            )

    if args.once:
        tick("snapshot")
        return

    print(f"[monitor] watching {paths} every {args.interval}s -> {args.out_dir}")
    i = 0
    while True:
        tick("live")
        # also keep a rolling history copy
        if i % 5 == 0:
            tick(f"hist_{int(time.time())}")
        i += 1
        time.sleep(args.interval)


if __name__ == "__main__":
    main()