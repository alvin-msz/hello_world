python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/datasets/occ3d_nuscenes_packer.py \
  --src-data-dir data/nuscenes \
  --target-data-dir data/occ3d_nuscenes \
  --split-name train \
  --anno-file data/occ3d_nuscenes/nuscenes_infos_train.pkl \
  --pack-type lmdb \
  --num-workers 8

python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/datasets/occ3d_nuscenes_packer.py \
  --src-data-dir data/nuscenes \
  --target-data-dir data/occ3d_nuscenes \
  --split-name val \
  --anno-file data/occ3d_nuscenes/nuscenes_infos_val.pkl \
  --pack-type lmdb \
  --num-workers 8