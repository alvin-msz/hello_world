python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/datasets/nuscenes_packer.py --src-data-dir data/nuscenes --target-data-dir data/bevfusion_nuscenes/ --split-name train --pack-type lmdb --need-occ

python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/datasets/nuscenes_packer.py --src-data-dir data/nuscenes --target-data-dir data/bevfusion_nuscenes/ --split-name val --pack-type lmdb --need-occ

python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/create_data.py --dataset nuscenes --root-dir ./data/bevfusion_nuscenes/ --extra-tag nuscenes --out-dir data/bevfusion_nuscenes