python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/datasets/occ3d_nuscenes_viz.py \
  --data-path data/occ3d_nuscenes/train_lmdb \
  --viz-num 5 \
  --vis-bev2d \
  --save-path ./tmp/occ_gt_vis
