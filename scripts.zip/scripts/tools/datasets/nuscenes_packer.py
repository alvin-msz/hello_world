"""Pack nuscenes."""

"""Fix this issue:
    /usr/local/lib/python3.10/dist-packages/hat/data/datasets/data_packer.py
    queue_maxsize: Optional[int] = 1024 -> queue_maxsize: Optional[int] = 8
"""

import argparse
import os

from hat.data.datasets.nuscenes_dataset import NuscenesPacker
from hat.utils.logger import init_logger


def parse_args():
    parser = argparse.ArgumentParser(description="Pack nuscenes dataset.")
    parser.add_argument(
        "--src-data-dir",
        required=True,
        help="The directory that contains unpacked image files.",
    )
    parser.add_argument(
        "--pack-type",
        required=True,
        help="The pack data type for result of packer",
    )
    parser.add_argument(
        "--target-data-dir",
        default="",
        help="The directory for result of packer",
    )
    parser.add_argument(
        "--split-name", default="val", help="The split to paccked."
    )
    parser.add_argument(
        "--version", default="v1.0-mini", help="The version to packed."
    )
    parser.add_argument(
        "--num-workers",
        default=20,
        help="The number of workers to load image.",
    )
    parser.add_argument(
        "--only-lidar",
        action="store_true",
    )
    parser.add_argument(
        "--need-occ",
        action="store_true",
        help=(
            "Pack Occ3D occupancy GT into LMDB for multitask configs that use "
            "seq_meta[*][gt_occ_info] (voxel_semantics, mask_lidar, mask_camera). "
            "Requires under --src-data-dir: "
            "occ3d/gts/<scene_name>/<sample_token>/labels.npz "
            "(npz keys: semantics, mask_lidar, mask_camera). "
            "Ignored when --only-lidar is set (lidar-only packer has no occ path)."
        ),
    )
    args = parser.parse_args()
    return args


if __name__ == "__main__":
    args = parse_args()

    init_logger(".hat_logs/nuscenes_packer")
    directory = os.path.expanduser(args.src_data_dir)
    print("Loading dataset from %s" % directory)

    if args.target_data_dir == "":
        args.target_data_dir = args.src_data_dir
    pack_path = os.path.join(
        args.target_data_dir,
        "%s_%s" % (args.split_name, args.pack_type),
    )

    need_occ = args.need_occ and (not args.only_lidar)
    if args.need_occ and args.only_lidar:
        print(
            "Warning: --need-occ is ignored with --only-lidar "
            "(NuscenesLidarParser does not embed occ3d labels)."
        )

    packer = NuscenesPacker(
        args.version,
        directory,
        pack_path,
        args.split_name,
        int(args.num_workers),
        args.pack_type,
        args.only_lidar,
        need_occ=need_occ,
    )
    packer()
