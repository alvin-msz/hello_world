"""Lovász-Softmax loss (Berman & Blaschko, ECCV 2018).

Surrogate for the Jaccard index (mIoU) with a max-margin hinge structure
that is both differentiable and non-decomposable over pixels — i.e. it
optimises the *set-level* IoU directly, whereas cross-entropy only optimises
per-voxel classification accuracy.

This is the same formulation used by MonoScene and OccMamba (``L_iou``):

    L_iou(p, y) = mean_c  lovasz_hinge({ p_i[c] }, { [y_i == c] })

* ``classes='present'``: only sum over classes that appear in the batch —
  important for Occ3D, where ``free`` (17) almost never appears on the vis
  mask and would otherwise add a spurious, always-zero Jaccard gradient.
* ``ignore``: voxels labelled ``ignore`` are dropped (used to keep non-vis /
  unknown voxels out of the IoU supervision, matching the CE weight mask).
* ``per_image``: average the Lovász hinge per sample instead of over a whole
  batch — use False (monoscene default) for a single flattened batch.

Note: OccMamba applies Lovász on the *camera/visible* lattice via LSS; here
it is applied on ``mask_lidar | mask_camera`` (vis) voxels of Occ3D, i.e.
the exact same voxel set that CE / sem_scal already supervise. Free space is
excluded (never in vis), so there is no empty-label collapse risk.
"""
from __future__ import annotations

from torch.amp import autocast


def lovasz_grad(gt_sorted):
    """Lovász hinge gradient (Berman & Blaschko, Eq. on sorted errors)."""
    p = len(gt_sorted)
    gts = gt_sorted.sum()
    intersection = gts - gt_sorted.float().cumsum(0)
    union = gts + (1 - gt_sorted).float().cumsum(0)
    jaccard = 1.0 - intersection / union
    if p > 1:  # cover 1-pixel case
        jaccard[1:p] = jaccard[1:p] - jaccard[0:-1]
    return jaccard


def lovasz_softmax_flat(probas, labels, classes="present"):
    """Lovász-Softmax over flattened ``(C, N)`` probas / ``(N,)`` labels."""
    if probas.numel() == 0:
        return probas * 0.0

    C, N = probas.size()
    losses = []
    class_to_sum = list(range(C)) if classes in ("all", "present") else classes
    for c in class_to_sum:
        fg = (labels == c).float()
        if classes == "present" and fg.sum() == 0:
            continue
        if C == 1:
            if len(classes) > 1:
                raise ValueError("Sigmoid output possible only with 1 class")
            class_pred = probas[0]
        else:
            class_pred = probas[c]
        errors = (fg - class_pred).abs()
        errors_sorted, perm = errors.sort(0, descending=True)
        perm = perm.data
        fg_sorted = fg[perm]
        losses.append(errors_sorted @ lovasz_grad(fg_sorted))

    if len(losses) == 0:
        return probas * 0.0
    import torch

    return torch.stack(losses).mean()


def flatten_probas(probas, labels, ignore=None):
    """Normalise 2D/3D/5D probas to ``(C, N)`` and labels to ``(N,)``."""
    if probas.dim() == 3:
        # (C, H, W) -> (C, N)
        C, _, _ = probas.size()
        probas = probas.contiguous().view(C, -1)
        labels = labels.contiguous().view(-1)
    elif probas.dim() == 5:
        # (B, C, X, Y, Z) -> (C, B*X*Y*Z)
        C = probas.size(1)
        probas = probas.permute(1, 0, 2, 3, 4).contiguous().view(C, -1)
        labels = labels.contiguous().view(-1)
    elif probas.dim() == 2:
        # already (C, N)
        C = probas.size(0)
        labels = labels.contiguous().view(-1)
    else:
        raise ValueError(
            f"Unsupported probas dim {probas.dim()}, expected 2/3/5"
        )

    if ignore is None:
        return probas, labels
    valid = labels != ignore
    if valid.ndim == 0:
        valid = valid.unsqueeze(0)
    return probas[:, valid], labels[valid]


@autocast("cuda", enabled=False)
def lovasz_softmax(
    probas, labels, classes="present", per_image=False, ignore=None
):
    """Lovász-Softmax multiclass loss.

    Args:
        probas: softmax probabilities. ``(C, H, W)`` or ``(B, C, X, Y, Z)``.
        labels: integer targets. ``(H, W)`` or ``(B, X, Y, Z)``.
        classes: 'present' (sum only present classes) or 'all'.
        per_image: average per-sample hinge instead of whole-batch.
        ignore: label value to drop from the IoU supervision.
    """
    if per_image:
        import torch

        losses = []
        for prob, lab in zip(probas, labels):
            p, l = flatten_probas(prob.unsqueeze(0), lab.unsqueeze(0), ignore)
            losses.append(lovasz_softmax_flat(p, l, classes=classes))
        return torch.stack(losses).mean()
    probas, labels = flatten_probas(probas, labels, ignore)
    return lovasz_softmax_flat(probas, labels, classes=classes)