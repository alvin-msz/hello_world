"""Convert OCC prediction bins from lidar frame to ego frame (occ3d grid).

BevFusion multitask uses ``with_lidar_occ=True``: BPU / training outputs sit on the
lidar-aligned 200x200x16 grid.  Offline evaluation against occ3d ``labels.npz``
(ego grid) requires resampling with the same ``lidar2camego`` transform as HAT
``NuscenesBevSequenceDataset._get_lidar_occ``.

Example:
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/occ_bin_lidar_to_ego.py \
  --input-dir ./occ_preds_lidar \
  --output-dir ./occ_preds_ego \
  --frames-lst ./frames.lst \
  --nuscenes-root /path/to/nuscenes \
  --version v1.0-mini \
  --dtype int8
"""
from __future__ import annotations

import argparse
import glob
import json
import logging
import os
from typing import List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

OCC_GRID_SHAPE = (200, 200, 16)
DEFAULT_OCC_EGO_PC_RANGE = (-40.0, -40.0, -1.0, 40.0, 40.0, 5.4)
DEFAULT_OCC_LIDAR_PC_RANGE = (-40.0, -40.0, -5.0, 40.0, 40.0, 3.0)
DEFAULT_OCC_EGO_RESOLUTION = (0.4, 0.4, 0.4)
OCC_FREE_CLASS = 17
CAM_REFERENCE = "CAM_FRONT"


def parse_args():
    parser = argparse.ArgumentParser(
        description="Resample OCC bin volumes from lidar frame to ego frame"
    )
    parser.add_argument(
        "--input-dir",
        required=True,
        help="Directory with lidar-frame OCC bins (e.g. occ_rank*.bin)",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Directory to write ego-frame OCC bins",
    )
    parser.add_argument(
        "--frames-lst",
        required=True,
        help="frames.lst: one sample path per line (same order as sorted bins). "
        "Basename like sample_0000_<token_prefix>.",
    )
    parser.add_argument(
        "--nuscenes-root",
        required=True,
        help="nuScenes dataroot (contains maps/, samples/, v1.0-* json)",
    )
    parser.add_argument(
        "--version",
        default="v1.0-mini",
        help="nuScenes version string (default: v1.0-mini)",
    )
    parser.add_argument(
        "--glob",
        default="occ_rank*.bin",
        help="Glob under input-dir for OCC bin files (default: occ_rank*.bin)",
    )
    parser.add_argument(
        "--dtype",
        default="int8",
        choices=["int8", "uint8", "int16", "int32"],
        help="Dtype for read/write (default: int8, matches BPU argmax export)",
    )
    parser.add_argument(
        "--cam-name",
        default=CAM_REFERENCE,
        help="Reference camera for lidar2camego (default: CAM_FRONT, same as HAT)",
    )
    parser.add_argument(
        "--save-manifest",
        action="store_true",
        help="Write manifest.json under output-dir listing transforms applied",
    )
    return parser.parse_args()


def parse_token_prefixes(frames_lst: str) -> List[str]:
    with open(frames_lst, "r") as f:
        lines = [line.strip() for line in f if line.strip()]
    prefixes = []
    for line in lines:
        basename = os.path.basename(line)
        parts = basename.split("_")
        if len(parts) >= 3:
            prefixes.append(parts[-1])
        else:
            prefixes.append(basename)
    logger.info("Read %d entries from %s", len(prefixes), frames_lst)
    return prefixes


def build_prefix_to_sample_token(nusc) -> dict:
    mapping = {}
    for sample in nusc.sample:
        token = sample["token"]
        for plen in (8, 10, 12, len(token)):
            prefix = token[:plen]
            if prefix not in mapping:
                mapping[prefix] = token
    return mapping


def compute_lidar2camego(nusc, sample_token: str, cam_name: str) -> np.ndarray:
    """Same geometry as HAT ``NuscenesBevSequenceDataset._get_lidar_occ``."""
    from pyquaternion import Quaternion

    sample = nusc.get("sample", sample_token)
    lid_sd = nusc.get("sample_data", sample["data"]["LIDAR_TOP"])
    cam_sd = nusc.get("sample_data", sample["data"][cam_name])

    cam_ep = nusc.get("ego_pose", cam_sd["ego_pose_token"])
    cam_ego2global = np.eye(4, dtype=np.float64)
    cam_ego2global[:3, :3] = Quaternion(cam_ep["rotation"]).rotation_matrix
    cam_ego2global[:3, 3] = np.array(cam_ep["translation"], dtype=np.float64)
    global2camego = np.linalg.inv(cam_ego2global)

    lid_cs = nusc.get("calibrated_sensor", lid_sd["calibrated_sensor_token"])
    lid_ep = nusc.get("ego_pose", lid_sd["ego_pose_token"])
    lidar2ego = np.eye(4, dtype=np.float64)
    lidar2ego[:3, :3] = Quaternion(lid_cs["rotation"]).rotation_matrix
    lidar2ego[:3, 3] = np.array(lid_cs["translation"], dtype=np.float64)
    ego2global = np.eye(4, dtype=np.float64)
    ego2global[:3, :3] = Quaternion(lid_ep["rotation"]).rotation_matrix
    ego2global[:3, 3] = np.array(lid_ep["translation"], dtype=np.float64)
    lidar2global = ego2global @ lidar2ego
    return (global2camego @ lidar2global).astype(np.float64)


def occ_lidar2ego(
    voxel_lidar: np.ndarray,
    transform_matrix: np.ndarray,
    pc_range=DEFAULT_OCC_EGO_PC_RANGE,
    lidar_pc_range=DEFAULT_OCC_LIDAR_PC_RANGE,
    ego_resolution=DEFAULT_OCC_EGO_RESOLUTION,
) -> np.ndarray:
    """Inverse of HAT ``_get_occ_ego2lidar``: lidar grid -> ego grid."""
    H, W, Z = voxel_lidar.shape
    occ_ego = np.full((H, W, Z), OCC_FREE_CLASS, dtype=voxel_lidar.dtype)
    inv = np.linalg.inv(np.asarray(transform_matrix, dtype=np.float64))

    x = np.linspace(0.5, W - 0.5, W)
    y = np.linspace(0.5, H - 0.5, H)
    z = np.linspace(0.5, Z - 0.5, Z)
    xg, yg, zg = np.meshgrid(x, y, z, indexing="ij")

    ego_coords = np.stack(
        [
            xg / W * (pc_range[3] - pc_range[0]) + pc_range[0],
            yg / H * (pc_range[4] - pc_range[1]) + pc_range[1],
            zg / Z * (pc_range[5] - pc_range[2]) + pc_range[2],
            np.ones_like(xg),
        ],
        axis=-1,
    )
    lidar_coords = ego_coords @ inv.T

    xs = (lidar_coords[..., 0] - lidar_pc_range[0]) / (
        lidar_pc_range[3] - lidar_pc_range[0]
    )
    ys = (lidar_coords[..., 1] - lidar_pc_range[1]) / (
        lidar_pc_range[4] - lidar_pc_range[1]
    )
    zs = (lidar_coords[..., 2] - lidar_pc_range[2]) / (
        lidar_pc_range[5] - lidar_pc_range[2]
    )
    x_lidar = np.floor(xs * W).astype(np.int32)
    y_lidar = np.floor(ys * H).astype(np.int32)
    z_lidar = np.floor(zs * Z).astype(np.int32)

    valid = (
        (x_lidar >= 0)
        & (x_lidar < W)
        & (y_lidar >= 0)
        & (y_lidar < H)
        & (z_lidar >= 0)
        & (z_lidar < Z)
    )
    occ_ego[valid] = voxel_lidar[x_lidar[valid], y_lidar[valid], z_lidar[valid]]
    return occ_ego


def load_lidar2camego_list(
    frames_lst: str,
    nuscenes_root: str,
    version: str,
    cam_name: str,
) -> Tuple[List[Optional[np.ndarray]], List[str]]:
    from nuscenes.nuscenes import NuScenes

    prefixes = parse_token_prefixes(frames_lst)
    nusc = NuScenes(version=version, dataroot=nuscenes_root, verbose=False)
    prefix_to_token = build_prefix_to_sample_token(nusc)

    transforms: List[Optional[np.ndarray]] = []
    sample_tokens: List[str] = []
    missing = 0
    for prefix in prefixes:
        sample_token = prefix_to_token.get(prefix)
        if sample_token is None:
            missing += 1
            if missing <= 5:
                logger.warning("No nuScenes sample for token prefix %s", prefix)
            transforms.append(None)
            sample_tokens.append("")
            continue
        try:
            transforms.append(
                compute_lidar2camego(nusc, sample_token, cam_name=cam_name)
            )
            sample_tokens.append(sample_token)
        except Exception as exc:
            missing += 1
            if missing <= 5:
                logger.warning(
                    "lidar2camego failed for prefix %s (%s): %s",
                    prefix,
                    sample_token,
                    exc,
                )
            transforms.append(None)
            sample_tokens.append(sample_token)
    if missing > 5:
        logger.warning("Total %d frames missing lidar2camego", missing)
    return transforms, sample_tokens


def convert_one_bin(
    in_path: str,
    out_path: str,
    lidar2camego: np.ndarray,
    np_dtype: np.dtype,
) -> None:
    flat = np.fromfile(in_path, dtype=np_dtype)
    expected = int(np.prod(OCC_GRID_SHAPE))
    if flat.size != expected:
        raise ValueError(
            f"{in_path}: size {flat.size} != grid {OCC_GRID_SHAPE} ({expected})"
        )
    volume = flat.reshape(OCC_GRID_SHAPE)
    ego_vol = occ_lidar2ego(volume, lidar2camego)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    ego_vol.astype(np_dtype, copy=False).tofile(out_path)


def main():
    args = parse_args()
    input_dir = os.path.abspath(args.input_dir)
    output_dir = os.path.abspath(args.output_dir)
    os.makedirs(output_dir, exist_ok=True)

    pattern = os.path.join(input_dir, args.glob)
    bin_files = sorted(glob.glob(pattern))
    if not bin_files:
        raise SystemExit(f"No files match {pattern}")

    transforms, sample_tokens = load_lidar2camego_list(
        args.frames_lst,
        args.nuscenes_root,
        args.version,
        args.cam_name,
    )
    if len(transforms) < len(bin_files):
        logger.warning(
            "frames.lst has %d entries but %d bin files; using min length",
            len(transforms),
            len(bin_files),
        )
    n = min(len(bin_files), len(transforms))

    np_dtype = np.dtype(args.dtype)
    manifest = []
    ok = 0
    skipped = 0

    for idx in range(n):
        in_path = bin_files[idx]
        name = os.path.basename(in_path)
        out_path = os.path.join(output_dir, name)
        l2c = transforms[idx]
        if l2c is None:
            logger.warning("Skip [%d] %s: no lidar2camego", idx, name)
            skipped += 1
            continue
        try:
            convert_one_bin(in_path, out_path, l2c, np_dtype)
            ok += 1
            if args.save_manifest:
                manifest.append(
                    {
                        "index": idx,
                        "input": in_path,
                        "output": out_path,
                        "sample_token": sample_tokens[idx],
                    }
                )
        except Exception as exc:
            logger.warning("Skip [%d] %s: %s", idx, name, exc)
            skipped += 1

    logger.info(
        "Done: converted %d / %d bins -> %s (skipped %d)",
        ok,
        n,
        output_dir,
        skipped,
    )
    if args.save_manifest:
        manifest_path = os.path.join(output_dir, "manifest.json")
        with open(manifest_path, "w") as f:
            json.dump(
                {
                    "input_dir": input_dir,
                    "output_dir": output_dir,
                    "frames_lst": os.path.abspath(args.frames_lst),
                    "nuscenes_root": os.path.abspath(args.nuscenes_root),
                    "version": args.version,
                    "dtype": args.dtype,
                    "grid_shape": list(OCC_GRID_SHAPE),
                    "converted": ok,
                    "skipped": skipped,
                    "files": manifest,
                },
                f,
                indent=2,
            )
        logger.info("Wrote %s", manifest_path)


if __name__ == "__main__":
    main()
