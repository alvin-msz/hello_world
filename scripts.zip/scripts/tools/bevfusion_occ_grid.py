"""BevFusion that crops/upsamples CenterPoint BEV onto the Occ3D 200x200 grid.

CenterPoint PointPillar (``centerpoint_pointpillar_nuscenes_ego_occ3d``) voxelizes
ego points at ±51.2 m / 0.2 m with an 8 m Z pillar ``[-1.8, 6.2]``, and
SECONDNeck emits 128×128 (±51.2 m / 0.8 m). Camera VT / det use the same 8 m Z
with Occ3D XY (±40 m); OCC GT / C2H stay on Occ3D ``[-1, 5.4]`` 200×200×16.
HAT ``BevFusion`` concatenates lidar and camera BEV as-is, so lidar must be
cropped to the center ±40 m (100×100) and bilinear-upsampled to 200×200.
Neck weights stay under ``lidar_net.neck.*``.

If lidar XY or voxel size is not nuScenes ±51.2 / 0.2, recompute
``lidar_roi_box``: neck_res = voxel_xy * out_size_factor, then
roi = ((occ_min - lidar_min) / neck_res, (occ_max - lidar_min) / neck_res).
"""
from __future__ import annotations

from typing import Sequence, Tuple

import torch.nn.functional as F

from hat.models.structures.bevfusion import BevFusion
from hat.registry import OBJECT_REGISTRY

# SECOND 128×128 @ 0.8 m covering ±51.2 m; center ±40 m is 100 cells.
_DEFAULT_LIDAR_ROI = (14, 14, 114, 114)


@OBJECT_REGISTRY.register
class BevFusionOccGrid(BevFusion):
    """``BevFusion`` with lidar BEV remapped to Occ3D XY (200×200)."""

    def __init__(
        self,
        lidar_roi_box: Sequence[int] = _DEFAULT_LIDAR_ROI,
        lidar_out_hw: Tuple[int, int] = (200, 200),
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.lidar_roi_box = tuple(int(v) for v in lidar_roi_box)
        self.lidar_out_hw = (int(lidar_out_hw[0]), int(lidar_out_hw[1]))

    def forward_lidar_feature(self, example: dict):
        x = super().forward_lidar_feature(example)
        x1, y1, x2, y2 = self.lidar_roi_box
        x = x[:, :, y1:y2, x1:x2]
        if x.shape[-2:] != self.lidar_out_hw:
            x = F.interpolate(
                x,
                size=self.lidar_out_hw,
                mode="bilinear",
                align_corners=False,
            )
        return x
