#!/usr/bin/env python3
"""使用训练得到的 .pth.tar 在训练集或验证集上推理，并导出与 Occ3D 标签一致的 npz。

默认写出 ``labels.npz``，包含与官方 Occ3D ``labels.npz`` 相同的键：
``semantics``、``mask_lidar``、``mask_camera``。其中 ``semantics`` 为模型预测的体素类别，
``mask_*`` 与当前样本 GT 一致（仅表示观测区域，与多数评测/可视化脚本一致）。

目录结构（与常见可视化脚本兼容）::

    {out_dir}/{scene_name}/{sample_token}/labels.npz

可选 ``--save-pred-npz`` 额外写入 ``pred.npz``（键 ``pred``），便于使用仅读取 pred 的可视化脚本。

依赖与 ``predict.py`` 相同（horizon HAT 环境）。示例::

    export FLASHOCC_DATA_ROOTDIR=/path/to/occ3d_nuscenes
    python3 predict_occ_export_npz.py \\
        -c configs/occ/flashocc_henet_lss_occ3d_nuscenes.py \\
        --ckpt ./tmp_models/flashocc_henet_lss_occ3d_nuscenes/float-checkpoint-best.pth.tar \\
        --split val \\
        --out-dir ./tmp/occ_pred_npz \\
        --nuscenes-info ./data/occ3d_nuscenes/nuscenes_infos_val.pkl \\
        --device cuda:0
"""

from __future__ import annotations

import argparse
import logging
import os
import pickle
import sys
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import horizon_plugin_pytorch as horizon
from hat.data.collates.nusc_collates import collate_nuscenes
from hat.registry import RegistryContext, build_from_registry
from hat.utils.checkpoint import load_state_dict
from hat.utils.config import Config

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s"
)


def _ensure_tools_on_path(config_path: str) -> None:
    """与 flashocc 配置一致，注册 GTOccInfoFromVoxelSemantics 等。"""
    cfg_dir = os.path.dirname(os.path.abspath(config_path))
    tools_dir = os.path.abspath(os.path.join(cfg_dir, "..", "..", "tools"))
    if tools_dir not in sys.path:
        sys.path.insert(0, tools_dir)
    import flashocc_gt_occ_info_adapter  # noqa: F401


def _to_device(data: Any, device: torch.device, non_blocking: bool = True) -> Any:
    if torch.is_tensor(data):
        return data.to(device, non_blocking=non_blocking)
    if isinstance(data, dict):
        return {k: _to_device(v, device, non_blocking) for k, v in data.items()}
    if isinstance(data, list):
        return [_to_device(v, device, non_blocking) for v in data]
    if isinstance(data, tuple):
        return tuple(_to_device(v, device, non_blocking) for v in data)
    return data


def _strip_occ_supervision(batch: Dict[str, Any]) -> Dict[str, Any]:
    """推理时去掉 OCC GT，避免部分实现里对 label 的依赖。"""
    out = dict(batch)
    for k in (
        "voxel_semantics",
        "mask_lidar",
        "mask_camera",
        "gt_occ_info",
    ):
        out.pop(k, None)
    return out


def _occ_pred_from_outputs(model_out: Any) -> torch.Tensor:
    """从 ViewFusion + FlashOcc 输出中取出 occ_pre。"""
    if isinstance(model_out, (list, tuple)) and len(model_out) > 1:
        head = model_out[1]
    else:
        head = model_out
    if isinstance(head, dict) and "occ_pre" in head:
        return head["occ_pre"]
    if isinstance(head, dict):
        for k in ("occ", "semantics", "pred"):
            if k in head:
                return head[k]
    raise KeyError(
        "无法在模型输出中找到 occ_pre，请检查 decoder 输出结构。"
    )


def _tensor_to_numpy_mask(x: torch.Tensor) -> np.ndarray:
    a = x.detach().cpu().numpy()
    if a.dtype == np.bool_:
        return a
    return a.astype(np.uint8)


def _scene_token_from_occ_path(occ_path: str) -> Optional[Tuple[str, str]]:
    """``occ3d/gts/{scene_name}/{token}`` -> (scene_name, token)."""
    if not occ_path:
        return None
    parts = occ_path.replace("\\", "/").strip("/").split("/")
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return None


def _meta_for_index(
    infos: Optional[List[dict]], idx: int
) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    if not infos or idx < 0 or idx >= len(infos):
        return None, None, None
    info = infos[idx]
    scene = info.get("scene_name")
    token = info.get("token")
    occ_path = info.get("occ_path")
    if scene and token:
        return scene, token, occ_path
    if occ_path:
        st = _scene_token_from_occ_path(occ_path)
        if st:
            return st[0], st[1], occ_path
    return scene, token, occ_path


def _batch_sample_meta(
    batch: Dict[str, Any], b: int
) -> Tuple[Optional[str], Optional[str]]:
    """尝试从 collate 后的 batch 中取 scene_name / token。"""

    def _one(val: Any) -> Optional[str]:
        if val is None:
            return None
        if isinstance(val, (list, tuple)) and b < len(val):
            val = val[b]
        if isinstance(val, bytes):
            val = val.decode("utf-8", errors="ignore")
        return str(val) if val is not None else None

    scene = _one(batch.get("scene_name")) or _one(batch.get("scene"))
    token = _one(batch.get("token")) or _one(batch.get("sample_token"))

    metas = batch.get("img_metas")
    if isinstance(metas, list) and b < len(metas):
        m = metas[b]
        if isinstance(m, dict):
            if scene is None:
                sn = m.get("scene_name") or m.get("scene")
                scene = str(sn) if sn is not None else None
            if token is None:
                tk = m.get("token") or m.get("sample_token")
                token = str(tk) if tk is not None else None

    return scene, token


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "-c",
        "--config",
        required=True,
        help="FlashOcc Occ3D 配置文件路径（与 predict.py 相同）",
    )
    p.add_argument(
        "--ckpt",
        required=True,
        help="float 阶段 .pth.tar 权重路径",
    )
    p.add_argument(
        "--split",
        choices=("train", "val"),
        default="val",
        help="使用训练集或验证集 LMDB（与配置中 data_path 一致）",
    )
    p.add_argument(
        "--out-dir",
        required=True,
        help="导出根目录",
    )
    p.add_argument(
        "--nuscenes-info",
        default=None,
        help=(
            "nuscenes_infos_{train|val}.pkl，用于 scene_name/sample_token 与 infos 对齐；"
            "若不提供则使用 frame_XXXXXXXX 目录名"
        ),
    )
    p.add_argument(
        "--device",
        default="cuda:0",
        help="推理设备，如 cuda:0 或 cpu",
    )
    p.add_argument(
        "--batch-size",
        type=int,
        default=1,
        help="批大小，建议保持为 1 以便与 info 索引对齐",
    )
    p.add_argument(
        "--num-workers",
        type=int,
        default=4,
    )
    p.add_argument(
        "--save-pred-npz",
        action="store_true",
        help="额外保存 pred.npz（键 pred），兼容部分可视化脚本",
    )
    p.add_argument(
        "--no-strip-gt",
        action="store_true",
        help="转发前不删除 voxel_semantics / mask_*（默认会删除以纯推理）",
    )
    p.add_argument(
        "--max-samples",
        type=int,
        default=-1,
        help="最多处理样本数，-1 表示全部",
    )
    p.add_argument(
        "--pkl-stride",
        type=int,
        default=None,
        help=(
            "将 dataloader 样本序号映射到 nuscenes info 下标：info_idx = sample_idx * stride。"
            "默认与数据集 load_interval 相同；若 pkl 与 LMDB 已一一对应可设为 1"
        ),
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    config_path = os.path.abspath(args.config)
    _ensure_tools_on_path(config_path)

    cfg = Config.fromfile(config_path)
    horizon.march.set_march(cfg.get("march", horizon.march.March.BAYES))

    infos: Optional[List[dict]] = None
    if args.nuscenes_info:
        with open(args.nuscenes_info, "rb") as f:
            blob = pickle.load(f)
        infos = blob.get("infos", blob)
        if not isinstance(infos, list):
            raise ValueError("pkl 中应包含 infos 列表")
        logger.info("已加载 nuscenes info: %d 条", len(infos))

    ds_cfg = dict(cfg.data[args.split])
    test_tfms = cfg.get("test_transforms", None)
    if test_tfms is not None:
        ds_cfg["transforms"] = test_tfms
    elif args.split == "train":
        logger.warning(
            "配置中未找到 test_transforms，训练集将使用 data.train 自带 transforms（可能含增广）。"
        )

    load_interval = int(ds_cfg.get("load_interval", 1))
    pkl_stride = args.pkl_stride if args.pkl_stride is not None else load_interval

    with RegistryContext():
        dataset = build_from_registry(ds_cfg)

    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        collate_fn=collate_nuscenes,
        pin_memory=True,
    )

    with RegistryContext():
        model = build_from_registry(cfg.model)
    load_state_dict(model, path_or_dict=args.ckpt, map_location="cpu")
    device = torch.device(args.device)
    model.to(device)
    model.eval()

    vbp = cfg.get("val_batch_processor", None) or {}
    use_amp = bool(vbp.get("enable_amp", False))
    amp_dtype = vbp.get("enable_amp_dtype", torch.float16)

    os.makedirs(args.out_dir, exist_ok=True)

    ns = 0
    for batch_idx, batch in enumerate(loader):
        if args.max_samples >= 0 and ns >= args.max_samples:
            break

        masks_lidar = batch.get("mask_lidar")
        masks_camera = batch.get("mask_camera")
        if masks_lidar is None or masks_camera is None:
            raise KeyError("batch 中缺少 mask_lidar / mask_camera，无法写出与 GT 同结构的 npz")

        raw_batch = batch
        fwd = _strip_occ_supervision(batch) if not args.no_strip_gt else dict(batch)
        fwd = _to_device(fwd, device)

        with torch.no_grad():
            if use_amp and device.type == "cuda":
                with torch.cuda.amp.autocast(dtype=amp_dtype):
                    out = model(fwd)
            else:
                out = model(fwd)

        occ_pre = _occ_pred_from_outputs(out)
        B = occ_pre.shape[0]

        for bi in range(B):
            if args.max_samples >= 0 and ns >= args.max_samples:
                break

            info_idx = (batch_idx * B + bi) * pkl_stride
            scene_guess, token_guess = _batch_sample_meta(raw_batch, bi)
            scene_i, token_i, occ_path = _meta_for_index(infos, info_idx)
            scene = scene_guess or scene_i
            token = token_guess or token_i
            if not scene or not token:
                scene = scene or "unknown_scene"
                token = token or f"frame_{info_idx:08d}"
                logger.debug(
                    "样本 %s 缺少 scene/token，使用回退目录名", info_idx
                )

            sem = (
                occ_pre[bi].squeeze().detach().cpu().numpy().astype(np.uint8)
            )
            ml = _tensor_to_numpy_mask(masks_lidar[bi].squeeze())
            mc = _tensor_to_numpy_mask(masks_camera[bi].squeeze())

            sub = os.path.join(args.out_dir, str(scene), str(token))
            os.makedirs(sub, exist_ok=True)
            labels_path = os.path.join(sub, "labels.npz")
            np.savez_compressed(
                labels_path,
                semantics=sem,
                mask_lidar=ml,
                mask_camera=mc,
            )
            if args.save_pred_npz:
                np.savez_compressed(
                    os.path.join(sub, "pred.npz"),
                    pred=sem,
                )

            ns += 1
            if ns % 50 == 0:
                logger.info("已写出 %d 个样本，最近: %s", ns, labels_path)

    logger.info("完成，共导出 %d 个样本 -> %s", ns, args.out_dir)


if __name__ == "__main__":
    main()
