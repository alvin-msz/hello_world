"""Map LiDAR-frame points (and CenterPoint boxes) into the ego / vehicle frame.

Used by ``*_ego.py`` configs. Two data layouts:

* ``NuscenesBevSequenceDataset``: ``data["points"]`` + ``data["lidar2ego"]`` (4x4)
* ``NuscenesLidarDataset``: ``data["lidar"]["points"]`` + ``metadata`` lidar2ego
  quaternion/translation; also transforms ``annotations`` boxes and then sets
  lidar2ego in metadata to identity so ``NuscenesMetric(use_lidar=True)`` does
  not apply the extrinsic twice.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np

from hat.registry import OBJECT_REGISTRY

try:
    from pyquaternion import Quaternion
except ImportError:  # pragma: no cover
    Quaternion = None


def _as_4x4(mat) -> np.ndarray:
    arr = np.asarray(mat, dtype=np.float64)
    if arr.shape != (4, 4):
        raise ValueError(f"lidar2ego must be 4x4, got {arr.shape}")
    return arr


def _lidar2ego_from_meta(meta: Dict[str, Any]) -> Optional[np.ndarray]:
    trans = meta.get("lidar2ego_translation")
    rot = meta.get("lidar2ego_rotation")
    if trans is None or rot is None:
        return None
    if Quaternion is None:
        raise ImportError("pyquaternion is required for CenterPoint Lidar2Ego")
    mat = np.eye(4, dtype=np.float64)
    mat[:3, :3] = Quaternion(rot).rotation_matrix
    mat[:3, 3] = np.asarray(trans, dtype=np.float64)
    return mat


def transform_points_xyz(points: np.ndarray, lidar2ego: np.ndarray) -> np.ndarray:
    """In-place-safe: returns a copy with xyz mapped by ``lidar2ego``."""
    pts = np.asarray(points, dtype=np.float32).copy()
    if pts.size == 0:
        return pts
    xyz = pts[:, :3]
    ones = np.ones((xyz.shape[0], 1), dtype=np.float64)
    homo = np.concatenate([xyz.astype(np.float64), ones], axis=1)
    mapped = (lidar2ego @ homo.T).T[:, :3].astype(np.float32)
    pts[:, :3] = mapped
    return pts


def transform_boxes(boxes: np.ndarray, lidar2ego: np.ndarray) -> np.ndarray:
    """Map CenterPoint boxes ``[x,y,z, dims, vx, vy, yaw_cp]`` into ego.

    ``get_lidar_ann_info`` stores CenterPoint yaw as ``-yaw_nusc - pi/2``.
    That mapping has a sign flip, so a Euclidean yaw increment ``alpha`` on
    the nuScenes heading changes CenterPoint yaw by ``-alpha``. Adding
    ``alpha`` directly (as if yaw were a geometric heading) leaves boxes
    ~90° off nuScenes lidar2ego and shows up as mAOE near pi/2.
    """
    out = np.asarray(boxes, dtype=np.float32).copy()
    if out.size == 0:
        return out
    rot = lidar2ego[:3, :3]
    xyz = out[:, :3]
    ones = np.ones((xyz.shape[0], 1), dtype=np.float64)
    homo = np.concatenate([xyz.astype(np.float64), ones], axis=1)
    out[:, :3] = (lidar2ego @ homo.T).T[:, :3].astype(np.float32)

    yaw_cp = out[:, -1].astype(np.float64)
    yaw_nusc = -yaw_cp - np.pi / 2
    heading = np.stack(
        [np.cos(yaw_nusc), np.sin(yaw_nusc), np.zeros_like(yaw_nusc)],
        axis=1,
    )
    heading_ego = heading @ rot.T
    yaw_nusc_ego = np.arctan2(heading_ego[:, 1], heading_ego[:, 0])
    out[:, -1] = (-yaw_nusc_ego - np.pi / 2).astype(np.float32)

    if out.shape[1] >= 9:
        rot2 = lidar2ego[:2, :2].astype(np.float32)
        out[:, 6:8] = out[:, 6:8] @ rot2.T
    return out


@OBJECT_REGISTRY.register
class Lidar2EgoNuscenes:
    """Transform LiDAR-frame points (and CenterPoint boxes) to ego."""

    def __init__(self, transform_boxes: bool = True):
        self.transform_boxes = transform_boxes

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if "lidar2ego" in data:
            lidar2ego = _as_4x4(data["lidar2ego"])
            if "points" in data and data["points"] is not None:
                pts = data["points"]
                if isinstance(pts, (list, tuple)):
                    data["points"] = [
                        transform_points_xyz(p, lidar2ego) for p in pts
                    ]
                else:
                    data["points"] = transform_points_xyz(pts, lidar2ego)
            return data

        if "lidar" in data and isinstance(data["lidar"], dict):
            meta = data.get("metadata", {})
            lidar2ego = _lidar2ego_from_meta(meta)
            if lidar2ego is None:
                return data
            lid = data["lidar"]
            if lid.get("points") is not None:
                lid["points"] = transform_points_xyz(lid["points"], lidar2ego)
            if self.transform_boxes:
                anno = lid.get("annotations")
                if isinstance(anno, dict):
                    if "gt_boxes" in anno and anno["gt_boxes"] is not None:
                        anno["gt_boxes"] = transform_boxes(
                            anno["gt_boxes"], lidar2ego
                        )
                    if "boxes" in anno and anno["boxes"] is not None:
                        anno["boxes"] = transform_boxes(
                            anno["boxes"], lidar2ego
                        )
            # Predictions are now ego; keep lidar box conventions in the
            # metric but skip the real extrinsic (identity lidar2ego).
            meta["lidar2ego_translation"] = [0.0, 0.0, 0.0]
            meta["lidar2ego_rotation"] = [1.0, 0.0, 0.0, 0.0]
            data["metadata"] = meta
        return data
