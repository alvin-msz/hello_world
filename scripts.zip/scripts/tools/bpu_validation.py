"""bpu validation tools, Only for ai benchmark hbm validation."""

import argparse

import numpy as np

from hat.registry import build_from_registry
from hat.utils.config import Config
from hat.utils.logger import init_logger


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        "-c",
        type=str,
        required=True,
        help="config file path",
    )
    parser.add_argument(
        "--result-path",
        type=str,
        nargs="+",
        required=True,
        help="result path for bpu prediction output.",
    )
    parser.add_argument(
        "--gt-files-path",
        type=str,
        default="",
        help="gt infos path for bpu prediction metric.",
    )
    # 允许接受任意额外参数，形式为 --key value
    parser.add_argument(
        "--extra-args",
        nargs=argparse.REMAINDER,
        help="additional arguments passed to process_data",
    )
    return parser.parse_args()


def defualt_process_result_data(result_path):
    lines = open(result_path).read().splitlines()
    img_data = {}
    for line in lines:
        data = line.strip().split(" ")
        image_name = data[1][:-4]
        boxes_data = data[2:]
        box_list = []
        for r in boxes_data:
            box_data = r.split(",")
            box_list.append({"bbox": np.array(box_data), "mask": False})
        img_data[image_name] = box_list
    return img_data


def parse_extra_args(extra_args):
    """
    将 ["--key1", "val1", "--key2", "val2"] 转换成字典 {"key1": val1, "key2": val2}
    """
    result = {}
    if extra_args is None:
        return result

    key = None
    for arg in extra_args:
        if arg.startswith("--"):
            key = arg[2:].replace("-", "_")
            result[key] = True  # 如果是 flag 类型
        elif key:
            result[key] = arg
            key = None
    return result


if __name__ == "__main__":
    args = parse_args()

    # 解析 extra args 为 dict
    extra_args = parse_extra_args(args.extra_args)
    print(f"Extra args for process_data: {extra_args}")

    config = Config.fromfile(args.config)
    init_logger(f".hat_logs/{config.task_name}_bpu_validation")

    process_result_data = config.get(
        "bpu_process_result_data", defualt_process_result_data
    )
    assert callable(
        process_result_data
    ), "process_result_data must be callable."
    result_data = process_result_data(args.result_path)
    print("Arm result loaded end!")

    eval_metric = config.get("bpu_eval_metric", None)
    if isinstance(eval_metric, (list, tuple)) and isinstance(
        eval_metric[0], dict
    ):
        eval_metric_registry = []
        for metirc in eval_metric:
            eval_metric_registry.append(build_from_registry(metirc))
        eval_metric = eval_metric_registry
    elif isinstance(eval_metric, dict):
        eval_metric = build_from_registry(eval_metric)
    assert eval_metric is not None, "You must set bpu_eval_metric in config."

    process_metric = config.get("bpu_process_metric", None)
    assert callable(process_metric), "process_metric must be callable."
    output = process_metric(
        result_data, eval_metric, args.gt_files_path, **extra_args
    )

    print("BPU eval finished!")
