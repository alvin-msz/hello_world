"""FlashOcc adapter transforms for Occ3dNuscenesDataset.

Why:
`hat.data.transforms.flashocc_transforms.BevFeatureAug` expects
`data["gt_occ_info"]`, but `hat.data.datasets.occ3d_nuscenes_dataset.Occ3dNuscenesDataset`
provides `data["voxel_semantics"]` and `data["mask_*"]` instead.

This module defines a small adapter transform and registers it into
HAT's OBJECT_REGISTRY.
"""

from hat.registry import OBJECT_REGISTRY


@OBJECT_REGISTRY.register
class GTOccInfoFromVoxelSemantics:
    """Create `gt_occ_info` for FlashOcc transforms."""

    def __call__(self, data):
        if "gt_occ_info" not in data:
            data["gt_occ_info"] = dict(
                voxel_semantics=data["voxel_semantics"],
                mask_lidar=data["mask_lidar"],
                mask_camera=data["mask_camera"],
            )
        return data

