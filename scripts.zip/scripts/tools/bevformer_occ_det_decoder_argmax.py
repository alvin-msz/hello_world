"""BevformerOccDetDecoder with BPU-mappable OCC ArgMax.

OE 3.7.0 HAT ``FlashOccDetDecoder`` / ``BevformerOccDetDecoder`` do not
implement ``add_argmax_for_compile``. This subclass inserts ArgMax on the
**quantized INT8 logits** (before ``DeQuantStub``) so hbdk can lower it to
the BPU ArgMax op.

Do **not** dequant then argmax then ``.to(int8)``:

* float ArgMax after DeQuant is not a BPU op; the compiler may emit an
  OCC output with ``alignedByteSize == 0`` (board dumps 0-byte bins);
* ``.to(int8)`` after indices is often treated as a Quantize of a node
  that never had observers, which also yields an empty / dummy output.

Native BPU ArgMax writes INT32 class ids ``[B, Dx, Dy, Dz]``. Per-tensor
FakeQuant makes INT8 argmax match dequant+argmax; per-channel scales can
differ slightly from CPU ``OccArgmaxNdhwcPacked``.
"""

from typing import Dict, List, Union

import torch
from hat.models.structures.bevfusion import BevFusionHbirInfer
from hat.models.task_modules.flashocc.decoder import BevformerOccDetDecoder
from hat.registry import OBJECT_REGISTRY
from torch import Tensor


@OBJECT_REGISTRY.register
class BevformerOccDetDecoderArgmax(BevformerOccDetDecoder):
    """BevformerOccDetDecoder variant for compile-time OCC argmax on BPU."""

    def __init__(self, add_argmax_for_compile: bool = False, **kwargs):
        super().__init__(**kwargs)
        self.add_argmax_for_compile = add_argmax_for_compile

    def forward(
        self, bev_feat: Union[Tensor, List[Tensor]], data: Dict
    ):
        if not self.is_compile:
            gt_occ_info = data["seq_meta"][0]
        else:
            gt_occ_info = {}

        if isinstance(bev_feat, (list, tuple)):
            bev_feat = bev_feat[0]
        if self.roi_resizer is not None:
            bev_feat = self.roi_resizer([bev_feat])["roi_feat0"]

        occ_preds = self.occ_head(bev_feat)
        if self.is_compile and self.add_argmax_for_compile:
            # ArgMax on quantized logits, INT32 indices. No DeQuant / Quantize.
            return [occ_preds.argmax(dim=-1).to(dtype=torch.int32)]

        occ_preds = self.dequant(occ_preds)
        if self.is_compile:
            return [occ_preds]

        result = self._post_process(occ_preds, gt_occ_info)
        if self.training:
            return result
        return [result["occ_pre"]]


@OBJECT_REGISTRY.register
class BevFusionHbirInferArgmax(BevFusionHbirInfer):
    """HBIR infer for OCC graphs that already emitted class ids."""

    def forward(self, data):
        inputs = self.process_input(data)
        outputs = self.ir_model(inputs)

        bev_embed, outputs_classes, reference_out, outputs_coords = outputs[0]
        bev_outputs = self.deploy_model.bev_decoders[0].get_outputs(
            [outputs_classes], [reference_out], [outputs_coords], bev_embed
        )
        result = self.deploy_model.bev_decoders[0].post_process(bev_outputs)
        bev_results = self._update_res(result, None)

        occ = outputs[1][0]
        if hasattr(occ, "dim") and occ.dim() >= 5:
            occ_res = occ.softmax(-1).argmax(-1)
        else:
            occ_res = occ
        return bev_results, [occ_res]
