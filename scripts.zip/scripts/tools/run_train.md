export FLASHOCC_DATA_ROOTDIR=/open_explorer/data/occ3d_nuscenes

# 训练浮点模型
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/train.py \
  --stage float \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py \
  --device-ids 0

# 导出calibration模型 | "calibration_trainer"
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/train.py \
  --stage calibration \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py \
  --device-ids 0

# QAT训练 | "qat_trainer"
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/train.py \
  --stage qat \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py \
  --device-ids 0

# 导出量化 HBIR（生成 quantized.bc） | "deploy_model_convert_pipeline" | "hbir_exporter"
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/export_hbir.py \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py

# 编译成板端部署模型（HBM） | "compile_cfg"
python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/compile_perf_hbir.py \
  --config samples/ai_toolchain/horizon_model_train_sample/scripts/configs/occ/flashocc_henet_lss_occ3d_nuscenes.py