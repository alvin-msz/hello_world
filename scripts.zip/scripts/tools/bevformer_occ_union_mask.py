"""BevformerOccDetDecoder with fusion mask and Occ3D-safe OCC losses.

HAT ``FlashOccDetDecoder._post_process`` computes ``mask_lidar | mask_camera``
then overwrites it because the next branch is ``if lidar_input`` rather than
``elif``. This subclass keeps the union.

Occ3D vis is a surface-hit mask. Non-vis is *unknown*, not free. Full-grid
``geo_scal`` / FREE ``sem_scal`` (treat every FREE label as empty) forces
distant columns to FREE, suppresses courtyard objects through C2H, and
makes ground classes fight FREE specificity. That path is not used.

Current loss (no absolute z-band, no FREE CE mixed into occupied CE):

* Occupied CE on vis — unchanged (HAT ``sum(w·ce)/sum(w)``).
* ``sem_scal`` on vis — per-class P/R/spec among occupied labels; skip FREE.
* ``geo_scal`` on vis ∪ known-empty — known-empty = FREE above the column
  hit (column-relative). Unknown stays out of the set.
"""
from typing import Dict

import torch
import torch.nn.functional as F
from hat.models.task_modules.flashocc.decoder import BevformerOccDetDecoder
from hat.registry import OBJECT_REGISTRY

from ego_occ_rotate import OCC3D_FREE_INDEX
from lovasz_softmax import lovasz_softmax
from occ_scal_loss import free_above_hits_mask, known_empty_geo_scal, sem_scal_loss


@OBJECT_REGISTRY.register
class BevformerOccDetDecoderUnionMask(BevformerOccDetDecoder):
    """Fusion union mask + Occ3D-safe scal losses + Lovász-Softmax."""

    def __init__(
        self,
        add_sem_scal: bool = True,
        add_geo_scal: bool = True,
        add_lovasz: bool = True,
        sem_scal_weight: float = 0.5,
        geo_scal_weight: float = 0.2,
        lovasz_weight: float = 1.0,
        free_index: int = OCC3D_FREE_INDEX,
        ignore_index: int = 255,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.add_sem_scal = bool(add_sem_scal)
        self.add_geo_scal = bool(add_geo_scal)
        self.add_lovasz = bool(add_lovasz)
        self.sem_scal_weight = float(sem_scal_weight)
        self.geo_scal_weight = float(geo_scal_weight)
        self.lovasz_weight = float(lovasz_weight)
        self.free_index = int(free_index)
        self.ignore_index = int(ignore_index)

    def _visibility_mask(self, data: Dict) -> torch.Tensor:
        if self.lidar_input and self.camera_input:
            return (
                data["gt_occ_info"]["mask_lidar"]
                | data["gt_occ_info"]["mask_camera"]
            )
        if self.lidar_input:
            return data["gt_occ_info"]["mask_lidar"]
        if self.camera_input:
            return data["gt_occ_info"]["mask_camera"]
        raise ValueError(
            "BevformerOccDetDecoderUnionMask needs lidar_input "
            "and/or camera_input"
        )

    def _loss(self, occ_pred, voxel_semantics, vis, known_empty):
        target = voxel_semantics.long()
        preds = occ_pred.reshape(-1, self.num_classes)
        vis_f = vis.reshape(-1).to(dtype=preds.dtype)
        losses = {
            "loss_occ": self.loss_occ(preds, target.reshape(-1), vis_f)
        }

        vis_b = vis.to(dtype=torch.bool)
        if self.add_sem_scal and self.sem_scal_weight > 0:
            sem_target = target.clone().masked_fill(~vis_b, self.ignore_index)
            logits = occ_pred.permute(0, 4, 1, 2, 3).contiguous()
            losses["loss_sem_scal"] = self.sem_scal_weight * sem_scal_loss(
                logits,
                sem_target,
                ignore_index=self.ignore_index,
                # others + free
                skip_classes=(0, self.free_index,),
            )

        if self.add_geo_scal and self.geo_scal_weight > 0:
            losses["loss_geo_scal"] = self.geo_scal_weight * known_empty_geo_scal(
                occ_pred,
                vis_b,
                known_empty,
                free_index=self.free_index,
            )

        if self.add_lovasz and self.lovasz_weight > 0:
            # IoU surrogate on vis voxels only — same labelled set that CE /
            # sem_scal already supervise. Non-vis (unknown) and free (17, almost
            # never on vis) are dropped via ignore / 'present'.
            probas = F.softmax(occ_pred.float().permute(0, 4, 1, 2, 3), dim=1)
            lovasz_target = target.clone().masked_fill(~vis_b, self.ignore_index)
            losses["loss_lovasz"] = self.lovasz_weight * lovasz_softmax(
                probas,
                lovasz_target,
                classes="present",
                per_image=False,
                ignore=self.ignore_index,
            )
        return losses

    def _post_process(self, occ_preds, data: Dict):
        if self.training:
            voxel_semantics = data["gt_occ_info"]["voxel_semantics"]
            vis = self._visibility_mask(data)
            known_empty = free_above_hits_mask(
                vis, voxel_semantics, free_index=self.free_index
            )
            return self._loss(occ_preds, voxel_semantics, vis, known_empty)
        occ_pred = self._decode(occ_preds)
        return {"occ_pre": occ_pred}
