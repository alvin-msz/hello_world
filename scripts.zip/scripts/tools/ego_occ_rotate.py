"""Keep ego OCC voxels aligned with ``BevBBoxRotation``.

HAT loads native Occ3D voxels in the sampler *before* transforms and never
resamples them. ``BevBBoxRotation`` rotates ``ego2img`` / boxes / points but
does not touch ``gt_occ_info``. It also does not write the sampled yaw back
unless ``data["scenes_aug"]["angle"]`` is already set.

Put these two transforms around ``BevBBoxRotation``:

1. ``SampleBevRotationAngle`` — sample yaw into ``scenes_aug["angle"]``
2. ``BevBBoxRotation`` — HAT uses that angle
3. ``RotateEgoOccVoxels`` — yaw-rotate ``voxel_semantics`` / masks with the
   same inverse mapping as ``BevBBoxRotation.point_rotate``

Range split used by the ``*_ego*`` configs (nuScenes / Occ3D defaults):

* ``OCC3D_PC_RANGE`` — OCC GT / C2H / visualization (16 × 0.4 m)
* ``VT_DET_PC_RANGE`` — BEVFormer VT + detection. Z is ``[-1.8, 6.2]``
  (span 8.0 m) so HAT ``gen_reference_points`` gets integer
  ``Z = z_max - z_min``, and after the 0.5 m inset the samples
  ``linspace(-1.3, 5.7, N)`` still cover Occ3D ``[-1, 5.4]``.
* ``LIDAR_EGO_PC_RANGE`` — CenterPoint pillarization (XY ±51.2 m / 0.2 m,
  same 8 m Z). PointPillar still collapses Z; do not use Occ3D 6.4 m.

If your lidar crop / perception ROI is **not** nuScenes, retune here then
keep the three configs importing these constants. Do not mix old checkpoints.

1. OCC labels (must match the npz/LMDB voxel grid)::

       OCC3D_PC_RANGE / RESOLUTION / GRID_SIZE
       viz ``vcs_range`` = OCC3D_PC_RANGE

2. VT + det XY must stay 1:1 with the OCC BEV if ``use_upsample=False``
   (200×200 @ 0.4 m ⇒ ±40 m). If OCC XY changes, also change
   ``bev_h_`` / ``bev_w_`` / ``vt_virtual_bev_*``.

3. VT + det Z: keep span **8.0** (HAT treats metres as the dummy bin
   count). Pad the OCC z-interval by 0.8 m each side so the 0.5 m inset
   does not clip OCC bounds::

       occ_z_min, occ_z_max = ...          # e.g. -1.0, 5.4  (span 6.4)
       VT_DET_Z_RANGE = (occ_z_min - 0.8, occ_z_max + 0.8)  # span 8.0
       # HAT samples: linspace(z_min+0.5, z_max-0.5, N)

   Detection ``pc_range`` and BPU ``bev_range`` must use this band, not
   OCC z. Retrain after any z change.

4. LiDAR pillar XY is the CenterPoint encoder grid, **not** the OCC
   grid. Official: ±51.2 / 0.2 → 512 scatter → 128×128 @ 0.8 m neck.
   Fusion then crops center ±OCC_XY (roi ``(14,14,114,114)`` for
   ±40 vs ±51.2). If lidar XY or voxel size changes::

       nx = (x_max - x_min) / voxel_x          # must suit SECOND strides
       neck_res = voxel_x * out_size_factor    # 0.2 * 4 = 0.8
       roi_i0 = (occ_x_min - lidar_x_min) / neck_res

   Changing lidar XY to ±40 requires retraining CenterPoint (400×400
   scatter, different neck). Keep XY ±51.2 if you want the pretrained
   SECOND layout.

5. BPU JSON: preprocess ``back/front/right/left/bottom/top`` =
   ``LIDAR_EGO_PC_RANGE``; postprocess ``bev_range`` = ``VT_DET_PC_RANGE``.
"""
from __future__ import annotations

from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np

from hat.registry import OBJECT_REGISTRY

# Occ3D-nuScenes ego grid — https://github.com/Tsinghua-MARS-Lab/Occ3D
OCC3D_PC_RANGE = (-40.0, -40.0, -1.0, 40.0, 40.0, 5.4)
OCC3D_RESOLUTION = (0.4, 0.4, 0.4)
OCC3D_GRID_SIZE = (200, 200, 16)
OCC3D_FREE_INDEX = 17

# HAT VT ``Z = pc_range[5] - pc_range[2]`` must be 8.0 (official lidar span).
# Pad Occ3D z [-1, 5.4] by 0.8 m each side so samples cover both OCC bounds.
# XY stays Occ3D ±40 m so 200×200 BEV cells still match OCC labels.
VT_DET_Z_RANGE = (-1.8, 6.2)
VT_DET_PC_RANGE = (
    OCC3D_PC_RANGE[0],
    OCC3D_PC_RANGE[1],
    VT_DET_Z_RANGE[0],
    OCC3D_PC_RANGE[3],
    OCC3D_PC_RANGE[4],
    VT_DET_Z_RANGE[1],
)

# Aliases used by rotation helpers (Occ3D XY / Z, not the 8 m VT band).
_OCC_PC_RANGE = OCC3D_PC_RANGE
_OCC_RESOLUTION = OCC3D_RESOLUTION
_FREE_INDEX = OCC3D_FREE_INDEX

# LiDAR voxelization in ego: CenterPoint XY (±51.2 m / 0.2 m) + 8 m Z pillar.
LIDAR_EGO_XY_RANGE = (-51.2, -51.2, 51.2, 51.2)
LIDAR_EGO_Z_RANGE = VT_DET_Z_RANGE
LIDAR_EGO_PC_RANGE = (
    LIDAR_EGO_XY_RANGE[0],
    LIDAR_EGO_XY_RANGE[1],
    LIDAR_EGO_Z_RANGE[0],
    LIDAR_EGO_XY_RANGE[2],
    LIDAR_EGO_XY_RANGE[3],
    LIDAR_EGO_Z_RANGE[1],
)
LIDAR_EGO_VOXEL_SIZE = (0.2, 0.2, LIDAR_EGO_Z_RANGE[1] - LIDAR_EGO_Z_RANGE[0])


def occ3d_z_layer_centers(
    pc_range: Sequence[float] = OCC3D_PC_RANGE,
    resolution: Sequence[float] = OCC3D_RESOLUTION,
    dz: int = OCC3D_GRID_SIZE[2],
) -> np.ndarray:
    """Return physical z (m) at the center of each Occ3D vertical layer."""
    z0, z1 = float(pc_range[2]), float(pc_range[5])
    return z0 + (np.arange(dz, dtype=np.float64) + 0.5) * float(resolution[2])


def occ3d_vt_pillar_z_samples(
    num_points: int,
    pc_range: Sequence[float] = VT_DET_PC_RANGE,
) -> np.ndarray:
    """HAT VT physical z: ``linspace(z_min+0.5, z_max-0.5, N)`` meters."""
    z0, z1 = float(pc_range[2]), float(pc_range[5])
    n = int(num_points)
    if n <= 1:
        return np.array([(z0 + z1) * 0.5], dtype=np.float64)
    return np.linspace(z0 + 0.5, z1 - 0.5, n, dtype=np.float64)


def _as_numpy(arr) -> np.ndarray:
    if hasattr(arr, "detach"):
        arr = arr.detach().cpu().numpy()
    return np.asarray(arr)


def rotate_occ_yaw(
    voxels: np.ndarray,
    angle: float,
    fill: int,
    pc_range: Sequence[float] = _OCC_PC_RANGE,
    resolution: Sequence[float] = _OCC_RESOLUTION,
) -> np.ndarray:
    """Yaw-rotate an Occ3D grid so dest cell p gets the label at R^{-1} p.

    Matches ``BevBBoxRotation.point_rotate``: ``p_new = R_z(angle) @ p_old``.
    Out-of-range cells are filled (free=17 for semantics, 0 for masks).
    """
    vol = _as_numpy(voxels)
    if vol.ndim != 3:
        raise ValueError(f"OCC volume must be (X, Y, Z), got {vol.shape}")
    nx, ny, nz = vol.shape
    c = float(np.cos(angle))
    s = float(np.sin(angle))
    xs = pc_range[0] + (np.arange(nx, dtype=np.float64) + 0.5) * resolution[0]
    ys = pc_range[1] + (np.arange(ny, dtype=np.float64) + 0.5) * resolution[1]
    xd, yd = np.meshgrid(xs, ys, indexing="ij")
    x_src = c * xd + s * yd
    y_src = -s * xd + c * yd
    i_src = np.floor((x_src - pc_range[0]) / resolution[0]).astype(np.int32)
    j_src = np.floor((y_src - pc_range[1]) / resolution[1]).astype(np.int32)
    valid = (i_src >= 0) & (i_src < nx) & (j_src >= 0) & (j_src < ny)
    out = np.full(vol.shape, fill, dtype=vol.dtype)
    ii, jj = np.nonzero(valid)
    out[ii, jj, :] = vol[i_src[ii, jj], j_src[ii, jj], :]
    return out


@OBJECT_REGISTRY.register
class SampleBevRotationAngle:
    """Write ``data["scenes_aug"]["angle"]`` so ``BevBBoxRotation`` reuses it."""

    def __init__(
        self, rotation_3d_range: Tuple[float, float] = (-0.3925, 0.3925)
    ):
        self.rotation_3d_range = rotation_3d_range

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        scenes_aug = data.get("scenes_aug")
        if not isinstance(scenes_aug, dict):
            scenes_aug = {}
            data["scenes_aug"] = scenes_aug
        if "angle" not in scenes_aug:
            scenes_aug["angle"] = float(
                np.random.uniform(*self.rotation_3d_range)
            )
        return data


@OBJECT_REGISTRY.register
class RotateEgoOccVoxels:
    """Rotate ``gt_occ_info`` voxels by ``scenes_aug["angle"]`` (radians)."""

    def __init__(
        self,
        pc_range: Sequence[float] = OCC3D_PC_RANGE,
        resolution: Sequence[float] = OCC3D_RESOLUTION,
        free_index: int = OCC3D_FREE_INDEX,
        occ_keys: Sequence[str] = ("voxel_semantics", "ego_voxel_semantics"),
        mask_keys: Sequence[str] = ("mask_lidar", "mask_camera"),
    ):
        self.pc_range = tuple(pc_range)
        self.resolution = tuple(resolution)
        self.free_index = int(free_index)
        self.occ_keys = tuple(occ_keys)
        self.mask_keys = tuple(mask_keys)

    def _angle(self, data: Dict[str, Any]) -> Optional[float]:
        scenes_aug = data.get("scenes_aug")
        if isinstance(scenes_aug, dict) and "angle" in scenes_aug:
            return float(scenes_aug["angle"])
        return None

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        gt = data.get("gt_occ_info")
        if not isinstance(gt, dict):
            return data
        angle = self._angle(data)
        if angle is None or abs(angle) < 1e-12:
            return data
        for key in self.occ_keys:
            if key in gt and gt[key] is not None:
                gt[key] = rotate_occ_yaw(
                    gt[key],
                    angle,
                    fill=self.free_index,
                    pc_range=self.pc_range,
                    resolution=self.resolution,
                )
        for key in self.mask_keys:
            if key in gt and gt[key] is not None:
                gt[key] = rotate_occ_yaw(
                    gt[key],
                    angle,
                    fill=0,
                    pc_range=self.pc_range,
                    resolution=self.resolution,
                )
        data["gt_occ_info"] = gt
        return data
