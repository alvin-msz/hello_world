"""Occ3D-safe scene-scale occupancy losses.

SurroundOcc / OCCFusion ``geo_scal`` / ``sem_scal`` assume a *dense* empty
label. Occ3D ``mask_lidar|mask_camera`` is a surface-hit mask: non-vis means
*unknown*, not free. Full-grid empty supervision (treat every FREE voxel as
empty) pushes distant / occluded columns to FREE, washes out courtyard
objects via C2H, and fights ground classes with FREE specificity — that
failure mode is intentionally avoided here.

Safe recipe:

* ``sem_scal`` on vis voxels only (occupied semantics; FREE almost never in vis).
* ``geo_scal`` on ``vis`` ∪ ``known_empty`` only. ``known_empty`` must be
  evidence-based (e.g. FREE above a column hit), never ``~vis``.
"""
from __future__ import annotations

from typing import Optional, Sequence

import torch
import torch.nn.functional as F
from torch.amp import autocast

_EPS = 1e-6


def _bce_ones(prob: torch.Tensor, eps: float = _EPS) -> torch.Tensor:
    """BCE(p, 1) = -log(p). Avoid F.binary_cross_entropy (unsafe under AMP)."""
    prob = prob.float().clamp(eps, 1.0 - eps)
    return -torch.log(prob)


@autocast("cuda", enabled=False)
def geo_scal_binary(
    nonempty_prob: torch.Tensor,
    nonempty_target: torch.Tensor,
    valid: torch.Tensor,
) -> torch.Tensor:
    """Binary occupancy geo_scal (precision + recall + specificity).

    Args:
        nonempty_prob: predicted P(occupied) in ``[0, 1]``.
        nonempty_target: 1 = occupied, 0 = known empty.
        valid: voxels that participate (occupied ∪ known empty). Unknown
            must be False so they never contribute to specificity.
    """
    nonempty_prob = nonempty_prob.float()
    mask = valid.reshape(-1).to(dtype=torch.bool)
    if int(mask.sum()) == 0:
        return nonempty_prob.new_zeros(())
    target = nonempty_target.reshape(-1)[mask].float()
    nonempty_p = nonempty_prob.reshape(-1)[mask]
    empty_p = 1.0 - nonempty_p
    gt_pos = target.sum()
    gt_neg = (1.0 - target).sum()
    pred_pos = nonempty_p.sum()
    intersection = (target * nonempty_p).sum()
    loss = nonempty_p.new_zeros(())
    if pred_pos > 0:
        loss = loss + _bce_ones(intersection / pred_pos)
    if gt_pos > 0:
        loss = loss + _bce_ones(intersection / gt_pos)
    if gt_neg > 0:
        spec = ((1.0 - target) * empty_p).sum() / gt_neg
        loss = loss + _bce_ones(spec)
    return torch.nan_to_num(loss)


@autocast("cuda", enabled=False)
def sem_scal_loss(
    logits: torch.Tensor,
    target: torch.Tensor,
    ignore_index: int = 255,
    skip_classes: Optional[Sequence[int]] = None,
) -> torch.Tensor:
    """Per-class precision / recall / specificity on labelled voxels.

    Args:
        logits: ``(B, C, X, Y, Z)``.
        target: ``(B, X, Y, Z)``. ``ignore_index`` voxels are dropped.
        skip_classes: class ids to omit (e.g. Occ3D free=17 on vis-only
            targets, where free almost never appears).
    """
    logits = logits.float()
    pred = F.softmax(logits, dim=1)
    mask = target != ignore_index
    n_classes = pred.shape[1]
    skip = set(int(c) for c in (skip_classes or ()))
    loss = logits.new_zeros(())
    count = 0.0
    for cls_id in range(n_classes):
        if cls_id in skip:
            continue
        p = pred[:, cls_id][mask]
        completion = (target[mask] == cls_id).float()
        n_pos = completion.sum()
        if n_pos <= 0:
            continue
        count += 1.0
        nominator = (p * completion).sum()
        loss_cls = logits.new_zeros(())
        p_sum = p.sum()
        if p_sum > 0:
            loss_cls = loss_cls + _bce_ones(nominator / p_sum)
        loss_cls = loss_cls + _bce_ones(nominator / n_pos)
        n_neg = (1.0 - completion).sum()
        if n_neg > 0:
            spec = ((1.0 - p) * (1.0 - completion)).sum() / n_neg
            loss_cls = loss_cls + _bce_ones(spec)
        loss = loss + loss_cls
    if count <= 0:
        return logits.new_zeros(())
    return torch.nan_to_num(loss / count)


@autocast("cuda", enabled=False)
def known_empty_geo_scal(
    occ_pred: torch.Tensor,
    vis: torch.Tensor,
    known_empty: torch.Tensor,
    free_index: int,
) -> torch.Tensor:
    """geo_scal with Occ3D-safe empty set.

    Occupied = vis surface hits. Empty = ``known_empty`` only. Non-vis /
    non-known-empty voxels are *unknown* and are excluded — never treated
    as empty (avoids distant FREE collapse and courtyard wash-out).
    """
    nonempty_p = 1.0 - F.softmax(occ_pred.float(), dim=-1)[..., int(free_index)]
    vis_b = vis.to(dtype=torch.bool)
    empty_b = known_empty.to(dtype=torch.bool) & ~vis_b
    valid = vis_b | empty_b
    target = vis_b.to(dtype=nonempty_p.dtype)
    return geo_scal_binary(nonempty_p, target, valid)


def free_above_hits_mask(
    vis: torch.Tensor,
    voxel_semantics: torch.Tensor,
    free_index: int,
) -> torch.Tensor:
    """Known-empty: FREE voxels above the highest vis hit in each XY column.

    Column-relative (no absolute z band). Hollow object interiors below the
    top hit stay out of the empty set. Columns with no hit contribute nothing
    — distant / courtyard unknowns are not invented as empty.
    """
    vis_b = vis.to(dtype=torch.bool)
    dz = vis_b.shape[-1]
    z_ids = torch.arange(dz, device=vis_b.device).view(1, 1, 1, dz)
    z_max = (vis_b.float() * z_ids).amax(dim=-1, keepdim=True)
    has_hit = vis_b.any(dim=-1, keepdim=True)
    above = has_hit & (z_ids > z_max)
    return above & (voxel_semantics == int(free_index))
