import argparse
import logging
import os
from typing import Sequence, Union

import horizon_plugin_pytorch as horizon
import numpy as np
import torch

import hat
from hat.engine.launcher import get_launcher
from hat.registry import RegistryContext, build_from_registry
from hat.utils.config import Config
from hat.utils.distributed import get_dist_info
from hat.utils.logger import (
    LOG_DIR,
    DisableLogger,
    ExperimentLogger,
    MSGColor,
    format_msg,
    init_rank_logger,
    rank_zero_info,
    rank_zero_warn,
)
from hat.utils.seed import seed_training
from hat.utils.setup_env import setup_args_env, setup_hat_env

logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)-15s %(levelname)s %(message)s",
    level=logging.INFO,
)

# 兼容 torch>=2.6（weights_only 默认 True）：horizon_plugin_profiler 内部的
# torch.load(path) 加载坏例缓存含 numpy 数组/dtype 等，逐个 add_safe_globals
# 会一直漏（如 numpy.dtype[float64]）。这里全局兜底改回 weights_only=False。
_orig_torch_load = torch.load


def _patched_load(*args, **kwargs):
    kwargs.setdefault("weights_only", False)
    return _orig_torch_load(*args, **kwargs)


torch.load = _patched_load

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        "-c",
        type=str,
        required=True,
        help="config file path",
    )
    parser.add_argument(
        "--device-ids",
        "-ids",
        type=str,
        required=False,
        default=None,
        help="GPU device ids like '0,1,2,3', "
        "will override `device_ids` in config",
    )
    parser.add_argument(
        "--dist-url",
        type=str,
        default="auto",
        help="dist url for init process, such as tcp://localhost:8000",
    )
    parser.add_argument(
        "--backend",
        type=str,
        default="NCCL",
        choices=["NCCL", "GLOO"],
        help="dist url for init process",
    )
    parser.add_argument(
        "--launcher",
        type=str,
        choices=["torch", "mpi"],
        default=None,
        help="job launcher for multi machines",
    )
    parser.add_argument(
        "--level",
        type=int,
        default=logging.WARNING,
        help="Set the logging level for other rank except rank0",
    )
    parser.add_argument(
        "--enable-tracking",
        action="store_true",
        default=False,
        help="export HAT_ENABLE_MODEL_TRACKING=1, which enable aidi tracking",
    )

    known_args, unknown_args = parser.parse_known_args()
    return known_args, unknown_args


def quant_analysis_entrance(
    device: Union[None, int, Sequence[int]],
    cfg_file: str,
):
    if isinstance(cfg_file, Config):
        cfg = cfg_file
        cfg_file = cfg._filename
    else:
        # Avoid repeated fromfile causing different behaviors in same process
        cfg = Config.fromfile(cfg_file)

    rank, _ = get_dist_info()
    disable_logger = rank != 0 and cfg.get("log_rank_zero_only", False)

    # 1. init logger
    logger = init_rank_logger(
        rank,
        save_dir=cfg.get("log_dir", LOG_DIR),
        cfg_file=cfg_file,
        step="analysis",
        prefix="quant-analysis-",
    )

    if disable_logger:
        logger.info(
            format_msg(
                f"Logger of rank {rank} has been disable, turn off "
                "`log_rank_zero_only` in config if you don't want this.",
                MSGColor.GREEN,
            )
        )

    torch.backends.cudnn.benchmark = cfg.get("cudnn_benchmark", False)
    if cfg.get("seed", None) is not None:
        seed_training(cfg.seed)

    quant_analysis_solver = cfg.quant_analysis_solver

    rank_zero_info("=" * 50 + "BEGIN QUANT ANALYSIS" + "=" * 50)

    if "march" not in cfg:
        rank_zero_warn(
            format_msg(
                f"Please make sure the march is provided in configs. "
                f"Defaultly use {horizon.march.March.BAYES}",
                MSGColor.RED,
            )
        )
    horizon.march.set_march(cfg.get("march", horizon.march.March.BAYES))

    if quant_analysis_solver.get("out_dir", None) is None:
        save_path = "."
        if "ckpt_dir" in cfg:
            save_path = cfg.ckpt_dir
        else:
            logger.warning(
                "No ckpt_dir found in config file. Analysis results will be "
                + "saved in ./quant_analysis"
            )
        save_path = os.path.join(save_path, "quant_analysis")
        os.makedirs(save_path, exist_ok=True)
        quant_analysis_solver["out_dir"] = save_path
    with DisableLogger(disable_logger), RegistryContext():
        quant_analysis_solver["device_id"] = device
        quant_analysis = build_from_registry(quant_analysis_solver)
        quant_analysis()

    rank_zero_info("=" * 50 + "END QUANT ANALYSIS" + "=" * 50)


def quant_analysis(
    config: str,
    device_ids: str = None,
    dist_url: str = "auto",
    backend: str = "NCCL",
    launcher: str = None,
    args_env: list = None,
    enable_tracking: bool = False,
):
    if args_env:
        setup_args_env(args_env)
    stage = "quant_analysis"
    setup_hat_env(stage, enable_tracking=enable_tracking)

    config_info = Config.fromfile(config)

    if device_ids is not None:
        ids = list(map(int, device_ids.split(",")))
    else:
        ids = config_info.device_ids
    str_ids = list(map(str, ids))
    os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(str_ids)
    num_processes = len(ids)
    if ids is None or ids == -1:
        assert backend == "GLOO", f"backend should be GLOO, but get {backend}"
        num_processes = 1

    quant_analysis_solver = config_info.get("quant_analysis_solver", None)
    if quant_analysis_solver is None:
        raise RuntimeError("Please set quant_analysis_solver in config file.")

    experiment_logger = ExperimentLogger(enable_tracking=enable_tracking)
    experiment_logger.init_group("quant_analysis")

    launch = get_launcher("distributed_data_parallel_trainer")
    if launch is hat.engine.ddp_trainer.launch and launcher is not None:
        config_info = config_info
    else:
        config_info = config

    launch(
        quant_analysis_entrance,
        ids,
        dist_url=dist_url,
        dist_launcher=launcher,
        num_processes=num_processes,
        backend=backend,
        args=(config_info,),
    )


if __name__ == "__main__":
    try:
        args, args_env = parse_args()

        quant_analysis(
            config=args.config,
            device_ids=args.device_ids,
            dist_url=args.dist_url,
            backend=args.backend,
            launcher=args.launcher,
            args_env=args_env,
            enable_tracking=args.enable_tracking,
        )
    except Exception as e:
        ExperimentLogger.log_exception(
            exception=e,
            prefix="quant analysis failed",
            enable_tracking=args.enable_tracking,
        )
        raise e
