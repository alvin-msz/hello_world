python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/dataset_converters/create_data_flashocc.py \
  --src-data-path data/nuscenes \
  --out-dir data/occ3d_nuscenes