"""bpu preprocess tools, Only for ai benchmark hbm validation."""

import argparse
import os

import cv2

from hat.utils.config import Config
from hat.utils.logger import init_logger
from hat.registry import build_from_registry

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        "-c",
        type=str,
        required=True,
        help="config file path",
    )
    parser.add_argument(
        "--save-path",
        type=str,
        default="./data",
        help="save path for preprocess output.",
    )
    # 允许接受任意额外参数，形式为 --key value
    parser.add_argument(
        "--extra-args",
        nargs=argparse.REMAINDER,
        help="additional arguments passed to process_data",
    )
    return parser.parse_args()


def defualt_process_data(sample, save_path, i):
    image = sample["img"]
    image_name = f"{i}.png"
    cv2.imwrite(os.path.join(save_path, image_name), image)

def parse_extra_args(extra_args):
    """
    将 ["--key1", "val1", "--key2", "val2"] 转换成字典 {"key1": val1, "key2": val2}
    """
    result = {}
    if extra_args is None:
        return result

    key = None
    for arg in extra_args:
        if arg.startswith("--"):
            key = arg[2:].replace("-", "_")
            result[key] = True  # 如果是 flag 类型
        elif key:
            result[key] = arg
            key = None
    return result


if __name__ == "__main__":
    args = parse_args()

    # 解析 extra args 为 dict
    extra_args = parse_extra_args(args.extra_args)
    print(f"Extra args for process_data: {extra_args}")

    config = Config.fromfile(args.config)
    init_logger(f".hat_logs/{config.task_name}_bpu_val_preprocess")

    save_path = os.path.join(args.save_path, config.task_name)
    os.makedirs(save_path, exist_ok=True)
    print(f"Preprocess data will be saved in {save_path}")

    # get dataset
    val_dataset = config.get("bpu_val_dataset", None)
    val_dataset=build_from_registry(val_dataset)
    assert val_dataset is not None, "You must set bpu_val_dataset in config."
    process_data = config.get("bpu_preprocess_data", defualt_process_data)
    assert callable(process_data), "process_data must be callable."

    process_data(val_dataset, save_path, **extra_args)
    print("Preprocess finished!")
