#!/usr/bin/env python3
# Copyright (c) Horizon Robotics. All Rights Reserved.
"""BevFusion 浮点 / QAT 模型单帧 OCC 推理，导出与板端一致的 int16 bin。

输出格式对齐 ``QATBevFusionOcc4dPostProcessMethod::SaveOccPredBin``：
扁平 ``int16`` 类别标签，文件名默认 ``occ_rank0_{frame_id:06d}.bin``。

兼容以下配置（由 ``--config`` 决定 BEV / VT / 坐标系）::

    # BevFusion 多传感器（需点云 + 可选 deploy aux bin）
    bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_argmax_cpu.py
    bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_argmax_cpu_ego.py
    bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_vt_l2_argmax_cpu.py
    bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_vt_l2_argmax_cpu_ego.py

    # BevFormer 相机预训练（``lidar_input=False``，仅 img + 外参，无 deploy_inputs）
    bevformer_henet_camera_multitask_nuscenes_pretrain.py
    bevformer_henet_camera_multitask_nuscenes_pretrain_ego.py
    bevformer_henet_camera_multitask_nuscenes_vt_l2_pretrain.py
    bevformer_henet_camera_multitask_nuscenes_vt_l2_pretrain_ego.py

输入来源（三选一）::

  1. ``--sample-dir``：``prepare_nuscenes_mini_inputs.py`` 写出的样本目录
     （``img.bin``；多传感器还需 ``lidar_points.bin``）；外参从 ``--homo-dir`` /
     ``--infer-example-dir`` 的 ``lidar2img.npy`` / ``ego2img.npy`` 读取。
  2. ``--infer-example-dir``：6 路 jpg + 外参；多传感器还需 ``lidar.npy``。
  3. ``--from-val``：用 ``config.val_dataset``（``val_data_path`` LMDB）跑完整验证集，
     点云 ``num_sweeps`` 与 ``train_dataset`` 对齐（默认 9），
     每帧写出 ``occ_rank0_{idx:06d}.bin``，并生成 ``frames.lst``。

``--mode``::

  * ``float``（默认）：加载 ``cfg.model`` 在线 VT；多传感器含 PointPillar
    pre_process；相机预训练仅需图像与外参。
  * ``qat`` / ``calibration``：走 ``cfg.qat_predictor`` / ``calibration_predictor``
    的 ``ModelConvertPipeline``（``RepModel2Deploy`` → ``Float2QAT`` → 加载
    对应 checkpoint）。拓扑与 ``float`` 相同，权重为 fake-quant，不能把 QAT
    ckpt 直接 ``load`` 进浮点图。``Float2QAT`` 需要 config 里的 val LMDB
    做 example 前向。
  * ``deploy``：加载 ``cfg.deploy_model`` + aux grid bin（仅多传感器 argmax 配置
    有 ``deploy_inputs``；相机预训练请用 ``--mode float``）。

示例（lidar 系点云 + 官方浮点权重，一帧出 bin）::

    # 推荐：与权重同系的 lidar 配置
    python3 samples/ai_toolchain/horizon_model_train_sample/scripts/tools/infer_float_occ_one_frame.py \\
      -c samples/ai_toolchain/horizon_model_train_sample/scripts/configs/lidar_bevfusion/bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_argmax_cpu.py \\
      --ckpt ./tmp_pretrained_models/bevfusion_pointpillar_henet_multisensor_multitask/float-checkpoint-last.pth.tar \\
      --sample-dir ./samples/ucp_tutorial/dnn/ai_benchmark/runtime/qat/mini_data/bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_ego/sample_infer_example \\
      --homo-dir ./tmp_pretrained_models/bevfusion_pointpillar_henet_multisensor_multitask \\
      --point-coord-frame lidar \\
      --output-dir ./tmp/occ_float_bin \\
      --frame-id 0

    # 相机预训练（仅需 jpg + 外参，无需 lidar.npy）
    python3 .../infer_float_occ_one_frame.py \\
      -c .../bevformer_henet_camera_multitask_nuscenes_pretrain_ego.py \\
      --ckpt ./tmp_models/bevformer_henet_camera_multitask_nuscenes_ego/float-checkpoint-last.pth.tar \\
      --infer-example-dir ./tmp_pretrained_models/bevfusion_pointpillar_henet_multisensor_multitask \\
      --output-dir ./tmp/occ_float_bin

    # 验证集全量（config.val_data_path LMDB）
    python3 .../infer_float_occ_one_frame.py \\
      -c .../bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_argmax_cpu_ego.py \\
      --ckpt ./tmp_models/.../float-checkpoint-last.pth.tar \\
      --from-val \\
      --output-dir ./tmp/occ_float_bin_val

    # QAT 验证集（默认 ckpt_dir/qat-checkpoint-last.pth.tar）
    python3 .../infer_float_occ_one_frame.py \\
      -c .../bevfusion_pointpillar_henet_multisensor_multitask_nuscenes_argmax_cpu_ego.py \\
      --mode qat \\
      --from-val \\
      --output-dir ./tmp/occ_qat_bin_val

依赖：与训练相同的 HAT / horizon_plugin_pytorch / CUDA 环境（OE Docker）。
"""

from __future__ import annotations

import argparse
import copy
import json
import logging
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
import torch

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s"
)

AUX_BIN_NAMES = (
    "queries_rebatch_grid.bin",
    "restore_bev_grid.bin",
    "reference_points_rebatch.bin",
    "bev_pillar_counts.bin",
)
AUX_LOGICAL = (
    "queries_rebatch_grid",
    "restore_bev_grid",
    "reference_points_rebatch",
    "bev_pillar_counts",
)


def parse_args():
    p = argparse.ArgumentParser(
        description="BevFusion float/QAT OCC one-frame → int16 bin"
    )
    p.add_argument(
        "--config",
        "-c",
        required=True,
        help="argmax_cpu / ego / vt_l2 / vt_l2_ego 之一",
    )
    p.add_argument(
        "--ckpt",
        default=None,
        help=(
            "checkpoint；默认按 --mode 取 ckpt_dir 下 "
            "float-/qat-/calibration-checkpoint-last.pth.tar（没有 last 再试 best）"
        ),
    )
    p.add_argument(
        "--sample-dir",
        default=None,
        help="prepare 样本目录（img.bin；多传感器另需 lidar_points.bin）",
    )
    p.add_argument(
        "--infer-example-dir",
        default=None,
        help=(
            "含 img*.jpg + lidar2img.npy + ego2img.npy；"
            "多传感器还需 lidar.npy；相机预训练可省略点云"
        ),
    )
    p.add_argument(
        "--homo-dir",
        default=None,
        help="外参 npy 目录；默认回退到 --infer-example-dir",
    )
    p.add_argument(
        "--from-val",
        action="store_true",
        help="从 config.val_dataset / val_data_path 读取 nuScenes 验证集并逐帧出 bin",
    )
    p.add_argument(
        "--val-data-path",
        default=None,
        help="覆盖 config.val_data_path（LMDB 目录）",
    )
    p.add_argument(
        "--max-samples",
        type=int,
        default=-1,
        help="--from-val 时最多处理样本数，-1 表示全部",
    )
    p.add_argument(
        "--start-idx",
        type=int,
        default=0,
        help="--from-val 时跳过前 N 个样本（frame_id 仍按全集序号）",
    )
    p.add_argument(
        "--num-workers",
        type=int,
        default=4,
        help="--from-val DataLoader workers",
    )
    p.add_argument(
        "--num-sweeps",
        type=int,
        default=None,
        help=(
            "--from-val 多扫点数；默认对齐 train_dataset.num_sweeps "
            "（这些配置为 9），再回退 val_dataset"
        ),
    )
    p.add_argument(
        "--output-dir",
        required=True,
        help="OCC bin 输出目录",
    )
    p.add_argument(
        "--frame-id",
        type=int,
        default=0,
        help="写入文件名中的 frame_id（默认 0）",
    )
    p.add_argument(
        "--bin-prefix",
        default="occ_rank0_",
        help="与板端 eval_bin_prefix 一致，默认 occ_rank0_",
    )
    p.add_argument(
        "--mode",
        choices=("float", "deploy", "qat", "calibration"),
        default="float",
        help=(
            "float=完整浮点模型在线 VT；qat/calibration=同一拓扑经 Float2QAT 后"
            "加载对应 ckpt；deploy=吃准备好的 aux grid bin（浮点 deploy 图）"
        ),
    )
    p.add_argument(
        "--point-coord-frame",
        choices=("auto", "lidar", "ego"),
        default="lidar",
        help=(
            "输入点云坐标系（默认 lidar，与 pretrained lidar.npy / "
            "prepare 未做 lidar→ego 时一致）。"
            "若与模型期望不一致（ego 配置需 ego 点云），会自动 lidar→ego。"
            "auto=假定输入已与 config.use_lidar2img 一致、不做变换。"
        ),
    )
    p.add_argument(
        "--device",
        default="cuda:0",
    )
    p.add_argument(
        "--tools-dir",
        default=None,
        help="scripts/tools；默认取本文件所在目录",
    )
    p.add_argument(
        "--orig-hw",
        default="900,1600",
        help="外参缩放用的原图 HxW（nuScenes 相机默认 900,1600）",
    )
    p.add_argument(
        "--save-npy",
        action="store_true",
        help="额外保存 semantics.npy（int16，带 shape）便于检查",
    )
    return p.parse_args()


def _ensure_tools_path(config_path: str, tools_dir: Optional[str]) -> Path:
    if tools_dir:
        td = Path(tools_dir).resolve()
    else:
        td = Path(__file__).resolve().parent
    if str(td) not in sys.path:
        sys.path.insert(0, str(td))
    # ego / vt configs may import local adapters next to tools
    cfg_dir = Path(config_path).resolve().parent
    for extra in (td, cfg_dir):
        if str(extra) not in sys.path:
            sys.path.insert(0, str(extra))
    return td


def load_hat_config(config_path: str, tools_dir: Optional[str]):
    _ensure_tools_path(config_path, tools_dir)
    from hat.utils.config import Config

    return Config.fromfile(str(Path(config_path).resolve()))


def is_camera_only(cfg) -> bool:
    """``lidar_input=False`` 或 model 无 lidar_network（BevFormer 相机预训练）。"""
    if getattr(cfg, "lidar_input", None) is False:
        return True
    model = getattr(cfg, "model", None)
    if isinstance(model, dict) and model.get("lidar_network") is None:
        return True
    return False


def has_deploy_pipeline(cfg) -> bool:
    return (
        getattr(cfg, "deploy_model", None) is not None
        and getattr(cfg, "deploy_inputs", None) is not None
    )


def resolve_img_shape(cfg) -> Tuple[int, ...]:
    """图像张量逻辑 shape；无 deploy_inputs 时从 input_size 推导。"""
    di = getattr(cfg, "deploy_inputs", None)
    if di is not None and "img" in di:
        return tuple(int(x) for x in di["img"].shape)
    rs = getattr(cfg, "resize_shape", None)
    vs = getattr(cfg, "val_data_shape", None)
    for src in (vs, rs):
        if src is not None and len(src) >= 3:
            return (6, int(src[0]), int(src[1]), int(src[2]))
    inp = getattr(cfg, "input_size", (512, 960))
    return (6, 3, int(inp[0]), int(inp[1]))


def occ_decoder_index(cfg) -> int:
    """OCC 在 model_outs 中的下标（det 在前时 index=1）。"""
    if getattr(cfg, "use_bev_head", True) and getattr(cfg, "use_occ_head", True):
        return 1
    return 0


def resize_homo(homo: np.ndarray, scale: Tuple[float, float]) -> np.ndarray:
    view = np.eye(4, dtype=np.float64)
    view[0, 0] = scale[1]
    view[1, 1] = scale[0]
    return (view @ homo.astype(np.float64)).astype(np.float32)


def crop_homo(homo: np.ndarray, offset: Tuple[float, float]) -> np.ndarray:
    view = np.eye(4, dtype=np.float64)
    view[0, 2] = -offset[0]
    view[1, 2] = -offset[1]
    return np.matmul(view, homo.astype(np.float64)).astype(np.float32)


def homography_resize_and_crop(
    homo_6: np.ndarray,
    resize_hw: Tuple[int, int],
    orig_hw: Tuple[int, int],
    val_hw: Tuple[int, int],
) -> np.ndarray:
    """与 prepare_nuscenes_mini_inputs.homography_resize_and_crop 一致。"""
    rs = resize_hw
    vs = val_hw
    scale = (rs[0] / orig_hw[0], rs[1] / orig_hw[1])
    homo = resize_homo(homo_6.astype(np.float64), scale)
    top = int(rs[0] - vs[0])
    left = int((rs[1] - vs[1]) / 2)
    return crop_homo(homo, (left, top))


def load_homo_npy(path: Path) -> np.ndarray:
    arr = np.asarray(np.load(path), dtype=np.float64)
    if arr.ndim == 2 and arr.size == 96:
        arr = arr.reshape(6, 4, 4)
    if arr.shape[:2] != (6, 4):
        raise ValueError(f"{path} 期望 (6,4,4)，实际 {arr.shape}")
    return arr.astype(np.float32)


def sorted_infer_jpg_paths(infer_dir: Path) -> list[str]:
    jpgs = [
        p
        for p in infer_dir.iterdir()
        if p.suffix.lower() in (".jpg", ".jpeg")
    ]

    def keyfn(p: Path) -> int:
        m = re.search(r"img(\d+)_", p.name, re.I)
        return int(m.group(1)) if m else 10**9

    return [str(p) for p in sorted(jpgs, key=keyfn)]


def build_image_from_jpgs(
    img_paths: list[str], resize_hw: Tuple[int, int]
) -> Tuple[np.ndarray, Tuple[int, int]]:
    """与 prepare / config.process_inputs 相同：RGB→resize→pad→YUV444→Normalize。"""
    import horizon_plugin_pytorch as horizon
    from hat.data.transforms.functional_img import image_pad

    try:
        from torchvision.transforms.functional import resize
    except ImportError:
        from torchvision.transforms._functional_tensor import resize

    views = []
    first_orig: Optional[Tuple[int, int]] = None
    for ip in img_paths:
        bgr = cv2.imread(ip, cv2.IMREAD_COLOR)
        if bgr is None:
            raise FileNotFoundError(ip)
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        if first_orig is None:
            first_orig = (rgb.shape[0], rgb.shape[1])
        chw = torch.from_numpy(rgb.transpose(2, 0, 1)).float()
        resized = resize(chw, list(resize_hw))
        padded = image_pad(resized, "chw", None, 32, 0.0)
        t_u8 = padded.round().clamp(0, 255).to(dtype=torch.uint8)
        yuv = (
            horizon.nn.functional.bgr_to_yuv444(t_u8.unsqueeze(0), True)
            .squeeze(0)
            .float()
        )
        views.append((yuv - 128.0) / 128.0)
    stacked = torch.stack(views, dim=0).detach().cpu().numpy().astype(np.float32)
    assert first_orig is not None
    return stacked, first_orig


def load_points_from_bin(path: Path, max_points: int = 40000) -> np.ndarray:
    flat = np.fromfile(path, dtype=np.float32)
    if flat.size % 5 != 0:
        raise ValueError(f"{path} 元素数 {flat.size} 不能整除 5")
    pts = flat.reshape(-1, 5)
    if pts.shape[0] > max_points:
        pts = pts[:max_points]
    return pts


def load_img_bin(path: Path, shape: Tuple[int, ...]) -> np.ndarray:
    arr = np.fromfile(path, dtype=np.float32)
    expect = int(np.prod(shape))
    if arr.size != expect:
        raise ValueError(
            f"{path} 元素数 {arr.size} != deploy img shape {shape} ({expect})"
        )
    return arr.reshape(shape)


def load_aux_bin(
    path: Path, shape: Tuple[int, ...]
) -> np.ndarray:
    arr = np.fromfile(path, dtype=np.float32)
    expect = int(np.prod(shape))
    if arr.size != expect:
        raise ValueError(
            f"{path} 元素数 {arr.size} != expected shape {shape} ({expect})"
        )
    return arr.reshape(shape)


def infer_lidar2ego_from_homographies(
    lidar2img_6: np.ndarray, ego2img_6: np.ndarray, cam_index: int = 1
) -> np.ndarray:
    """与 prepare_nuscenes_mini_inputs.infer_lidar2ego_from_homographies 一致。"""
    lid2img = np.asarray(lidar2img_6[cam_index], dtype=np.float64)
    ego2img = np.asarray(ego2img_6[cam_index], dtype=np.float64)
    k_e2i = ego2img[:3, :3]
    k_inv = np.linalg.inv(k_e2i)
    ego2cam_34 = k_inv @ ego2img[:3, :4]
    ego2cam = np.eye(4, dtype=np.float64)
    ego2cam[:3, :4] = ego2cam_34
    cam2ego = np.linalg.inv(ego2cam)
    lid2cam_34 = k_inv @ lid2img[:3, :4]
    lid2cam = np.eye(4, dtype=np.float64)
    lid2cam[:3, :4] = lid2cam_34
    return (cam2ego @ lid2cam).astype(np.float64)


def transform_points_lidar_to_ego(
    pts: np.ndarray, lidar2ego: np.ndarray
) -> np.ndarray:
    out = np.asarray(pts, dtype=np.float32, order="C").copy()
    xyz = out[:, :3].astype(np.float64)
    ones = np.ones((xyz.shape[0], 1), dtype=np.float64)
    hom = np.concatenate([xyz, ones], axis=1)
    mapped = (lidar2ego.astype(np.float64) @ hom.T).T[:, :3].astype(np.float32)
    out[:, :3] = mapped
    return out


def resolve_model_point_frame(cfg) -> str:
    """模型期望的点云坐标系：use_lidar2img=True → lidar，否则 ego。"""
    return "lidar" if bool(getattr(cfg, "use_lidar2img", True)) else "ego"


def resolve_input_point_frame(cfg, arg_frame: str) -> str:
    """输入点云坐标系；auto 表示假定已与模型一致。"""
    if arg_frame != "auto":
        return arg_frame
    return resolve_model_point_frame(cfg)


def resolve_resize_val_hw(cfg) -> Tuple[Tuple[int, int], Tuple[int, int]]:
    rs = getattr(cfg, "resize_shape", None)
    vs = getattr(cfg, "val_data_shape", None)
    if rs is not None and len(rs) >= 3:
        resize_hw = (int(rs[1]), int(rs[2]))
    else:
        resize_hw = tuple(int(x) for x in cfg.input_size)
    if vs is not None and len(vs) >= 3:
        val_hw = (int(vs[1]), int(vs[2]))
    else:
        val_hw = resize_hw
    return resize_hw, val_hw


def _torch_load_ckpt(ckpt_path: str):
    """Load HAT checkpoint; PyTorch>=2.6 defaults weights_only=True and rejects numpy."""
    try:
        return torch.load(ckpt_path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(ckpt_path, map_location="cpu")


def build_float_model(cfg, ckpt_path: str, device: torch.device):
    import horizon_plugin_pytorch as horizon
    from hat.registry import RegistryContext, build_from_registry
    from hat.utils.checkpoint import load_state_dict

    horizon.march.set_march(cfg.march)
    with RegistryContext():
        model = build_from_registry(cfg.model)
    model.eval()
    model.to(device)
    load_state_dict(
        model,
        _torch_load_ckpt(ckpt_path),
        allow_miss=True,
        ignore_extra=True,
        verbose=True,
    )
    return model


def build_deploy_model(cfg, ckpt_path: str, device: torch.device):
    import horizon_plugin_pytorch as horizon
    from hat.registry import RegistryContext, build_from_registry
    from hat.utils.checkpoint import load_state_dict

    horizon.march.set_march(cfg.march)
    model_dict = getattr(cfg, "deploy_model", None) or cfg.model
    with RegistryContext():
        model = build_from_registry(model_dict)
    model.eval()
    model.to(device)
    load_state_dict(
        model,
        _torch_load_ckpt(ckpt_path),
        allow_miss=True,
        ignore_extra=True,
        verbose=True,
    )
    return model


def _cfg_item(cfg, key, default=None):
    if hasattr(cfg, "get"):
        return cfg.get(key, default)
    return getattr(cfg, key, default)


def _override_load_checkpoint(pipeline_cfg, ckpt_path: str) -> None:
    converters = pipeline_cfg.get("converters") if hasattr(pipeline_cfg, "get") else None
    if converters is None:
        converters = pipeline_cfg["converters"]
    found = False
    for conv in converters:
        ctype = conv.get("type") if hasattr(conv, "get") else None
        if ctype == "LoadCheckpoint":
            conv["checkpoint_path"] = ckpt_path
            conv["allow_miss"] = True
            conv["ignore_extra"] = True
            conv["verbose"] = True
            found = True
    if not found:
        converters.append(
            dict(
                type="LoadCheckpoint",
                checkpoint_path=ckpt_path,
                allow_miss=True,
                ignore_extra=True,
                verbose=True,
            )
        )


def _patch_example_dataloader_path(pipeline_cfg, val_data_path: Optional[str]) -> None:
    if not val_data_path:
        return
    converters = pipeline_cfg.get("converters")
    if converters is None:
        return
    for conv in converters:
        if conv.get("type") != "Float2QAT":
            continue
        dl = conv.get("example_data_loader")
        if dl is None:
            continue
        ds = dl.get("dataset") if hasattr(dl, "get") else None
        if ds is not None and hasattr(ds, "__setitem__"):
            ds["data_path"] = val_data_path
            logger.info("Float2QAT example_data_loader.data_path → %s", val_data_path)


def resolve_ckpt_path(cfg, mode: str, ckpt_arg: Optional[str]) -> str:
    if ckpt_arg:
        p = Path(ckpt_arg).resolve()
        if not p.is_file():
            raise FileNotFoundError(p)
        return str(p)
    ckpt_dir = Path(getattr(cfg, "ckpt_dir", "./tmp_models"))
    prefix = {
        "qat": "qat",
        "calibration": "calibration",
        "float": "float",
        "deploy": "float",
    }.get(mode, "float")
    candidates = [
        ckpt_dir / f"{prefix}-checkpoint-last.pth.tar",
        ckpt_dir / f"{prefix}-checkpoint-best.pth.tar",
    ]
    for p in candidates:
        if p.is_file():
            return str(p.resolve())
    raise FileNotFoundError(
        f"未指定 --ckpt，且找不到 {candidates[0]} 或 {candidates[1]}"
    )


def build_converted_model(
    cfg,
    stage: str,
    ckpt_path: str,
    device: torch.device,
    val_data_path: Optional[str] = None,
):
    """按 ``{stage}_predictor`` 做 Float2QAT 再加载 checkpoint（与 predict.py --stage 一致）。"""
    import horizon_plugin_pytorch as horizon
    from hat.registry import RegistryContext, build_from_registry

    pred_key = f"{stage}_predictor"
    predictor = _cfg_item(cfg, pred_key, None)
    if predictor is None:
        raise SystemExit(
            f"config 缺少 {pred_key}，无法 --mode {stage}。"
            "BevFusion 多传感器 argmax/ego 配置均有该字段。"
        )
    horizon.march.set_march(cfg.march)
    pipeline_cfg = copy.deepcopy(predictor["model_convert_pipeline"])
    _override_load_checkpoint(pipeline_cfg, ckpt_path)
    _patch_example_dataloader_path(pipeline_cfg, val_data_path)
    model_cfg = predictor["model"]
    convs = pipeline_cfg.get("converters", [])
    conv_types = []
    for c in convs:
        if hasattr(c, "get"):
            conv_types.append(c.get("type"))
        else:
            conv_types.append(getattr(c, "type", type(c).__name__))
    logger.info(
        "构建 %s 模型：pipeline converters=%s ckpt=%s",
        stage,
        conv_types,
        ckpt_path,
    )
    with RegistryContext():
        pipeline = build_from_registry(pipeline_cfg)
        model = build_from_registry(model_cfg)
        model = pipeline(model)
    model.eval()
    model.to(device)
    return model


def build_lidar_preprocess(cfg, device: torch.device):
    """从 cfg.model.lidar_network.pre_process 构建体素化模块。"""
    if is_camera_only(cfg):
        raise RuntimeError("相机预训练配置无 LiDAR pre_process")
    from hat.registry import RegistryContext, build_from_registry

    lidar_net = cfg.model.get("lidar_network")
    if not lidar_net or "pre_process" not in lidar_net:
        raise RuntimeError("config.model 缺少 lidar_network.pre_process")
    pp = lidar_net["pre_process"]
    with RegistryContext():
        preprocess = build_from_registry(pp)
    preprocess.eval()
    preprocess.to(device)
    return preprocess


@torch.no_grad()
def voxelize_points(
    preprocess, points_np: np.ndarray, device: torch.device
) -> Dict[str, torch.Tensor]:
    """返回 deploy 所需 features / coors。"""
    pts = torch.from_numpy(np.asarray(points_np, dtype=np.float32)).to(device)
    # CenterPointPreProcess 一般接受 list[Tensor] 或 dict
    try:
        out = preprocess([pts])
    except TypeError:
        out = preprocess({"points": [pts]})
    if isinstance(out, dict):
        features = out.get("features")
        coors = out.get("coors")
        if features is None or coors is None:
            # 部分实现键名不同
            for k, v in out.items():
                if "feat" in k.lower() and features is None:
                    features = v
                if "coor" in k.lower() and coors is None:
                    coors = v
        if features is None or coors is None:
            raise RuntimeError(f"pre_process 输出缺少 features/coors: {list(out)}")
        return {"features": features, "coors": coors}
    if isinstance(out, (list, tuple)) and len(out) >= 2:
        return {"features": out[0], "coors": out[1]}
    raise RuntimeError(f"无法解析 pre_process 输出类型: {type(out)}")


_SKIP_TO_DEVICE_KEYS = frozenset(
    {
        "lidar2img",
        "ego2img",
        "gt_occ_info",
        "voxel_semantics",
        "mask_lidar",
        "mask_camera",
    }
)


def to_device_for_infer(data: Any, device: torch.device) -> Any:
    """把 img / points 等张量搬到 GPU；外参保持 numpy（VT.point_sampling 需要）。"""
    if torch.is_tensor(data):
        return data.to(device, non_blocking=True)
    if isinstance(data, dict):
        out = {}
        for k, v in data.items():
            if k in _SKIP_TO_DEVICE_KEYS:
                out[k] = v
            else:
                out[k] = to_device_for_infer(v, device)
        return out
    if isinstance(data, list):
        return [to_device_for_infer(v, device) for v in data]
    if isinstance(data, tuple):
        return tuple(to_device_for_infer(v, device) for v in data)
    return data


def _tensor_to_float_cpu(t) -> torch.Tensor:
    """QAT 输出常为 QTensor，先 dequantize 再转 float CPU。"""
    if t is None:
        raise TypeError("OCC tensor is None")
    if hasattr(t, "dequantize"):
        try:
            dq = t.dequantize()
            if dq is not None:
                t = dq
        except Exception:
            pass
    if not torch.is_tensor(t):
        t = torch.as_tensor(t)
    return t.detach().float().cpu()


def _occ_raw_tensor(model_outs: Any, cfg=None) -> torch.Tensor:
    occ_idx = occ_decoder_index(cfg) if cfg is not None else 1
    if isinstance(model_outs, dict):
        for k in ("occ_pre", "occ", "semantics", "pred"):
            if k in model_outs:
                t = model_outs[k]
                break
        else:
            raise KeyError(f"dict 输出无 OCC 键: {list(model_outs)}")
    elif isinstance(model_outs, (list, tuple)):
        pick = occ_idx if len(model_outs) > occ_idx else (len(model_outs) - 1)
        occ = model_outs[pick]
        if isinstance(occ, dict):
            t = occ.get("occ_pre", occ.get("occ", occ.get("semantics")))
            if t is None:
                raise KeyError(f"OCC dict 无已知键: {list(occ)}")
        elif isinstance(occ, (list, tuple)):
            t = occ[0]
        else:
            t = occ
    else:
        t = model_outs
    t = _tensor_to_float_cpu(t)
    ncls = int(getattr(cfg, "num_classes_occ", 18)) if cfg is not None else 18
    if t.ndim >= 4 and int(t.shape[-1]) == ncls:
        t = t.argmax(dim=-1)
    elif t.ndim == 4 and int(t.shape[0]) == ncls:
        t = t.argmax(dim=0)
    return t


def extract_occ_semantics_list(model_outs: Any, cfg=None) -> List[np.ndarray]:
    """支持 batch：返回每帧 (H,W,Z) int32。"""
    t = _occ_raw_tensor(model_outs, cfg)
    if t.ndim == 3:
        return [t.numpy().astype(np.int32)]
    if t.ndim == 4:
        return [t[i].numpy().astype(np.int32) for i in range(t.shape[0])]
    raise ValueError(f"OCC 期望 3D/4D，实际 shape={tuple(t.shape)}")


def extract_occ_semantics(model_outs: Any, cfg=None) -> np.ndarray:
    arrs = extract_occ_semantics_list(model_outs, cfg)
    if len(arrs) != 1:
        raise ValueError(f"单帧路径期望 batch=1，实际 {len(arrs)}")
    return arrs[0]


def _meta_token(meta_item: Any) -> Optional[str]:
    if not isinstance(meta_item, dict):
        return None
    for k in ("token", "sample_token", "sample"):
        v = meta_item.get(k)
        if v is None:
            continue
        if isinstance(v, bytes):
            v = v.decode("utf-8", errors="ignore")
        s = str(v).strip()
        if s:
            return s
    return None


def sample_token_from_batch(batch: Dict[str, Any], b: int = 0) -> str:
    """从 collate 后的 batch 取 nuScenes sample token，没有则空串。"""
    seq = batch.get("seq_meta")
    if isinstance(seq, (list, tuple)) and seq:
        sm0 = seq[0] if not isinstance(seq[0], (list, tuple)) else seq[0]
        if isinstance(sm0, dict):
            metas = sm0.get("meta")
            if isinstance(metas, (list, tuple)) and b < len(metas):
                tok = _meta_token(metas[b])
                if tok:
                    return tok
            tok = _meta_token(sm0)
            if tok:
                return tok
    for k in ("token", "sample_token"):
        v = batch.get(k)
        if isinstance(v, (list, tuple)) and b < len(v):
            v = v[b]
        if v is not None and not isinstance(v, (list, dict)):
            s = str(v).strip()
            if s:
                return s
    return ""


def _cfg_mapping(obj) -> Optional[Any]:
    if obj is None:
        return None
    if isinstance(obj, dict) or hasattr(obj, "get"):
        return obj
    return None


def resolve_lidar_load_kwargs(cfg, num_sweeps_cli: Optional[int]) -> Dict[str, Any]:
    """与训练对齐的点云加载参数（num_sweeps / load_dim / use_dim / need_lidar）。

    优先级：CLI ``--num-sweeps`` > ``train_dataset`` > ``val_dataset``。
    多传感器默认 9 扫，与 NuscenesBevSequenceDataset 训练配置一致。
    """
    train_ds = _cfg_mapping(getattr(cfg, "train_dataset", None))
    val_ds = _cfg_mapping(getattr(cfg, "val_dataset", None))

    def _pick(key: str, default=None):
        if train_ds is not None and train_ds.get(key) is not None:
            return train_ds.get(key)
        if val_ds is not None and val_ds.get(key) is not None:
            return val_ds.get(key)
        return default

    camera_only = is_camera_only(cfg)
    default_sweeps = 1 if camera_only else 9
    num_sweeps = num_sweeps_cli
    if num_sweeps is None:
        num_sweeps = _pick("num_sweeps", default_sweeps)
    num_sweeps = int(num_sweeps)

    need_lidar = _pick("need_lidar", not camera_only)
    if not camera_only:
        need_lidar = True

    return {
        "num_sweeps": num_sweeps,
        "need_lidar": bool(need_lidar),
        "load_dim": int(_pick("load_dim", 5)),
        "use_dim": list(_pick("use_dim", [0, 1, 2, 3, 4])),
    }


def build_val_dataloader(
    cfg,
    val_data_path: Optional[str],
    num_workers: int,
    start_idx: int = 0,
    max_samples: int = -1,
    num_sweeps_cli: Optional[int] = None,
):
    """用 config.val_dataset 建单卡 DataLoader（不用 DistributedSampler）。

    点云多扫 ``num_sweeps`` 与训练 ``train_dataset`` 对齐（默认 9），
    避免 val 漏写时只跑 keyframe。
    """
    from hat.registry import RegistryContext, build_from_registry

    ds_cfg = getattr(cfg, "val_dataset", None)
    if ds_cfg is None:
        raise SystemExit("config 无 val_dataset，无法 --from-val")
    ds_cfg = copy.deepcopy(ds_cfg)
    if val_data_path:
        ds_cfg["data_path"] = val_data_path
    elif not ds_cfg.get("data_path"):
        vdp = getattr(cfg, "val_data_path", None)
        if not vdp:
            raise SystemExit("config 无 val_data_path")
        ds_cfg["data_path"] = vdp

    lidar_kw = resolve_lidar_load_kwargs(cfg, num_sweeps_cli)
    prev_sweeps = ds_cfg.get("num_sweeps")
    ds_cfg.update(lidar_kw)
    if prev_sweeps is not None and int(prev_sweeps) != lidar_kw["num_sweeps"]:
        logger.warning(
            "val_dataset.num_sweeps=%s 已改为 %d 以与训练对齐",
            prev_sweeps,
            lidar_kw["num_sweeps"],
        )
    logger.info(
        "val lidar load aligned to train: num_sweeps=%d need_lidar=%s "
        "load_dim=%s use_dim=%s",
        lidar_kw["num_sweeps"],
        lidar_kw["need_lidar"],
        lidar_kw["load_dim"],
        lidar_kw["use_dim"],
    )

    loader_cfg = getattr(cfg, "val_data_loader", None) or {}
    collate_fn = loader_cfg.get("collate_fn") if isinstance(loader_cfg, dict) else None

    with RegistryContext():
        dataset = build_from_registry(ds_cfg)

    n_all = len(dataset)
    start = max(0, int(start_idx))
    if start >= n_all:
        raise SystemExit(f"--start-idx {start} >= dataset len {n_all}")
    if max_samples >= 0:
        end = min(n_all, start + int(max_samples))
    else:
        end = n_all
    if start > 0 or end < n_all:
        dataset = torch.utils.data.Subset(dataset, list(range(start, end)))

    logger.info(
        "val dataset path=%s full_len=%d slice=[%d, %d) collate=%s",
        ds_cfg.get("data_path"),
        n_all,
        start,
        end,
        getattr(collate_fn, "__name__", type(collate_fn).__name__),
    )
    return (
        torch.utils.data.DataLoader(
            dataset,
            batch_size=1,
            shuffle=False,
            num_workers=max(0, int(num_workers)),
            pin_memory=True,
            collate_fn=collate_fn,
        ),
        start,
        lidar_kw,
    )


@torch.no_grad()
def run_val_inference(
    model,
    loader,
    cfg,
    device: torch.device,
    out_dir: Path,
    bin_prefix: str,
    save_npy: bool,
    max_samples: int,
    start_idx: int,
    lidar_kw: Optional[Dict[str, Any]] = None,
    extra_meta: Optional[Dict[str, Any]] = None,
) -> int:
    """逐帧推理验证集并写 bin + frames.lst。"""
    out_dir.mkdir(parents=True, exist_ok=True)
    frames_lines: List[str] = []
    index_meta: List[Dict[str, Any]] = []
    n_saved = 0
    for local_i, batch in enumerate(loader):
        if max_samples >= 0 and n_saved >= max_samples:
            break
        fwd = to_device_for_infer(batch, device)
        outs = model(fwd)
        arrs = extract_occ_semantics_list(outs, cfg)
        token = sample_token_from_batch(batch, 0)
        token_short = token[:8] if token else f"{start_idx + local_i:08d}"
        frame_id = start_idx + local_i
        semantics = arrs[0]
        save_occ_pred_bin(out_dir, semantics, frame_id, bin_prefix, save_npy)
        sample_tag = f"sample_{frame_id:04d}_{token_short}"
        frames_lines.append(str(out_dir / sample_tag) + "\n")
        index_meta.append(
            {
                "frame_id": frame_id,
                "bin": f"{bin_prefix}{frame_id:06d}.bin",
                "token": token,
                "shape": list(semantics.shape),
            }
        )
        n_saved += 1
        if n_saved % 20 == 0:
            logger.info(
                "val infer %d frames, last token=%s",
                n_saved,
                token or token_short,
            )

    lst_path = out_dir / "frames.lst"
    with open(lst_path, "w", encoding="utf-8") as f:
        f.writelines(frames_lines)
    with open(out_dir / "infer_val_meta.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "num_frames": n_saved,
                "start_idx": start_idx,
                "val_data_path": getattr(cfg, "val_data_path", None),
                "num_sweeps": (lidar_kw or {}).get("num_sweeps"),
                "need_lidar": (lidar_kw or {}).get("need_lidar"),
                "load_dim": (lidar_kw or {}).get("load_dim"),
                "use_dim": (lidar_kw or {}).get("use_dim"),
                **(extra_meta or {}),
                "frames": index_meta,
            },
            f,
            indent=2,
        )
    logger.info("Wrote %d bins + %s", n_saved, lst_path)
    return n_saved


def save_occ_pred_bin(
    out_dir: Path,
    semantics: np.ndarray,
    frame_id: int,
    bin_prefix: str,
    save_npy: bool,
) -> Path:
    """对齐 SaveOccPredBin：int16 扁平写盘。"""
    out_dir.mkdir(parents=True, exist_ok=True)
    pred = np.clip(semantics.reshape(-1), 0, 32767).astype(np.int16)
    name = f"{bin_prefix}{frame_id:06d}.bin"
    path = out_dir / name
    pred.tofile(path)
    logger.debug(
        "Saved OCC pred bin: %s shape=%s elems=%d",
        path,
        list(semantics.shape),
        pred.size,
    )
    if save_npy:
        npy_path = out_dir / f"{bin_prefix}{frame_id:06d}.npy"
        np.save(npy_path, semantics.astype(np.int16))
        logger.info("Saved OCC npy: %s", npy_path)
    return path


def prepare_frame_tensors(
    args, cfg, device: torch.device
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """返回 (float_model_input, meta)。meta 含 img_np / points_np / homo 等。"""
    camera_only = is_camera_only(cfg)
    img_shape = resolve_img_shape(cfg)
    resize_hw, val_hw = resolve_resize_val_hw(cfg)
    orig_parts = [int(x.strip()) for x in args.orig_hw.split(",")]
    if len(orig_parts) != 2:
        raise ValueError("--orig-hw 需为 H,W")
    default_orig_hw = (orig_parts[0], orig_parts[1])

    input_frame = resolve_input_point_frame(cfg, args.point_coord_frame)
    model_frame = resolve_model_point_frame(cfg)
    use_lidar2img = bool(getattr(cfg, "use_lidar2img", True))
    logger.info(
        "camera_only=%s input_point_frame=%s model_point_frame=%s "
        "use_lidar2img=%s img_shape=%s resize=%s val=%s",
        camera_only,
        input_frame,
        model_frame,
        use_lidar2img,
        img_shape,
        resize_hw,
        val_hw,
    )

    homo_dir = Path(args.homo_dir).resolve() if args.homo_dir else None
    if homo_dir is None and args.infer_example_dir:
        homo_dir = Path(args.infer_example_dir).resolve()

    img_np: Optional[np.ndarray] = None
    points_np: Optional[np.ndarray] = None
    orig_hw = default_orig_hw

    if args.sample_dir:
        sample_dir = Path(args.sample_dir).resolve()
        img_bin = sample_dir / "img.bin"
        lidar_bin = sample_dir / "lidar_points.bin"
        if not img_bin.is_file():
            raise FileNotFoundError(f"sample-dir 需含 img.bin: {sample_dir}")
        img_np = load_img_bin(img_bin, img_shape)
        if lidar_bin.is_file():
            points_np = load_points_from_bin(lidar_bin)
        elif not camera_only:
            raise FileNotFoundError(
                f"多传感器 sample-dir 需含 lidar_points.bin: {sample_dir}"
            )
        logger.info(
            "Loaded sample-dir: img=%s points=%s",
            img_np.shape,
            None if points_np is None else points_np.shape,
        )
        if homo_dir is None:
            raise SystemExit(
                "使用 --sample-dir 时必须提供 --homo-dir 或 --infer-example-dir "
                "以读取 lidar2img.npy / ego2img.npy"
            )
    elif args.infer_example_dir:
        infer_p = Path(args.infer_example_dir).resolve()
        jpg_paths = sorted_infer_jpg_paths(infer_p)
        if len(jpg_paths) < 6:
            raise FileNotFoundError(
                f"{infer_p} 期望至少 6 张 img*_*.jpg，实际 {len(jpg_paths)}"
            )
        img_np, orig_hw = build_image_from_jpgs(jpg_paths[:6], resize_hw)
        if img_np.shape != img_shape:
            logger.warning(
                "jpg 预处理 shape %s != config 期望 %s，将尝试继续",
                img_np.shape,
                img_shape,
            )
        lidar_path = infer_p / "lidar.npy"
        if lidar_path.is_file():
            lidar = np.load(lidar_path)
            if lidar.ndim != 2 or lidar.shape[1] < 5:
                raise ValueError(f"lidar.npy 期望 (N,>=5)，实际 {lidar.shape}")
            points_np = lidar[:, :5].astype(np.float32)
            if points_np.shape[0] > 40000:
                points_np = points_np[:40000]
        elif not camera_only:
            raise FileNotFoundError(lidar_path)
        if homo_dir is None:
            homo_dir = infer_p
        logger.info(
            "Loaded infer-example: points=%s img=%s orig_hw=%s",
            None if points_np is None else points_np.shape,
            img_np.shape,
            orig_hw,
        )
    else:
        raise SystemExit("必须指定 --sample-dir 或 --infer-example-dir")

    assert homo_dir is not None
    lidar2img_raw = load_homo_npy(homo_dir / "lidar2img.npy")
    ego2img_raw = load_homo_npy(homo_dir / "ego2img.npy")

    if not camera_only and points_np is not None:
        if input_frame == "lidar" and model_frame == "ego":
            l2e_path = homo_dir / "lidar2ego.npy"
            if l2e_path.is_file():
                l2e = np.asarray(np.load(l2e_path), dtype=np.float64)
            else:
                l2e = infer_lidar2ego_from_homographies(
                    lidar2img_raw, ego2img_raw
                )
                logger.info("由 lidar2img/ego2img 反推 lidar2ego")
            points_np = transform_points_lidar_to_ego(points_np, l2e)
            logger.info("点云已 lidar→ego 以匹配 ego 模型")
        elif input_frame == "ego" and model_frame == "lidar":
            raise SystemExit(
                "输入点云为 ego 系，但 config.use_lidar2img=True 需要 lidar 系。"
                "请改用 lidar 系数据，或切换到 *_ego.py 配置。"
            )

    lidar2img = homography_resize_and_crop(
        lidar2img_raw, resize_hw, orig_hw, val_hw
    )
    ego2img = homography_resize_and_crop(
        ego2img_raw, resize_hw, orig_hw, val_hw
    )

    # img 上 GPU；外参保持 numpy（VT.point_sampling 会 np.asarray）
    img_t = torch.from_numpy(img_np).float().to(device)
    model_input: Dict[str, Any] = {
        "img": img_t,
        "seq_meta": [
            {
                "meta": [{"scene": "float_infer_one_frame"}],
                "lidar2img": [np.asarray(lidar2img, dtype=np.float32)],
                "ego2img": [np.asarray(ego2img, dtype=np.float32)],
            }
        ],
    }
    if points_np is not None:
        model_input["points"] = [
            torch.from_numpy(points_np).float().to(device)
        ]
    elif not camera_only:
        raise SystemExit("多传感器推理缺少点云输入")

    meta = {
        "img_np": img_np,
        "points_np": points_np,
        "lidar2img": lidar2img,
        "ego2img": ego2img,
        "sample_dir": Path(args.sample_dir).resolve() if args.sample_dir else None,
        "point_frame": model_frame,
        "input_frame": input_frame,
        "camera_only": camera_only,
        "resize_hw": resize_hw,
        "val_hw": val_hw,
        "orig_hw": orig_hw,
    }
    return model_input, meta


def build_deploy_inputs(
    cfg, meta: Dict[str, Any], preprocess, device: torch.device
) -> Dict[str, torch.Tensor]:
    sample_dir = meta.get("sample_dir")
    if sample_dir is None:
        raise SystemExit("--mode deploy 需要 --sample-dir（含 aux *.bin）")

    di = cfg.deploy_inputs
    voxel = voxelize_points(preprocess, meta["points_np"], device)
    features = voxel["features"]
    coors = voxel["coors"]

    # 对齐 deploy_inputs 形状（必要时 pad）
    feat_shape = tuple(int(x) for x in di["features"].shape)
    coor_shape = tuple(int(x) for x in di["coors"].shape)
    if tuple(features.shape) != feat_shape:
        logger.warning(
            "features shape %s != deploy %s，尝试 reshape/pad",
            tuple(features.shape),
            feat_shape,
        )
        # 常见: (1,C,P,N) vs 实际
        if features.numel() == int(np.prod(feat_shape)):
            features = features.reshape(feat_shape)
        elif features.ndim == len(feat_shape):
            tgt = torch.zeros(feat_shape, dtype=features.dtype, device=device)
            src = features
            for dim in range(features.ndim):
                if src.shape[dim] > feat_shape[dim]:
                    src = src.narrow(dim, 0, feat_shape[dim])
            tgt[tuple(slice(0, s) for s in src.shape)] = src
            features = tgt
        else:
            raise RuntimeError(
                f"features 无法对齐: {tuple(features.shape)} vs {feat_shape}"
            )
    if tuple(coors.shape) != coor_shape:
        tgt = torch.zeros(coor_shape, dtype=torch.int32, device=device)
        src = coors.to(torch.int32)
        n = min(src.shape[0], coor_shape[0])
        tgt[:n] = src[:n]
        coors = tgt
    else:
        coors = coors.to(torch.int32)

    inputs: Dict[str, torch.Tensor] = {
        "features": features.float(),
        "coors": coors,
        "img": torch.from_numpy(meta["img_np"]).float().to(device),
    }
    for logical, fname in zip(AUX_LOGICAL, AUX_BIN_NAMES):
        shape = tuple(int(x) for x in di[logical].shape)
        path = sample_dir / fname
        if not path.is_file():
            raise FileNotFoundError(f"deploy 模式缺少 {path}")
        arr = load_aux_bin(path, shape)
        inputs[logical] = torch.from_numpy(arr).float().to(device)
        logger.info("Loaded aux %s shape=%s", fname, shape)
    return inputs


@torch.no_grad()
def main():
    args = parse_args()
    n_sources = sum(
        bool(x)
        for x in (args.sample_dir, args.infer_example_dir, args.from_val)
    )
    if n_sources != 1:
        raise SystemExit(
            "必须且只能指定一种输入: --sample-dir / --infer-example-dir / --from-val"
        )

    cfg = load_hat_config(args.config, args.tools_dir)
    camera_only = is_camera_only(cfg)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if device.type != "cuda":
        logger.warning("CUDA 不可用，将在 CPU 上跑（可能极慢或不支持）")

    if args.mode == "deploy":
        if args.from_val:
            raise SystemExit(
                "--from-val 仅支持 --mode float / qat / calibration"
                "（验证集走完整 model，在线 VT）"
            )
        if camera_only or not has_deploy_pipeline(cfg):
            raise SystemExit(
                "--mode deploy 仅适用于含 deploy_model + deploy_inputs 的 "
                "BevFusion 多传感器 argmax 配置；相机预训练请用 --mode float"
            )

    ckpt = resolve_ckpt_path(cfg, args.mode, args.ckpt)
    logger.info(
        "config=%s ckpt=%s mode=%s camera_only=%s from_val=%s",
        args.config,
        ckpt,
        args.mode,
        camera_only,
        args.from_val,
    )

    if args.from_val:
        if args.mode in ("qat", "calibration"):
            model = build_converted_model(
                cfg, args.mode, ckpt, device, args.val_data_path
            )
        else:
            model = build_float_model(cfg, ckpt, device)
        loader, start, lidar_kw = build_val_dataloader(
            cfg,
            args.val_data_path,
            args.num_workers,
            args.start_idx,
            args.max_samples,
            args.num_sweeps,
        )
        n = run_val_inference(
            model,
            loader,
            cfg,
            device,
            Path(args.output_dir).resolve(),
            args.bin_prefix,
            args.save_npy,
            args.max_samples,
            start,
            lidar_kw,
            extra_meta={"mode": args.mode, "ckpt": ckpt},
        )
        print(f"OK: wrote {n} bins -> {args.output_dir}")
        return

    model_input, meta = prepare_frame_tensors(args, cfg, device)

    if args.mode == "float":
        model = build_float_model(cfg, ckpt, device)
        outs = model(model_input)
    elif args.mode in ("qat", "calibration"):
        model = build_converted_model(
            cfg, args.mode, ckpt, device, args.val_data_path
        )
        outs = model(model_input)
    else:
        model = build_deploy_model(cfg, ckpt, device)
        preprocess = build_lidar_preprocess(cfg, device)
        deploy_in = build_deploy_inputs(cfg, meta, preprocess, device)
        outs = model(deploy_in)

    semantics = extract_occ_semantics(outs, cfg)
    out_path = save_occ_pred_bin(
        Path(args.output_dir).resolve(),
        semantics,
        args.frame_id,
        args.bin_prefix,
        args.save_npy,
    )
    print(f"OK: {out_path} shape={list(semantics.shape)} dtype=int16")


if __name__ == "__main__":
    main()
